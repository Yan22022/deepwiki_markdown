---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/1.3-codebase-organization
crawled_at: 2025-06-03T19:42:49.735949
---



# Codebase Organization

Relevant source files

  * [CHANGES](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/CHANGES)
  * [Makefile](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile)
  * [libcuda/cuda_api.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_api.h)
  * [linux-so-version.txt](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/linux-so-version.txt)
  * [setup_environment](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/setup_environment)
  * [version](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/version)
  * [version_detection.mk](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/version_detection.mk)



This document provides an overview of the GPGPU-Sim codebase structure, major components, and their relationships. It serves as a guide to help developers navigate the simulator's code organization and understand how different components interact. For build setup and environment configuration, see [Build System and Setup](/gpgpu-sim/gpgpu-sim_distribution/1.2-build-system-and-setup).

## Directory Structure

GPGPU-Sim is organized into several key directories that correspond to the major components of the simulation framework.
[/code]
[code] 
Sources: [Makefile44-56](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L44-L56) [setup_environment64-65](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/setup_environment#L64-L65)

### Key Directories

  * **src/** : Contains the core simulation components

    * **cuda-sim/** : Front-end CUDA simulator and PTX parser
    * **gpgpu-sim/** : GPU microarchitecture simulator
    * **intersim2/** : Interconnection network simulator
    * **accelwattch/** : Power modeling framework
  * **lib/** : Compiled libraries organized by compiler, CUDA version, and build type

  * **build/** : Build artifacts and object files

  * **configs/** : Configuration files for different GPU architectures

  * **doc/** : Documentation

  * **libcuda/** : CUDA runtime API implementation

  * **libopencl/** : OpenCL runtime API implementation

  * **cuobjdump_to_ptxplus/** : Tool for converting CUDA object dumps to PTXPlus format




Sources: [Makefile61-62](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L61-L62) [Makefile198-223](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L198-L223)

## Major Libraries and Components

GPGPU-Sim is composed of several libraries that work together to provide a comprehensive GPU simulation environment.
[/code]
[code] 
Sources: [Makefile61-94](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L61-L94) [Makefile146-196](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L146-L196)

### Core Libraries

  1. **cuda-sim** : Front-end CUDA simulator

     * Parses and executes PTX instructions
     * Simulates functional behavior of CUDA kernels
     * Handles PTX parsing and interpretation
  2. **gpgpu-sim_uarch** : Back-end microarchitecture simulator

     * Models GPU shader cores
     * Simulates memory hierarchy
     * Provides cycle-accurate timing model
     * Manages thread scheduling and execution
  3. **intersim2** : Interconnection network simulator

     * Models on-chip communication networks
     * Simulates routing and flow control
     * Models network topology and congestion
  4. **gpgpusimlib** : Common utilities and infrastructure

     * Shared functionality across components
     * Integration between front-end and back-end
  5. **accelwattch** : Optional power modeling component

     * Estimates GPU power consumption
     * Models different power components (dynamic, static, etc.)



Sources: [Makefile198-227](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L198-L227) [CHANGES3-4](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/CHANGES#L3-L4)

### API Libraries

  1. **libcuda/libcudart.so** : CUDA Runtime API implementation

     * Intercepts CUDA API calls
     * Redirects execution to the simulator
     * Emulates CUDA driver behavior
  2. **libopencl/libOpenCL.so** : OpenCL API implementation

     * Provides OpenCL compatibility layer
     * Translates OpenCL to CUDA/PTX for simulation



Sources: [Makefile146-196](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L146-L196) [libcuda/cuda_api.h1-50](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_api.h#L1-L50)

## Build System

GPGPU-Sim uses a modular build system that allows different configurations based on compiler version, CUDA version, and build type.
[/code]
[code] 
Sources: [Makefile35-42](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L35-L42) [Makefile97-145](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L97-L145)

### Build Configuration

The build system uses several key variables to determine build configuration:

  * **GPGPUSIM_CONFIG** : Stores the configuration in format `gcc-{cc_version}/cuda-{cuda_version}/{debug|release}`
  * **SIM_LIB_DIR** : Directory for compiled libraries
  * **SIM_OBJ_FILES_DIR** : Directory for object files
  * **DEBUG** : Flag for debug/release mode



Build artifacts are stored based on compiler version, CUDA version, and build type, allowing different configurations to coexist.

Sources: [Makefile37-56](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L37-L56) [setup_environment64-65](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/setup_environment#L64-L65)

### Build Dependencies

The build system enforces dependencies between components:

  1. **cuda-sim** : Built first as many components depend on it
  2. **gpgpu-sim_uarch** : Depends on cuda-sim
  3. **intersim2** : Depends on cuda-sim and gpgpu-sim_uarch
  4. **gpgpusimlib** : Depends on all above components
  5. **API libraries** : Depend on all core components



Sources: [Makefile198-227](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L198-L227)

## Core Component Organization

### CUDA Simulation (Front-End)

The CUDA simulation component handles PTX parsing and functional simulation of CUDA kernels.
[/code]
[code] 
Sources: [Makefile208-210](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L208-L210) [CHANGES25-32](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/CHANGES#L25-L32)

### GPGPU Architecture Simulation (Back-End)

The GPGPU architecture simulation component models the GPU hardware and provides cycle-accurate timing simulation.
[/code]
[code] 
Sources: [Makefile218-220](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L218-L220) [CHANGES31-46](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/CHANGES#L31-L46)

### Memory System

The memory system models the GPU's memory hierarchy, including caches, DRAM, and memory controllers.
[/code]
[code] 
Sources: [CHANGES39-45](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/CHANGES#L39-L45) [CHANGES135-141](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/CHANGES#L135-L141)

### Interconnect Network

The interconnect network simulates the on-chip communication network between shader cores and memory partitions.
[/code]
[code] 
Sources: [Makefile222-223](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L222-L223) [CHANGES147-149](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/CHANGES#L147-L149)

## Configuration and Versioning

### Configuration System

GPGPU-Sim uses configuration files to define GPU architectures and simulation parameters.
[/code]
[code] 
Sources: [CHANGES59-62](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/CHANGES#L59-L62)

### Version Management

The version system tracks GPGPU-Sim, CUDA, and compiler versions to ensure compatibility.
[/code]
[code] 
Sources: [version1](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/version#L1-L1) [version_detection.mk29-47](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/version_detection.mk#L29-L47) [setup_environment8-13](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/setup_environment#L8-L13)

## Integration with CUDA/OpenCL

GPGPU-Sim integrates with CUDA and OpenCL applications by intercepting library calls.
[/code]
[code] 
Sources: [Makefile146-196](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L146-L196) [libcuda/cuda_api.h50-100](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_api.h#L50-L100)

## Summary

GPGPU-Sim codebase is organized into several key components:

  1. **Core Simulation Libraries** :

     * cuda-sim: Front-end PTX simulation
     * gpgpu-sim_uarch: Back-end hardware modeling
     * intersim2: Interconnection network simulation
     * accelwattch: Power modeling (optional)
  2. **API Libraries** :

     * libcudart.so: CUDA runtime API implementation
     * libOpenCL.so: OpenCL API implementation
  3. **Support Components** :

     * Build system
     * Configuration system
     * Version management
     * Testing framework



The modular design allows for flexibility in simulation configurations and supports different GPU architectures from Fermi through Ampere generations.

