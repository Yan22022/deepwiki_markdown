---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/5.3-continuous-integration-and-testing
crawled_at: 2025-06-03T19:42:45.891621
---



# Continuous Integration and Testing

Relevant source files

  * [.github/workflows/accelsim.yml](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.github/workflows/accelsim.yml)
  * [.github/workflows/main.yml](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.github/workflows/main.yml)
  * [.gitignore](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.gitignore)
  * [.travis.yml](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.travis.yml)
  * [configs/tested-cfgs/SM7_QV100/config_volta_islip.icnt](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_QV100/config_volta_islip.icnt)
  * [short-tests-accelsim.sh](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/short-tests-accelsim.sh)
  * [short-tests-cmake.sh](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/short-tests-cmake.sh)
  * [short-tests.sh](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/short-tests.sh)



This document describes the continuous integration (CI) and testing framework used in GPGPU-Sim. It covers the CI infrastructure, test workflows, and testing strategies that ensure code changes maintain simulator functionality across different GPU architecture configurations. For information about GPU architecture configurations themselves, see [GPU Architecture Configurations](/gpgpu-sim/gpgpu-sim_distribution/5.2-gpu-architecture-configurations).

## CI/CD Infrastructure

GPGPU-Sim utilizes GitHub Actions as its primary CI platform, with legacy support for Travis CI. These systems automatically test code changes to ensure they don't break existing functionality.
[/code]
[code] 
Sources: [.github/workflows/main.yml1-106](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.github/workflows/main.yml#L1-L106) [.travis.yml1-39](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.travis.yml#L1-L39) [.github/workflows/accelsim.yml1-34](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.github/workflows/accelsim.yml#L1-L34)

### GitHub Actions Workflows

GPGPU-Sim uses GitHub Actions for automated testing of different GPU configurations. The system runs simulations on Docker containers with pre-installed CUDA environments.

#### Main Workflow

The primary workflow (`Short-Tests`) tests multiple GPU architectures in parallel:

Job Name| GPU Configuration| Container  
---|---|---  
build-TITANV| TITANV| tgrogers/accel-sim_regress:Ubuntu-22.04-cuda-11.7  
build-TITANV-LOCALXBAR| TITANV-LOCALXBAR| tgrogers/accel-sim_regress:Ubuntu-22.04-cuda-11.7  
build-QV100| QV100| tgrogers/accel-sim_regress:Ubuntu-22.04-cuda-11.7  
build-2060| RTX2060| tgrogers/accel-sim_regress:Ubuntu-22.04-cuda-11.7  
build-3070| RTX3070| tgrogers/accel-sim_regress:Ubuntu-22.04-cuda-11.7  
  
Sources: [.github/workflows/main.yml3-86](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.github/workflows/main.yml#L3-L86)

#### AccelSim Workflow

A separate workflow (`Short-Tests-AccelSim`) tests integration with Accel-Sim:
[/code]
[code] 
Sources: [.github/workflows/accelsim.yml1-34](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.github/workflows/accelsim.yml#L1-L34) [short-tests-accelsim.sh1-40](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/short-tests-accelsim.sh#L1-L40)

### Legacy Travis CI

The repository maintains Travis CI configuration for backward compatibility:
[/code]
[code] 
Sources: [.travis.yml1-39](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.travis.yml#L1-L39)

## Test Implementation

### Test Scripts

The CI system uses several shell scripts to execute tests:

  1. **short-tests.sh** : Main test script that:

     * Sets up the environment
     * Builds GPGPU-Sim using make
     * Clones the Accel-Sim framework
     * Runs simulations using Rodinia benchmarks
     * Monitors test progress
  2. **short-tests-cmake.sh** : Alternative test script using CMake build system

  3. **short-tests-accelsim.sh** : Script for testing integration with Accel-Sim




Sources: [short-tests.sh1-25](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/short-tests.sh#L1-L25) [short-tests-cmake.sh1-28](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/short-tests-cmake.sh#L1-L28) [short-tests-accelsim.sh1-40](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/short-tests-accelsim.sh#L1-L40)

### Testing Framework

GPGPU-Sim tests use the Accel-Sim framework for automated testing:
[/code]
[code] 
The testing process involves:

  1. Building GPGPU-Sim
  2. Running benchmark simulations via Accel-Sim's job launcher
  3. Monitoring the progress of tests
  4. Reporting results back to GitHub



Sources: [short-tests.sh19-24](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/short-tests.sh#L19-L24) [short-tests-cmake.sh20-27](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/short-tests-cmake.sh#L20-L27)

## Test Configurations

GPGPU-Sim tests multiple GPU configurations to ensure compatibility across different architectures. Each configuration represents a specific GPU model with its unique characteristics.

### Supported GPU Configurations

The CI system tests the following configurations:

Configuration| Description| Architecture  
---|---|---  
TITANV| NVIDIA Titan V| Volta  
TITANV-LOCALXBAR| Titan V with local crossbar| Volta  
QV100| NVIDIA Tesla V100| Volta  
RTX2060| NVIDIA RTX 2060| Turing  
RTX3070| NVIDIA RTX 3070| Ampere  
GTX480 (Travis)| NVIDIA GTX 480| Fermi  
  
Each configuration uses specific interconnect settings and GPU parameters defined in configuration files.

Sources: [.github/workflows/main.yml18-86](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.github/workflows/main.yml#L18-L86) [configs/tested-cfgs/SM7_QV100/config_volta_islip.icnt1-75](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_QV100/config_volta_islip.icnt#L1-L75)

### Configuration Settings

The GPU configurations include settings for:

  * Network topology
  * Routing algorithms
  * Flow control parameters
  * Buffer sizes
  * Allocation strategies



Example of interconnect configuration for QV100:
[code] 
    topology = fly;
    k = 144;
    n = 1;
    routing_function = dest_tag;
    num_vcs = 1;
    vc_buf_size = 256;
    
[/code]

Sources: [configs/tested-cfgs/SM7_QV100/config_volta_islip.icnt8-24](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_QV100/config_volta_islip.icnt#L8-L24)

## Running Tests Locally

Developers can run the same tests locally to verify changes before submitting pull requests:

  1. Set required environment variables:
[/code]
[code]   2. Run the test script:
[/code]
[code] 


The test script will:

  * Build GPGPU-Sim
  * Clone Accel-Sim framework if not present
  * Run simulations with Rodinia benchmarks
  * Monitor and report test results



Sources: [short-tests.sh1-25](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/short-tests.sh#L1-L25)

## Code Coverage and Quality

The `.gitignore` file indicates that GPGPU-Sim has support for code coverage analysis through gcov:
[code] 
    #gcov
    *.gcov
    *.gcda
    *.gcno
    
[/code]

However, the current CI workflows do not appear to explicitly include code coverage reporting. The repository also has a commented-out section for code formatting, which suggests there might be plans to add automated code formatting to the CI pipeline in the future.

Sources: [.gitignore42-45](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.gitignore#L42-L45) [.github/workflows/main.yml87-105](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.github/workflows/main.yml#L87-L105)

## Integration with External Tools

### Accel-Sim Framework

GPGPU-Sim integrates with the Accel-Sim framework for testing:
[/code]
[code] 
The Accel-Sim framework provides:

  * Job launching utilities
  * Test monitoring
  * Pre-compiled benchmarks
  * Trace collection tools



Sources: [short-tests.sh22-24](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/short-tests.sh#L22-L24) [short-tests-accelsim.sh22-39](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/short-tests-accelsim.sh#L22-L39)

## Automated Testing Triggers

Tests are automatically triggered on:

  * Push to any branch (except GitHub's readonly queue branches)
  * Pull request creation or update
  * Merge group updates
  * Manual trigger via GitHub Actions workflow_dispatch



Sources: [.github/workflows/main.yml6-14](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.github/workflows/main.yml#L6-L14) [.github/workflows/accelsim.yml6-14](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.github/workflows/accelsim.yml#L6-L14)

## Conclusion

GPGPU-Sim's continuous integration and testing framework ensures simulator functionality across multiple GPU architectures. The system leverages GitHub Actions, Docker containers, and the Accel-Sim framework to provide comprehensive testing. By automatically testing against multiple GPU configurations, the framework helps maintain compatibility and catch regressions early in the development process.

