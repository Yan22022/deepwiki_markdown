---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/5.1-configuration-system
crawled_at: 2025-06-03T19:42:39.585744
---



# Configuration System

Relevant source files

  * [configs/tested-cfgs/SM2_GTX480/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM2_GTX480/gpgpusim.config)
  * [configs/tested-cfgs/SM3_KEPLER_TITAN/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM3_KEPLER_TITAN/gpgpusim.config)
  * [configs/tested-cfgs/SM6_TITANX/config_pascal_islip.icnt](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM6_TITANX/config_pascal_islip.icnt)
  * [configs/tested-cfgs/SM6_TITANX/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM6_TITANX/gpgpusim.config)
  * [configs/tested-cfgs/SM75_RTX2060/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM75_RTX2060/gpgpusim.config)
  * [configs/tested-cfgs/SM75_RTX2060_S/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM75_RTX2060_S/gpgpusim.config)
  * [configs/tested-cfgs/SM7_GV100/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_GV100/gpgpusim.config)
  * [configs/tested-cfgs/SM7_QV100/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_QV100/gpgpusim.config)
  * [configs/tested-cfgs/SM7_TITANV/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_TITANV/gpgpusim.config)
  * [configs/tested-cfgs/SM86_RTX3070/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM86_RTX3070/gpgpusim.config)



The GPGPU-Sim configuration system provides a flexible framework for defining and customizing GPU architecture parameters for simulation. This page documents the configuration file format, key parameters, and how the configuration system affects the simulator's behavior. For information about specific GPU architecture configurations, see [GPU Architecture Configurations](/gpgpu-sim/gpgpu-sim_distribution/5.2-gpu-architecture-configurations).

## Overview

The configuration system in GPGPU-Sim allows users to specify detailed parameters that define the simulated GPU architecture. These parameters control every aspect of the simulation, from high-level architectural features to detailed timing specifications.
[/code]
[code] 
Sources: configs/tested-cfgs/SM7_TITANV/gpgpusim.config, configs/tested-cfgs/SM75_RTX2060/gpgpusim.config

## Configuration File Format

GPGPU-Sim uses a simple text-based configuration file format. Each configuration option is specified on a separate line with the following syntax:
[code] 
    -parameter_name parameter_value
    
[/code]

Comments can be added using the `#` character:
[code] 
    # This is a comment
    -gpgpu_n_clusters 30  # Number of SMs
    
[/code]

Multiple values for a single parameter can be specified using various delimiters depending on the parameter:

  * Colon-separated values (e.g., `-gpgpu_clock_domains 1365:1365:1365:3500.5`)
  * Comma-separated values (e.g., `-gpgpu_pipeline_widths 4,4,4,4,4,4,4,4,4,4,8,4,4`)
  * Space-separated values (e.g., `-gpgpu_cache:dl1 S:4:128:64,L:T:m:L:L,A:512:8,16:0,32`)



Sources: configs/tested-cfgs/SM75_RTX2060/gpgpusim.config, configs/tested-cfgs/SM7_TITANV/gpgpusim.config

## Configuration Hierarchy

The configuration parameters in GPGPU-Sim are organized hierarchically according to the system components they affect.
[/code]
[code] 
Sources: configs/tested-cfgs/SM7_TITANV/gpgpusim.config, configs/tested-cfgs/SM75_RTX2060/gpgpusim.config, configs/tested-cfgs/SM7_QV100/gpgpusim.config

## Core Configuration Parameters

### Functional Simulator Parameters

These parameters control the behavior of the functional simulation.

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_ptx_instruction_classification`| Enable/disable PTX instruction classification| `0`  
`-gpgpu_ptx_sim_mode`| PTX simulation mode| `0`  
`-gpgpu_ptx_force_max_capability`| Maximum compute capability for PTX| `75`  
`-gpgpu_ptx_convert_to_ptxplus`| Convert PTX to PTXPlus| `0`  
  
Sources: configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:1-4

### Device Limits

These parameters define limits for various device resources.

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_stack_size_limit`| Maximum stack size (bytes)| `1024`  
`-gpgpu_heap_size_limit`| Maximum heap size (bytes)| `8388608`  
`-gpgpu_runtime_sync_depth_limit`| Maximum depth of runtime synchronization| `2`  
`-gpgpu_runtime_pending_launch_count_limit`| Maximum number of pending kernel launches| `2048`  
`-gpgpu_max_concurrent_kernel`| Maximum number of concurrent kernels| `128`  
  
Sources: configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:7-13

### Compute Capability

These parameters specify the compute capability of the simulated GPU.

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_compute_capability_major`| Major compute capability version| `7`  
`-gpgpu_compute_capability_minor`| Minor compute capability version| `5`  
  
Sources: configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:16-17

### High-Level Architecture Configuration

These parameters define the high-level structure of the GPU.

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_n_clusters`| Number of clusters (SMs)| `30`  
`-gpgpu_n_cores_per_cluster`| Number of cores per cluster| `1`  
`-gpgpu_n_mem`| Number of memory partitions| `12`  
`-gpgpu_n_sub_partition_per_mchannel`| Number of sub-partitions per memory channel| `2`  
`-gpgpu_clock_domains`| Clock frequencies for Core:Interconnect:L2:DRAM (MHz)| `1365:1365:1365:3500.5`  
  
Sources: configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:24-31

## Shader Core Configuration

### Register File and Pipeline Configuration

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_shader_registers`| Total number of registers per SM| `65536`  
`-gpgpu_registers_per_block`| Maximum number of registers per block| `65536`  
`-gpgpu_occupancy_sm_number`| SM architecture for occupancy calculation| `75`  
`-gpgpu_shader_core_pipeline`| Number of threads:warp size| `1024:32`  
`-gpgpu_shader_cta`| Maximum number of CTAs per SM| `16`  
`-gpgpu_simd_model`| SIMD model (1 for Nvidia-like)| `1`  
  
Sources: configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:34-40

### Functional Units and Pipeline Width

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_pipeline_widths`| Pipeline widths for different stages| `4,4,4,4,4,4,4,4,4,4,8,4,4`  
`-gpgpu_num_sp_units`| Number of SP (single-precision) units| `4`  
`-gpgpu_num_sfu_units`| Number of SFU (special function) units| `4`  
`-gpgpu_num_dp_units`| Number of DP (double-precision) units| `4`  
`-gpgpu_num_int_units`| Number of INT (integer) units| `4`  
`-gpgpu_tensor_core_avail`| Tensor core availability| `1`  
`-gpgpu_num_tensor_core_units`| Number of tensor core units| `4`  
  
Sources: configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:44-50

### Instruction Latency and Throughput

Parameter| Description| Example Value  
---|---|---  
`-ptx_opcode_latency_int`| Latency of integer operations| `4,4,4,4,21`  
`-ptx_opcode_initiation_int`| Initiation interval of integer operations| `2,2,2,2,2`  
`-ptx_opcode_latency_fp`| Latency of floating-point operations| `4,4,4,4,39`  
`-ptx_opcode_initiation_fp`| Initiation interval of floating-point operations| `2,2,2,2,4`  
`-ptx_opcode_latency_dp`| Latency of double-precision operations| `64,64,64,64,330`  
`-ptx_opcode_initiation_dp`| Initiation interval of double-precision operations| `64,64,64,64,130`  
`-ptx_opcode_latency_sfu`| Latency of special function unit operations| `21`  
`-ptx_opcode_initiation_sfu`| Initiation interval of special function unit operations| `8`  
`-ptx_opcode_latency_tesnor`| Latency of tensor core operations| `64`  
`-ptx_opcode_initiation_tensor`| Initiation interval of tensor core operations| `64`  
  
Sources: configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:55-64

### Warp Scheduling

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_num_sched_per_core`| Number of warp schedulers per core| `4`  
`-gpgpu_scheduler`| Scheduling algorithm (e.g., lrr, gto)| `lrr`  
`-gpgpu_max_insn_issue_per_warp`| Maximum instructions issued per warp per cycle| `1`  
`-gpgpu_dual_issue_diff_exec_units`| Whether to allow dual issue to different execution units| `1`  
  
Sources: configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:79-83

## Memory Hierarchy Configuration

### L1 Cache and Shared Memory

GPGPU-Sim allows for adaptive partitioning of resources between L1 cache and shared memory.

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_adaptive_cache_config`| Enable adaptive L1/shared memory configuration| `1`  
`-gpgpu_shmem_option`| Available shared memory size options (KB)| `32,64`  
`-gpgpu_unified_l1d_size`| Total size of unified L1/shared memory (KB)| `96`  
`-gpgpu_l1_banks`| Number of L1 cache banks| `4`  
`-gpgpu_cache:dl1`| L1 data cache configuration| `S:4:128:64,L:T:m:L:L,A:256:32,16:0,32`  
`-gpgpu_l1_latency`| L1 cache latency (cycles)| `32`  
  
Sources: configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:90-101

### Shared Memory Configuration

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_shmem_size`| Total shared memory size (bytes)| `65536`  
`-gpgpu_shmem_sizeDefault`| Default shared memory size (bytes)| `65536`  
`-gpgpu_shmem_per_block`| Maximum shared memory per block (bytes)| `49152`  
`-gpgpu_smem_latency`| Shared memory latency (cycles)| `30`  
`-gpgpu_shmem_num_banks`| Number of shared memory banks| `32`  
`-gpgpu_shmem_limited_broadcast`| Limited broadcast for shared memory| `0`  
`-gpgpu_shmem_warp_parts`| Number of shared memory warp parts| `1`  
  
Sources: configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:103-111

### L2 Cache Configuration

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_cache:dl2`| L2 cache configuration| `S:64:128:16,L:B:m:L:P,A:192:4,32:0,32`  
`-gpgpu_cache:dl2_texture_only`| Whether L2 caches only texture data| `0`  
`-gpgpu_dram_partition_queues`| DRAM partition queue depths| `64:64:64:64`  
`-gpgpu_memory_partition_indexing`| Memory partition indexing scheme| `0`  
  
Sources: configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:114-118

### Other Caches

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_cache:il1`| Instruction L1 cache configuration| `N:64:128:16,L:R:f:N:L,S:2:48,4`  
`-gpgpu_inst_fetch_throughput`| Instruction fetch throughput| `4`  
`-gpgpu_tex_cache:l1`| Texture cache configuration| `N:4:128:256,L:R:m:N:L,T:512:8,128:2`  
`-gpgpu_const_cache:l1`| Constant cache configuration| `N:128:64:8,L:R:f:N:L,S:2:64,4`  
`-gpgpu_perfect_inst_const_cache`| Perfect instruction and constant cache| `1`  
  
Sources: configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:121-128

## DRAM Configuration

### DRAM Parameters

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_l2_rop_latency`| L2 to ROP latency| `194`  
`-dram_latency`| DRAM latency (cycles)| `96`  
`-gpgpu_dram_scheduler`| DRAM scheduler algorithm| `1`  
`-gpgpu_frfcfs_dram_sched_queue_size`| FR-FCFS scheduler queue size| `64`  
`-gpgpu_dram_return_queue_size`| DRAM return queue size| `192`  
`-gpgpu_n_mem_per_ctrlr`| Number of memories per controller| `1`  
`-gpgpu_dram_buswidth`| DRAM bus width (bytes)| `2`  
`-gpgpu_dram_burst_length`| DRAM burst length| `16`  
  
Sources: configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:140-151

### DRAM Timing

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_dram_timing_opt`| DRAM timing parameters| `nbk=16:CCD=4:RRD=12:RCD=24:RAS=55:RP=24:RC=78:CL=24:WL=8:CDLR=10:WR=24:nbkgrp=4:CCDL=6:RTPL=4`  
`-dram_dual_bus_interface`| Dual bus interface| `0`  
`-dram_bnk_indexing_policy`| Bank indexing policy| `0`  
`-dram_bnkgrp_indexing_policy`| Bank group indexing policy| `1`  
  
Sources: configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:157-162

## Interconnection Network Configuration

GPGPU-Sim supports different network modes for the interconnection network.

Parameter| Description| Example Value  
---|---|---  
`-network_mode`| Network mode (1=configuration file, 2=built-in)| `2`  
`-icnt_in_buffer_limit`| Input buffer limit| `512`  
`-icnt_out_buffer_limit`| Output buffer limit| `512`  
`-icnt_subnets`| Number of subnets| `2`  
`-icnt_flit_size`| Size of a network flit (bytes)| `40`  
`-icnt_arbiter_algo`| Arbiter algorithm| `1`  
  
Sources: configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:133-137

When using network mode 1, an external interconnect configuration file must be specified:
[code] 
    -network_mode 1
    -inter_config_file config_pascal_islip.icnt
    
[/code]

The interconnect configuration file contains detailed settings for the network topology, routing algorithm, flow control, and other network parameters.

Sources: configs/tested-cfgs/SM6_TITANX/gpgpusim.config:164-165, configs/tested-cfgs/SM6_TITANX/config_pascal_islip.icnt

## Statistics Collection Configuration

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_memlatency_stat`| Memory latency statistics collection interval| `14`  
`-gpgpu_runtime_stat`| Runtime statistics collection interval| `500`  
`-enable_ptx_file_line_stats`| Enable statistics at PTX file and line level| `1`  
`-visualizer_enabled`| Enable visualizer| `0`  
  
Sources: configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:168-171

## Configuration File Examples and Pre-defined GPU Architectures

GPGPU-Sim comes with pre-defined configuration files for various NVIDIA GPU architectures. These can be found in the `configs/tested-cfgs/` directory.
[/code]
[code] 
The configuration system allows you to select one of these pre-defined architectures or create your own custom configuration by modifying the parameters.

Sources: configs/tested-cfgs/SM2_GTX480/gpgpusim.config, configs/tested-cfgs/SM3_KEPLER_TITAN/gpgpusim.config, configs/tested-cfgs/SM6_TITANX/gpgpusim.config, configs/tested-cfgs/SM7_TITANV/gpgpusim.config, configs/tested-cfgs/SM75_RTX2060/gpgpusim.config, configs/tested-cfgs/SM86_RTX3070/gpgpusim.config

## Comparison of Key Parameters Across GPU Generations

Below is a comparison of key configuration parameters across different GPU architectures supported by GPGPU-Sim:

Parameter| SM2_GTX480 (Fermi)| SM3_KEPLER (Kepler)| SM6_TITANX (Pascal)| SM7_TITANV (Volta)| SM75_RTX2060 (Turing)| SM86_RTX3070 (Ampere)  
---|---|---|---|---|---|---  
Core Clock| 700 MHz| 837 MHz| 1417 MHz| 1200 MHz| 1365 MHz| 1132 MHz  
DRAM Clock| 924 MHz| 1502 MHz| 2500 MHz| 850 MHz| 3500.5 MHz| 3500.5 MHz  
SM Count| 15| 14| 28| 40| 30| 46  
Cores/SM| 1| 1| 1| 2| 1| 1  
Mem Partitions| 6| 12| 12| 24| 12| 16  
L1 Cache| 32 KB| 16/48 KB| Disabled| Adaptive (0-128 KB)| Adaptive (32-96 KB)| Adaptive (0-128 KB)  
L2 Cache Size| ~786 KB| ~1.5 MB| ~3 MB| ~4.5 MB| ~3 MB| ~4 MB  
Register File| 32768| 65536| 65536| 65536| 65536| 65536  
SIMD Width| 32| 32| 32| 32| 32| 32  
Shared Memory| 48 KB| 16/48 KB| 48/96 KB| 0-96 KB| 32-64 KB| 0-100 KB  
  
Sources: configs/tested-cfgs/SM2_GTX480/gpgpusim.config, configs/tested-cfgs/SM3_KEPLER_TITAN/gpgpusim.config, configs/tested-cfgs/SM6_TITANX/gpgpusim.config, configs/tested-cfgs/SM7_TITANV/gpgpusim.config, configs/tested-cfgs/SM75_RTX2060/gpgpusim.config, configs/tested-cfgs/SM86_RTX3070/gpgpusim.config

## Configuration Propagation Flow

The following diagram illustrates how configuration parameters are loaded and propagated through the simulator:
[/code]
[code] 
The configuration system is the foundation for GPGPU-Sim's flexibility, allowing it to model a wide range of GPU architectures from different generations by simply changing configuration parameters.

Sources: configs/tested-cfgs/SM7_TITANV/gpgpusim.config, configs/tested-cfgs/SM75_RTX2060/gpgpusim.config, configs/tested-cfgs/SM86_RTX3070/gpgpusim.config

