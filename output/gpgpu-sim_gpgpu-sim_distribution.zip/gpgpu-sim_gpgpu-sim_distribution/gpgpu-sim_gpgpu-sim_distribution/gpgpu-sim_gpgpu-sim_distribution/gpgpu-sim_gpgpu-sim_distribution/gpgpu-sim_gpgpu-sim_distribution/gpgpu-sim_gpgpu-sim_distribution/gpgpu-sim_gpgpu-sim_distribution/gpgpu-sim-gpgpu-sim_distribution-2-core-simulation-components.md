---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/2-core-simulation-components
crawled_at: 2025-06-03T19:42:13.180855
---



# Core Simulation Components

Relevant source files

  * [src/abstract_hardware_model.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.cc)
  * [src/abstract_hardware_model.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h)
  * [src/gpgpu-sim/gpu-sim.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.cc)
  * [src/gpgpu-sim/gpu-sim.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h)
  * [src/gpgpu-sim/shader.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc)
  * [src/gpgpu-sim/shader.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h)



This page provides an overview of the core simulation components in GPGPU-Sim, describing the main architectural elements that make up the simulation infrastructure. For information about configuration options, see [Configuration and Testing](/gpgpu-sim/gpgpu-sim_distribution/5-configuration-and-testing), and for detailed API interfaces, see [API Runtime and Interfaces](/gpgpu-sim/gpgpu-sim_distribution/3-api-runtime-and-interfaces).

## Overview

GPGPU-Sim implements a cycle-accurate GPU architecture simulator with detailed models of shader cores, memory systems, and interconnect networks. The core simulation components work together to execute CUDA/OpenCL applications and provide performance statistics and insights.
[/code]
[code] 
Sources: [src/gpgpu-sim/shader.h350-367](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L350-L367) [src/gpgpu-sim/gpu-sim.h556-806](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h#L556-L806)

## Simulation Hierarchy

The GPGPU-Sim simulator is structured in a hierarchical manner, with components organized to reflect the architecture of modern GPUs.

### Core Simulation Class Hierarchy
[/code]
[code] 
Sources: [src/gpgpu-sim/gpu-sim.h577-650](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h#L577-L650) [src/gpgpu-sim/shader.h469-505](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L469-L505)

The simulation hierarchy begins with `gpgpu_sim` as the top-level simulator class, which manages the overall simulation process. This class is extended by either `exec_gpgpu_sim` (for regular execution) or `sst_gpgpu_sim` (for integration with SST framework). The simulator consists of multiple `simt_core_cluster` instances, each containing multiple `shader_core_ctx` instances that represent individual shader cores.

## Shader Core Architecture

The shader core is the primary computational unit of the GPU and is represented by the `shader_core_ctx` class. Each shader core contains pipeline stages, execution units, a memory subsystem, and scheduling components.
[/code]
[code] 
Sources: [src/gpgpu-sim/shader.cc460-468](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L460-L468) [src/gpgpu-sim/shader.h469-505](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L469-L505)

The shader core components include:

  1. **Front-End Pipeline** : Handles instruction fetch, decode, and issue operations
  2. **Warp Schedulers** : Manage the scheduling of warps for execution
  3. **Operand Collector** : Collects operands from registers for execution
  4. **Execution Units** : Various execution units for different instruction types
  5. **Memory Subsystem** : Handles memory accesses, including caches and shared memory



## Pipeline Stages

The shader core implements a pipeline architecture to process instructions.
[/code]
[code] 
Sources: [src/gpgpu-sim/shader.cc101-124](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L101-L124) [src/gpgpu-sim/shader.h59-77](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L59-L77)

Each pipeline stage has specific register sets defined in the `shader_core_ctx` class:
[code] 
    Pipeline Stages:
    - FE: Fetch
    - ID: Decode
    - ID_OC_SP/SFU/DP/INT/TENSOR/MEM: Issue to different execution units
    - OC_EX_SP/SFU/DP/INT/TENSOR/MEM: Operand Collection for different execution units
    - EX_WB: Execute and Writeback
    
[/code]

## Execution Units

GPGPU-Sim models multiple types of execution units to handle different instruction types. These units are created and managed in `shader_core_ctx::create_exec_pipeline()`.

Execution Unit Type| Description| Function  
---|---|---  
SP Unit| Single-precision floating point| Basic arithmetic operations  
SFU Unit| Special Function Unit| Transcendental functions (sin, cos, etc.)  
DP Unit| Double-precision floating point| Double-precision arithmetic  
INT Unit| Integer| Integer arithmetic operations  
Tensor Core| Tensor operations| Matrix multiply-accumulate operations  
LDST Unit| Load/Store| Memory access operations  
Specialized Unit| Configurable specialized units| Application-specific accelerators  
  
Sources: [src/gpgpu-sim/shader.cc410-456](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L410-L456)

Each execution unit handles specific types of instructions and has its own latency and throughput characteristics. The LDST unit is particularly important as it handles all memory operations and interfaces with the memory subsystem.

## Warp Management and SIMT Execution

At the heart of GPU execution is the SIMT (Single Instruction, Multiple Thread) execution model, where multiple threads execute the same instruction but on different data. GPGPU-Sim models this through warps and the SIMT stack.

### Warp and Thread State
[/code]
[code] 
Sources: [src/gpgpu-sim/shader.h103-205](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L103-L205) [src/abstract_hardware_model.h433-481](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L433-L481)

The `shd_warp_t` class represents a warp in GPGPU-Sim, tracking the current PC, active threads, and instruction buffer. The `simt_stack` manages branch divergence and reconvergence, with each entry containing a PC and active mask.

## Warp Scheduling

GPGPU-Sim implements various warp scheduling policies through the `scheduler_unit` class hierarchy.
[/code]
[code] 
Sources: [src/gpgpu-sim/shader.h376-567](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L376-L567) [src/gpgpu-sim/shader.cc186-269](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L186-L269)

The scheduler implementations include:

  * **LRR (Loose Round Robin)** : Rotates through all warps
  * **GTO (Greedy Then Oldest)** : Prioritizes the oldest warps
  * **Two-level Active** : Uses a two-level scheduling approach with active and pending warps
  * **Others** : Various other scheduling policies like RRR (Strict Round Robin) and Warp Limiting



## Memory System Integration

The shader core interfaces with the memory system through the load/store unit (`ldst_unit`) and various cache structures.
[/code]
[code] 
Sources: [src/gpgpu-sim/shader.cc451-456](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L451-L456) [src/abstract_hardware_model.h762-893](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L762-L893)

Key components include:

  1. **LDST Unit** : Handles all memory instructions
  2. **Memory Coalescer** : Combines memory accesses from threads in a warp
  3. **Cache Hierarchy** : L1, L2, and specialized caches
  4. **Interconnection Network** : Handles communication between shader cores and memory partitions
  5. **Memory Partitions** : Manage DRAM access and scheduling



## Simulation Cycle

The simulation proceeds through a cycle-by-cycle execution model, with the main loop implemented in `gpgpu_sim::cycle()`.
[/code]
[code] 
Sources: [src/gpgpu-sim/gpu-sim.h589-590](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h#L589-L590)

The simulation cycle includes:

  1. **Shader Core Cycle** : Process pipeline stages, issue instructions, execute
  2. **Memory Cycle** : Process memory requests, manage DRAM access
  3. **Interconnect Cycle** : Transfer data between cores and memory
  4. **Block Issuing** : Schedule new CTAs to available cores
  5. **Statistics Collection** : Gather performance statistics



## Conclusion

The core simulation components in GPGPU-Sim work together to provide a detailed, cycle-accurate simulation of GPU execution. The simulator models shader cores, memory hierarchy, and interconnection networks to simulate the execution of CUDA and OpenCL applications. These components allow researchers and developers to study GPU performance, explore architectural improvements, and optimize applications.

For more details on specific components, refer to the corresponding wiki pages:

  * [Shader Core Simulation](/gpgpu-sim/gpgpu-sim_distribution/2.1-shader-core-simulation) for in-depth information on shader cores
  * [Memory System](/gpgpu-sim/gpgpu-sim_distribution/2.3-memory-system) for details on the memory hierarchy
  * [Execution Model and Thread Management](/gpgpu-sim/gpgpu-sim_distribution/2.4-execution-model-and-thread-management) for details on the SIMT execution model
  * [CUDA Simulation and PTX Execution](/gpgpu-sim/gpgpu-sim_distribution/2.2-cuda-simulation-and-ptx-execution) for details on PTX instruction execution



