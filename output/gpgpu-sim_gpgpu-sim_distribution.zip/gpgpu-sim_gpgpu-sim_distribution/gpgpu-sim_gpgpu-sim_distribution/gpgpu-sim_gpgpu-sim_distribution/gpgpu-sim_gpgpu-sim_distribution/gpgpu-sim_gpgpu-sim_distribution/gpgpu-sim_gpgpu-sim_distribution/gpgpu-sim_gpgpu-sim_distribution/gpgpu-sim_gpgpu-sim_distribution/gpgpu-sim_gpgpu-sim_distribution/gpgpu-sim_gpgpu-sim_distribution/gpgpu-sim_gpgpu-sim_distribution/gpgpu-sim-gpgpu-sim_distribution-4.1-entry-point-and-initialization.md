---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/4.1-entry-point-and-initialization
crawled_at: 2025-06-03T19:42:21.236965
---



# Entry Point and Initialization

Relevant source files

  * [src/cuda-sim/cuda-sim.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda-sim.h)
  * [src/debug.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/debug.cc)
  * [src/debug.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/debug.h)
  * [src/gpgpusim_entrypoint.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc)
  * [src/gpgpusim_entrypoint.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.h)
  * [src/stream_manager.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc)
  * [src/stream_manager.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h)



This page documents the entry point and initialization process of GPGPU-Sim. It covers how the simulator is started, configured, and initialized, as well as how the simulation threads and stream management are set up to execute CUDA/OpenCL operations. For information about the runtime API implementation itself, see [API Runtime and Interfaces](/gpgpu-sim/gpgpu-sim_distribution/3-api-runtime-and-interfaces).

## Overview

GPGPU-Sim is initialized through a specific sequence of operations that prepare the simulation environment, load configuration parameters, and set up the simulation infrastructure. The initialization process creates the necessary components that will execute CUDA/OpenCL applications, including the GPU model, memory system, and stream management.
[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.cc304-346](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L304-L346) [src/gpgpusim_entrypoint.cc348-364](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L348-L364)

## Core Context and State

The GPGPU-Sim state is maintained in two key contexts:

  1. `gpgpu_context`: The primary container for the GPGPU-Sim state, containing a pointer to `the_gpgpusim` and other simulation components.
  2. `GPGPUsim_ctx`: Holds core simulation state including the GPU instance, stream manager, and synchronization primitives.


[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.h40-76](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.h#L40-L76)

## Initialization Process

The initialization process is driven by the `gpgpu_ptx_sim_init_perf()` method, which performs the following steps:

  1. Initialize the random number generator (`srand(1)`)
  2. Display the GPGPU-Sim splash screen
  3. Read simulation environment variables
  4. Parse PTX options
  5. Create and configure the GPU simulator
  6. Initialize the stream manager
  7. Set up synchronization primitives


[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.cc304-346](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L304-L346)

## Simulation Thread Management

After initialization, GPGPU-Sim starts a simulation thread that executes either in sequential or concurrent mode. This thread is responsible for executing the simulation loop that processes CUDA/OpenCL operations.

### Simulation Thread Startup

The simulation thread is started with the `start_sim_thread()` method:
[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.cc348-364](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L348-L364)

### Execution Modes

GPGPU-Sim supports two primary execution modes:

#### 1\. Sequential Mode

In sequential mode, one kernel is executed at a time. The simulation loop waits for a signal to start, processes a single kernel to completion, and then signals completion.
[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.cc61-84](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L61-L84)

#### 2\. Concurrent Mode

In concurrent mode, multiple operations can be processed concurrently. The simulation thread continuously checks for operations in the stream manager and processes them as they become available.
[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.cc91-185](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L91-L185)

## Stream Management

The stream manager is a critical component that manages the execution of CUDA/OpenCL operations. It handles the scheduling of operations on streams, tracks the progress of operations, and facilitates synchronization between the host and device.

### Stream Manager Structure
[/code]
[code] 
Sources: [src/stream_manager.h31-282](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h#L31-L282) [src/stream_manager.cc29-510](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L29-L510)

### Operation Processing Flow

The stream manager processes operations through the following flow:

  1. Host code pushes operations into the stream manager with `push()`
  2. The simulation thread calls `operation()` to execute the next operation
  3. The `do_operation()` method on the stream operation executes the actual operation (kernel launch, memory copy, etc.)
  4. The stream manager manages synchronization and records completion


[/code]
[code] 
Sources: [src/stream_manager.cc124-215](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L124-L215) [src/stream_manager.cc257-275](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L257-L275)

## Host-Device Synchronization

GPGPU-Sim provides several synchronization mechanisms to coordinate between the host application and the device simulation:

### 1\. Explicit Synchronization

The `gpgpu_context::synchronize()` method provides explicit synchronization, waiting until all operations in the stream manager are complete:
[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.cc256-272](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L256-L272)

### 2\. Stream Synchronization

Individual streams can be synchronized using the `CUstream_st::synchronize()` method:
[/code]
[code] 
Sources: [src/stream_manager.cc67-75](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L67-L75)

### 3\. Semaphore-based Synchronization

For sequential mode, semaphores are used to synchronize between the host and simulation thread:
[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.cc61-84](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L61-L84) [src/gpgpusim_entrypoint.cc341-343](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L341-L343)

## Termination Process

The simulator can be terminated through the `exit_simulation()` method, which sets the `g_sim_done` flag and waits for the simulation thread to exit:
[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.cc295-302](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L295-L302)

## Structural Support for Different Modes

GPGPU-Sim supports multiple execution modes, including:

  1. **Standard simulation mode** : The default mode where GPGPU-Sim runs as a library linked to CUDA applications
  2. **SST mode** : For integration with the Structural Simulation Toolkit (SST)
  3. **Sequential/Concurrent API modes** : For different CUDA API execution behaviors


[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.cc328-335](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L328-L335) [src/gpgpusim_entrypoint.cc348-364](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L348-L364)

## Debug Support

GPGPU-Sim includes an interactive debugging system that can be used to debug the simulation. The debugger includes features for setting breakpoints, watchpoints, and single-stepping through the simulation.
[/code]
[code] 
Sources: [src/debug.cc46-218](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/debug.cc#L46-L218) [src/debug.h29-86](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/debug.h#L29-L86)

## Conclusion

The entry point and initialization system of GPGPU-Sim provides a comprehensive framework for starting, configuring, and running GPU simulations. The system supports different execution modes, handles synchronization between host and device, and provides mechanisms for debugging and monitoring the simulation.

The initialization process creates and configures the GPU model, sets up the stream manager for operation scheduling, and starts the simulation thread that executes operations. The stream manager serves as the bridge between the host application and the simulated GPU, managing the flow of operations and coordinating synchronization.

