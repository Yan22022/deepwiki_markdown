---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/5-configuration-and-testing
crawled_at: 2025-06-03T19:42:30.811079
---



# Configuration and Testing

Relevant source files

  * [.github/workflows/accelsim.yml](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.github/workflows/accelsim.yml)
  * [.github/workflows/main.yml](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.github/workflows/main.yml)
  * [.gitignore](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.gitignore)
  * [.travis.yml](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.travis.yml)
  * [configs/tested-cfgs/SM2_GTX480/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM2_GTX480/gpgpusim.config)
  * [configs/tested-cfgs/SM3_KEPLER_TITAN/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM3_KEPLER_TITAN/gpgpusim.config)
  * [configs/tested-cfgs/SM6_TITANX/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM6_TITANX/gpgpusim.config)
  * [configs/tested-cfgs/SM75_RTX2060/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM75_RTX2060/gpgpusim.config)
  * [configs/tested-cfgs/SM75_RTX2060_S/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM75_RTX2060_S/gpgpusim.config)
  * [configs/tested-cfgs/SM7_GV100/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_GV100/gpgpusim.config)
  * [configs/tested-cfgs/SM7_QV100/config_volta_islip.icnt](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_QV100/config_volta_islip.icnt)
  * [configs/tested-cfgs/SM7_QV100/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_QV100/gpgpusim.config)
  * [configs/tested-cfgs/SM7_TITANV/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_TITANV/gpgpusim.config)
  * [configs/tested-cfgs/SM86_RTX3070/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM86_RTX3070/gpgpusim.config)
  * [short-tests-accelsim.sh](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/short-tests-accelsim.sh)
  * [short-tests-cmake.sh](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/short-tests-cmake.sh)
  * [short-tests.sh](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/short-tests.sh)



This document provides a comprehensive overview of the configuration system and testing framework in GPGPU-Sim. It explains how to configure the simulator to model different GPU architectures, describe their parameters in detail, and use the testing infrastructure to validate simulations.

## 1\. Configuration System Overview

GPGPU-Sim uses a flexible configuration system to define the parameters of the simulated GPU architecture. This allows users to model various NVIDIA GPU architectures from Fermi (GTX480) to Ampere (RTX3070), or create custom GPU designs.

The configuration system is based on plain text files with parameter settings that control every aspect of the simulator's behavior, from high-level architecture specifications to detailed timing parameters.
[/code]
[code] 
Sources: `configs/tested-cfgs/SM7_QV100/gpgpusim.config`, `configs/tested-cfgs/SM75_RTX2060/gpgpusim.config`, `configs/tested-cfgs/SM86_RTX3070/gpgpusim.config`

### 1.1 Configuration File Structure

Configuration files use a simple format where each line contains a parameter name (prefixed with a hyphen) followed by its value(s). Parameters are organized into logical groups:
[code] 
    # Functional simulator specification
    -gpgpu_ptx_instruction_classification 0
    -gpgpu_ptx_sim_mode 0
    -gpgpu_ptx_force_max_capability 75
    
    # Device Limits
    -gpgpu_stack_size_limit 1024
    -gpgpu_heap_size_limit 8388608
    
[/code]

Comments start with the `#` character and are used to organize parameters into sections and provide explanations.

Sources: `configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:1-15`

## 2\. Core Configuration Parameters

### 2.1 Functional Simulator Specifications

These parameters control the basic behavior of the functional simulation:

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_ptx_instruction_classification`| Controls PTX instruction classification| `0`  
`-gpgpu_ptx_sim_mode`| PTX simulation mode| `0`  
`-gpgpu_ptx_force_max_capability`| Maximum PTX capability version to support| `75`  
`-gpgpu_ptx_convert_to_ptxplus`| Whether to convert PTX to PTXPlus| `0`  
  
Sources: `configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:1-6`, `configs/tested-cfgs/SM7_QV100/gpgpusim.config:41-44`

### 2.2 Device Limits

These parameters define constraints of the simulated device:

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_stack_size_limit`| Maximum stack size per thread (bytes)| `1024`  
`-gpgpu_heap_size_limit`| Maximum heap size (bytes)| `8388608`  
`-gpgpu_runtime_sync_depth_limit`| Maximum depth of runtime synchronization| `2`  
`-gpgpu_runtime_pending_launch_count_limit`| Maximum pending kernel launches| `2048`  
`-gpgpu_max_concurrent_kernel`| Maximum concurrent kernels| `128`  
  
Sources: `configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:7-13`, `configs/tested-cfgs/SM7_QV100/gpgpusim.config:46-53`

### 2.3 High-Level Architecture Configuration

These parameters define the high-level structure of the GPU:

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_n_clusters`| Number of shader clusters (SMs)| `30` (RTX2060), `46` (RTX3070)  
`-gpgpu_n_cores_per_cluster`| Cores per cluster| `1`  
`-gpgpu_n_mem`| Number of memory partitions| `12` (RTX2060), `16` (RTX3070)  
`-gpgpu_n_sub_partition_per_mchannel`| Sub-partitions per memory channel| `2`  
  
Sources: `configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:24-27`, `configs/tested-cfgs/SM86_RTX3070/gpgpusim.config:24-27`

### 2.4 Clock Domains

These parameters define the clock frequencies for different components:
[code] 
    # clock domains
    #-gpgpu_clock_domains <Core Clock>:<Interconnect Clock>:<L2 Clock>:<DRAM Clock>
    -gpgpu_clock_domains 1365:1365:1365:3500.5
    
[/code]

The format is `<Core Clock>:<Interconnect Clock>:<L2 Clock>:<DRAM Clock>` with frequencies in MHz.

Sources: `configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:29-31`, `configs/tested-cfgs/SM86_RTX3070/gpgpusim.config:29-31`

### 2.5 Shader Core Configuration

These parameters define the shader core microarchitecture:

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_shader_registers`| Total registers per SM| `65536`  
`-gpgpu_registers_per_block`| Maximum registers per thread block| `65536`  
`-gpgpu_shader_core_pipeline`| Warp size and max warps per shader| `1024:32`  
`-gpgpu_num_sp_units`| Number of SP (single-precision) units per shader| `4`  
`-gpgpu_num_sfu_units`| Number of SFU (special function) units per shader| `4`  
`-gpgpu_num_dp_units`| Number of DP (double-precision) units per shader| `4`  
`-gpgpu_num_int_units`| Number of INT (integer) units per shader| `4`  
`-gpgpu_num_tensor_core_units`| Number of tensor core units per shader| `4`  
  
Sources: `configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:34-50`, `configs/tested-cfgs/SM7_QV100/gpgpusim.config:76-96`

### 2.6 Memory System Configuration

These parameters define the memory hierarchy, including caches and DRAM:
[/code]
[code] 
Cache configurations use the following format:
[code] 
    -gpgpu_cache:<cache_name> <config_string>
    
[/code]

Where `<config_string>` follows the pattern:
[code] 
    S:<nsets>:<bsize>:<assoc>,L:<rep>:<wr>:<alloc>:<wr_alloc>:<set_index_fn>,A:<mshr_entries>:<max_merge>,<mq_size>:0,32
    
[/code]

For example:
[code] 
    -gpgpu_cache:dl1 S:4:128:64,L:T:m:L:L,A:256:32,16:0,32
    
[/code]

This defines a data L1 cache with 4 sets, 128-byte lines, 64-way associativity, and other detailed parameters for replacement policy, write policy, and MSHR (Miss Status Holding Register) configuration.

Sources: `configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:85-127`, `configs/tested-cfgs/SM7_QV100/gpgpusim.config:139-178`

### 2.7 Interconnection Network Configuration

GPGPU-Sim supports two modes for the interconnection network:

  1. Built-in local crossbar (mode 2):
[code] -network_mode 2
         -icnt_in_buffer_limit 512
         -icnt_out_buffer_limit 512
         -icnt_subnets 2
         -icnt_flit_size 40
         -icnt_arbiter_algo 1
         
[/code]

  2. Detailed network simulation using a separate configuration file (mode 1):
[code] -network_mode 1 
         -inter_config_file config_volta_islip.icnt
         
[/code]




The detailed configuration file (`config_volta_islip.icnt`) defines parameters such as topology (e.g., butterfly, mesh), routing algorithm, virtual channels, and flow control.

Sources: `configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:130-137`, `configs/tested-cfgs/SM7_QV100/gpgpusim.config:181-190`, `configs/tested-cfgs/SM7_QV100/config_volta_islip.icnt`

### 2.8 DRAM Configuration

These parameters control the DRAM model:

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_dram_scheduler`| DRAM scheduler algorithm| `1` (FR-FCFS)  
`-gpgpu_frfcfs_dram_sched_queue_size`| Size of DRAM scheduler queue| `64`  
`-gpgpu_dram_return_queue_size`| Size of DRAM return queue| `192`  
`-gpgpu_n_mem_per_ctrlr`| Number of memory chips per controller| `1`  
`-gpgpu_dram_buswidth`| DRAM bus width in bytes| `2` or `16`  
`-gpgpu_dram_burst_length`| DRAM burst length| `16` or `2`  
`-dram_data_command_freq_ratio`| Ratio of data to command frequency| `4` (GDDR6) or `2` (HBM)  
  
DRAM timing parameters are specified in a single string:
[code] 
    -gpgpu_dram_timing_opt "nbk=16:CCD=4:RRD=12:RCD=24:RAS=55:RP=24:RC=78:CL=24:WL=8:CDLR=10:WR=24:nbkgrp=4:CCDL=6:RTPL=4"
    
[/code]

Sources: `configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:142-163`, `configs/tested-cfgs/SM7_QV100/gpgpusim.config:196-223`

### 2.9 Statistics and Visualization

These parameters control statistics collection and visualization:

Parameter| Description| Example Value  
---|---|---  
`-gpgpu_memlatency_stat`| Memory latency statistics level| `14`  
`-gpgpu_runtime_stat`| Runtime statistics collection interval| `500`  
`-enable_ptx_file_line_stats`| Enable PTX file/line statistics| `1`  
`-visualizer_enabled`| Enable visualizer| `0`  
`-trace_enabled`| Enable trace collection| `0`  
  
Sources: `configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:167-179`, `configs/tested-cfgs/SM7_QV100/gpgpusim.config:228-237`

## 3\. GPU Architecture Configurations

GPGPU-Sim includes pre-configured files for various NVIDIA GPU architectures. These configurations are based on public information about these GPUs and have been validated against real hardware.

### 3.1 Available GPU Configurations

Configuration| Architecture| Represented GPU  
---|---|---  
SM2_GTX480| Fermi| NVIDIA GTX 480  
SM3_KEPLER_TITAN| Kepler| NVIDIA TITAN (Kepler)  
SM6_TITANX| Pascal| NVIDIA TITAN X (Pascal)  
SM7_QV100| Volta| NVIDIA Quadro V100  
SM7_TITANV| Volta| NVIDIA TITAN V  
SM75_RTX2060| Turing| NVIDIA RTX 2060  
SM75_RTX2060_S| Turing| NVIDIA RTX 2060 Super  
SM86_RTX3070| Ampere| NVIDIA RTX 3070  
  
Each configuration file includes detailed comments with references to white papers and other technical documents used to derive the parameters.
[/code]
[code] 
Sources: `configs/tested-cfgs/SM2_GTX480/gpgpusim.config`, `configs/tested-cfgs/SM3_KEPLER_TITAN/gpgpusim.config`, `configs/tested-cfgs/SM6_TITANX/gpgpusim.config`, `configs/tested-cfgs/SM7_QV100/gpgpusim.config`, `configs/tested-cfgs/SM7_TITANV/gpgpusim.config`, `configs/tested-cfgs/SM75_RTX2060/gpgpusim.config`, `configs/tested-cfgs/SM75_RTX2060_S/gpgpusim.config`, `configs/tested-cfgs/SM86_RTX3070/gpgpusim.config`

### 3.2 Key Architecture Differences

Different GPU architectures have significant differences in their configurations:

Parameter| Fermi (GTX480)| Volta (V100)| Ampere (RTX3070)  
---|---|---|---  
SMs| 15| 80| 46  
Shader Model| SM 2.0| SM 7.0| SM 8.6  
Warp Scheduler Design| 2 per SM| 4 per SM| 4 per SM  
SP Units per SM| 2| 4| 4  
Memory Type| GDDR5| HBM2| GDDR6  
L1 Cache Design| Configurable L1/Shared| Unified L1D| Unified L1D  
Tensor Cores| No| Yes| Yes  
Sub-Core Model| No| Yes| Yes  
  
Sources: `configs/tested-cfgs/SM2_GTX480/gpgpusim.config`, `configs/tested-cfgs/SM7_QV100/gpgpusim.config`, `configs/tested-cfgs/SM86_RTX3070/gpgpusim.config`

## 4\. Testing Framework

GPGPU-Sim includes a comprehensive testing framework to validate the correctness of the simulator across different GPU configurations.

### 4.1 Continuous Integration

GPGPU-Sim uses GitHub Actions for continuous integration testing. The CI workflow runs a set of short functional tests across different GPU configurations:
[/code]
[code] 
Sources: `.github/workflows/main.yml`, `.github/workflows/accelsim.yml`

### 4.2 Test Scripts

The testing framework uses several shell scripts:

  1. `short-tests.sh`: Builds GPGPU-Sim and runs short functional tests using the Rodinia benchmark suite.
  2. `short-tests-cmake.sh`: Similar to the above but uses the CMake build system.
  3. `short-tests-accelsim.sh`: Tests integration with the Accel-Sim framework.



The test scripts perform the following steps:

  1. Set up the environment
  2. Build GPGPU-Sim
  3. Clone the Accel-Sim framework
  4. Run simulations with selected benchmarks
  5. Monitor and validate the results



Example usage:
[/code]
[code] 
Sources: `short-tests.sh`, `short-tests-cmake.sh`, `short-tests-accelsim.sh`

### 4.3 Testing with Different Architectures

The CI system tests multiple GPU configurations in parallel:

Test Job| Configuration| Note  
---|---|---  
`build-TITANV`| TITANV| Volta architecture with default network  
`build-TITANV-LOCALXBAR`| TITANV-LOCALXBAR| Volta with simplified local crossbar network  
`build-QV100`| QV100| Quadro V100 (professional Volta)  
`build-2060`| RTX2060| Consumer Turing architecture  
`build-3070`| RTX3070| Consumer Ampere architecture  
  
Sources: `.github/workflows/main.yml:16-86`

### 4.4 Integration with Accel-Sim

GPGPU-Sim can also be tested in integration with the Accel-Sim framework, which provides additional validation tools and trace-driven simulation capabilities:
[/code]
[code] 
The Accel-Sim integration tests use pre-generated traces from real GPUs to validate the simulator's behavior.

Sources: `short-tests-accelsim.sh`, `.github/workflows/accelsim.yml`

## 5\. Best Practices for Configuration and Testing

### 5.1 Configuration File Management

When working with configuration files:

  1. **Start with an existing configuration** : Begin with the closest matching GPU configuration file from the `configs/tested-cfgs/` directory.
  2. **Document changes** : Add comments explaining any modifications from the baseline configuration.
  3. **Parameter sensitivity** : Some parameters have significant impact on simulation results (e.g., cache sizes, warp scheduler policy). Test these systematically.
  4. **Check for consistency** : Ensure that interdependent parameters are modified together (e.g., when changing memory system parameters).



### 5.2 Running Regression Tests

To ensure your changes don't break existing functionality:

  1. Run the short tests before submitting changes:


[/code]
[code]   2. For more thorough testing, run across multiple configurations:


[/code]
[code]   3. Use `.gitignore` to prevent adding temporary files generated during testing:


[code] 
    *~
    *.swp
    lib/*
    build/*
    
[/code]

Sources: `.gitignore`

### 5.3 Common Configuration Issues

When configuring the simulator, watch out for these common issues:

  1. **Mismatched compute capability** : Ensure that `-gpgpu_ptx_force_max_capability` matches the targeted architecture.
  2. **Incorrect cache configuration** : Cache configuration strings have a complex format and parsing errors can be hard to debug.
  3. **DRAM timing parameters** : DRAM timing parameters must be consistent with the memory type (GDDR5/6 vs. HBM).
  4. **Interconnection network** : Using `-network_mode 1` requires a properly configured `.icnt` file.



Sources: `configs/tested-cfgs/SM7_QV100/gpgpusim.config:41-44`, `configs/tested-cfgs/SM75_RTX2060/gpgpusim.config:85-96`

## 6\. Conclusion

The configuration and testing system in GPGPU-Sim provides a flexible framework for simulating various GPU architectures with different levels of detail. By following the guidelines in this document, users can create accurate GPU models, validate their configurations through testing, and contribute to the ongoing development of the simulator.

For details about specific simulator components, please refer to the other wiki pages:

  * For shader core simulation, see [Shader Core Simulation](/gpgpu-sim/gpgpu-sim_distribution/2.1-shader-core-simulation)
  * For memory system details, see [Memory System](/gpgpu-sim/gpgpu-sim_distribution/2.3-memory-system)
  * For execution model, see [Execution Model and Thread Management](/gpgpu-sim/gpgpu-sim_distribution/2.4-execution-model-and-thread-management)



