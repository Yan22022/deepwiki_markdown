---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/3.3-device-runtime-for-cuda-dynamic-parallelism
crawled_at: 2025-06-03T19:42:34.227583
---



# Device Runtime for CUDA Dynamic Parallelism

Relevant source files

  * [src/cuda-sim/cuda_device_runtime.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda_device_runtime.cc)
  * [src/cuda-sim/cuda_device_runtime.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda_device_runtime.h)



## Overview

This document describes the implementation of CUDA Dynamic Parallelism (CDP) in GPGPU-Sim. CDP is a feature introduced in CUDA 5.0 that allows CUDA kernels to launch new kernels directly from the GPU without CPU involvement. This capability is essential for implementing recursive algorithms and dynamic workload distribution entirely on the GPU.

The CDP implementation in GPGPU-Sim provides the necessary device runtime APIs and supporting infrastructure to enable kernel launches from within device code, stream management at the device level, and parameter passing between parent and child kernels.

For information about the general CUDA Runtime API implementation, see [CUDA Runtime API](/gpgpu-sim/gpgpu-sim_distribution/3.1-cuda-runtime-api).

## Core Components

The CDP implementation centers around the `cuda_device_runtime` class that manages device-side kernel launches and the associated data structures.
[/code]
[code] 
Key components include:

  1. **`device_launch_config_t`** : Stores the launch configuration for a child kernel, including grid dimensions, block dimensions, shared memory size, and a pointer to the kernel function.

  2. **`device_launch_operation_t`** : Represents a queued child kernel launch operation with a reference to the child grid and the stream it will execute on.

  3. **`cuda_device_runtime` state tracking**:

     * `g_cuda_device_launch_param_map`: Maps parameter buffers to their associated launch configurations
     * `g_cuda_device_launch_op`: Maintains a queue of pending child kernel launches
     * `g_total_param_size` and `g_max_total_param_size`: Track parameter buffer memory usage



Sources: [src/cuda-sim/cuda_device_runtime.h5-31](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda_device_runtime.h#L5-L31) [src/cuda-sim/cuda_device_runtime.h35-66](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda_device_runtime.h#L35-L66)

## Device Runtime API Implementation

GPGPU-Sim implements three key device runtime APIs for CDP support:

### 1\. `cudaGetParameterBufferV2`

This function allocates a parameter buffer in global memory where arguments for a child kernel can be stored. It's called by device code before launching a child kernel.

The implementation:

  1. Extracts the function pointer, grid dimensions, block dimensions, and shared memory size for the child kernel
  2. Allocates a buffer in global memory sized to fit all kernel arguments
  3. Associates the buffer with the launch configuration in `g_cuda_device_launch_param_map`
  4. Returns the buffer address to the caller



### 2\. `cudaLaunchDeviceV2`

This function launches a child kernel using a previously allocated parameter buffer. The implementation:

  1. Retrieves the parameter buffer and target stream
  2. Retrieves the launch configuration associated with the buffer
  3. Creates a new `kernel_info_t` for the child kernel
  4. Sets up parent-child kernel relationships
  5. Copies kernel arguments from the parameter buffer to the child kernel's parameter memory
  6. Queues the launch operation



### 3\. `cudaStreamCreateWithFlags`

This function creates a new stream from within device code to allow asynchronous execution of child kernels. The implementation:

  1. Creates a new stream for the current CTA (Cooperative Thread Array)
  2. Writes the stream pointer back to the caller-provided address
  3. Returns success code



Sources: [src/cuda-sim/cuda_device_runtime.cc29-107](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda_device_runtime.cc#L29-L107) [src/cuda-sim/cuda_device_runtime.cc111-245](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda_device_runtime.cc#L111-L245) [src/cuda-sim/cuda_device_runtime.cc250-309](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda_device_runtime.cc#L250-L309)

## Child Kernel Launch Process

The diagram below illustrates the complete flow of a child kernel launch through CDP:
[/code]
[code] 
When executing child kernel launches:

  1. Queued launch operations are stored in `g_cuda_device_launch_op`
  2. The `launch_one_device_kernel()` function processes these operations one by one
  3. Each operation is converted to a `stream_operation` and handed to the stream manager
  4. Child kernels execute in the context of their parent kernel



Sources: [src/cuda-sim/cuda_device_runtime.cc311-326](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda_device_runtime.cc#L311-L326)

## Parameter Buffer Management

Parameter buffers are a critical part of the CDP implementation:
[/code]
[code] 
Key aspects of parameter buffer management:

  * Parameter buffers are allocated in global memory
  * The system tracks total parameter memory usage through `g_total_param_size`
  * Parameter buffers are freed implicitly when a child kernel is launched
  * Launch configurations are indexed by parameter buffer address



Sources: [src/cuda-sim/cuda_device_runtime.cc78-86](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda_device_runtime.cc#L78-L86) [src/cuda-sim/cuda_device_runtime.cc196-204](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda_device_runtime.cc#L196-L204) [src/cuda-sim/cuda_device_runtime.cc230-231](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda_device_runtime.cc#L230-L231)

## Device-Side Stream Management

CDP allows for stream creation and management directly from device code:
[/code]
[code] 
Key points about stream management:

  * Each CTA within a parent kernel can create its own streams
  * Each CTA also has a default stream
  * Streams are managed at the CTA level
  * Child kernels inherit the execution context of their parent kernel
  * Each stream exists in the scope of its creating CTA and handles asynchronous execution



Sources: [src/cuda-sim/cuda_device_runtime.cc290-295](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda_device_runtime.cc#L290-L295) [src/cuda-sim/cuda_device_runtime.cc211-226](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda_device_runtime.cc#L211-L226)

## Integration with GPGPU-Sim

The CDP implementation integrates with the broader GPGPU-Sim infrastructure:

Component| Interaction with CDP  
---|---  
Stream Manager| Receives child kernel launch operations via `stream_operation` objects  
Memory System| Provides global memory for parameter buffers  
CUDA Simulator| Executes the device runtime API functions during simulation  
PTX Parser| Performs PDOM analysis for child kernel functions  
Kernel Execution| Child kernels are created as `kernel_info_t` objects with parent-child relationships  
  
The CDP support is conditionally compiled based on the CUDA version, requiring CUDA 5.0 or later:
[code] 
    #if (CUDART_VERSION >= 5000)
    // CDP implementation
    #endif
    
[/code]

Sources: [src/cuda-sim/cuda_device_runtime.cc7-8](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda_device_runtime.cc#L7-L8) [src/cuda-sim/cuda_device_runtime.cc156-170](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda_device_runtime.cc#L156-L170) [src/cuda-sim/cuda_device_runtime.cc315-318](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda_device_runtime.cc#L315-L318)

## Performance Considerations

While not explicitly implemented in the current code, the CDP model includes configuration parameters for modeling launch latencies:

  * `g_kernel_launch_latency`: Could be used to model the latency of a child kernel launch
  * `g_TB_launch_latency`: Could be used to model the latency of launching a thread block



These parameters would allow for more accurate simulation of CDP overhead in real GPU hardware.

Sources: [src/cuda-sim/cuda_device_runtime.h45-46](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda_device_runtime.h#L45-L46)

