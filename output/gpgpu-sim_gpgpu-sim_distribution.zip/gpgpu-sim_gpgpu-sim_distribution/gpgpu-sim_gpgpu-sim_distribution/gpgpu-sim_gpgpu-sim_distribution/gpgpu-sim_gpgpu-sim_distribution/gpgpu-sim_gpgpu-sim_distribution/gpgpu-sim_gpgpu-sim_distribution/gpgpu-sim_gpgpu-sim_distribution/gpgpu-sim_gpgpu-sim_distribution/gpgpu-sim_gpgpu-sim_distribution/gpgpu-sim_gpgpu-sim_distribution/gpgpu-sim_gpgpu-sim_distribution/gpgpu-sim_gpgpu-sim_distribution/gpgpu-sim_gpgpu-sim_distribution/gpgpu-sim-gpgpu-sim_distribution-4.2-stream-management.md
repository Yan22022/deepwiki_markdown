---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/4.2-stream-management
crawled_at: 2025-06-03T19:42:25.226149
---



# Stream Management

Relevant source files

  * [src/cuda-sim/cuda-sim.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda-sim.h)
  * [src/debug.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/debug.cc)
  * [src/debug.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/debug.h)
  * [src/gpgpusim_entrypoint.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc)
  * [src/gpgpusim_entrypoint.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.h)
  * [src/stream_manager.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc)
  * [src/stream_manager.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h)



## Purpose and Scope

This document describes the stream management subsystem in GPGPU-Sim, which is responsible for handling CUDA/OpenCL streams and the operations queued within them. Streams are a core component that enables asynchronous execution in GPU applications, allowing operations like kernel launches and memory transfers to be queued for execution while the CPU continues with other tasks. The stream management system bridges the gap between the runtime APIs (see [API Runtime and Interfaces](/gpgpu-sim/gpgpu-sim_distribution/3-api-runtime-and-interfaces)) and the GPU simulation core, managing the queuing, scheduling, and execution of operations in a way that respects stream dependencies and synchronization.

## Stream Architecture

GPGPU-Sim implements streams as queues of operations that follow the CUDA/OpenCL stream abstraction. Each stream maintains an ordered sequence of operations that execute in FIFO order, with operations from different streams potentially executing concurrently.
[/code]
[code] 
**Diagram: Stream Management Class Structure**

Sources: [src/stream_manager.h29-282](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h#L29-L282) [src/stream_manager.cc1-510](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L1-L510)

### Stream Representation

Each stream in GPGPU-Sim is represented by the `CUstream_st` class, which maintains:

  * A unique identifier (`m_uid`)
  * A list of operations to be executed (`m_operations`)
  * A flag indicating if an operation is currently in progress (`m_pending`)
  * Thread synchronization primitives to ensure thread safety (`m_lock`)



Stream operations are queued to a stream and executed sequentially, with the potential for operations from different streams to execute concurrently.

Sources: [src/stream_manager.h225-248](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h#L225-L248) [src/stream_manager.cc36-122](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L36-L122)

### Stream Operations

Operations within a stream are represented by the `stream_operation` class, which can represent:

Operation Type| Description  
---|---  
`stream_memcpy_host_to_device`| Copy data from host memory to device memory  
`stream_memcpy_device_to_host`| Copy data from device memory to host memory  
`stream_memcpy_device_to_device`| Copy data between two device memory locations  
`stream_memcpy_to_symbol`| Copy data from host memory to a device symbol  
`stream_memcpy_from_symbol`| Copy data from a device symbol to host memory  
`stream_kernel_launch`| Launch a GPU kernel  
`stream_event`| Record an event in the stream  
`stream_wait_event`| Make the stream wait for an event to complete  
  
Each operation carries the necessary data (addresses, sizes, kernel pointers) to perform its function when scheduled by the simulator.

Sources: [src/stream_manager.h84-224](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h#L84-L224) [src/stream_manager.cc124-247](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L124-L247)

## Stream Manager

The `stream_manager` class is the central component that manages all streams and orchestrates the execution of operations. It maintains:

  * A list of active streams (`m_streams`)
  * The default stream (`m_stream_zero`)
  * A mapping from kernel grid IDs to their respective streams (`m_grid_id_to_stream`)
  * Synchronization mechanisms for thread safety


[/code]
[code] 
**Diagram: Stream Manager Operation Flow**

Sources: [src/stream_manager.cc249-456](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L249-L456)

### Operation Scheduling

The stream manager schedules operations from streams using a round-robin approach, with special priority given to the default stream (stream zero). This is implemented in the `front()` method of the `stream_manager` class:

  1. First, it checks if the default stream has operations and schedules from there
  2. If the default stream is empty or busy, it moves to the next available stream
  3. It continues this process, ensuring fair distribution of execution time among streams



The scheduling logic also handles operations that require specific conditions to execute (e.g., kernels that need to wait for resources).

Sources: [src/stream_manager.cc344-384](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L344-L384)

### Operation Execution

When an operation is scheduled, the `operation()` method in `stream_manager` calls `do_operation()` on the selected stream operation. The operation execution:

  1. Performs the requested action (memory transfer, kernel launch, etc.)
  2. Updates the stream state to mark the operation as completed
  3. Handles any callbacks or synchronization required



For kernel launches, the system registers the grid UID with the stream manager, allowing it to track when kernels complete and notify the appropriate stream.

Sources: [src/stream_manager.cc124-215](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L124-L215) [src/stream_manager.cc257-275](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L257-L275)

## Integration with Simulation

The stream management system integrates with the GPGPU-Sim core through the simulation thread, which processes stream operations and advances the GPU simulation.
[/code]
[code] 
**Diagram: Stream Execution and Simulation Integration**

Sources: [src/gpgpusim_entrypoint.cc91-185](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L91-L185) [src/stream_manager.cc276-314](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L276-L314)

### Simulation Thread Control

GPGPU-Sim can operate in two modes for simulation thread control:

  1. **Sequential Mode** : Simulates one kernel at a time, completing the entire simulation of a kernel before moving to the next
  2. **Concurrent Mode** : Simulates kernel executions concurrently, allowing for interleaved execution of operations from different streams



The simulation thread (`gpgpu_sim_thread_sequential` or `gpgpu_sim_thread_concurrent`) continuously checks for operations to execute and advances the GPU simulation accordingly.

Sources: [src/gpgpusim_entrypoint.cc61-185](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L61-L185)

### Synchronization

Synchronization between the host and GPU simulation is handled through several mechanisms:

  * The `synchronize()` method in `CUstream_st` blocks until all operations in the stream are complete
  * The `synchronize()` method in `gpgpu_context` waits for all streams to become inactive
  * Event operations can be used to synchronize between streams



When CUDA launch blocking is enabled (`m_cuda_launch_blocking`), the stream manager blocks after pushing an operation until all operations complete, simulating synchronous behavior.

Sources: [src/stream_manager.cc67-75](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L67-L75) [src/gpgpusim_entrypoint.cc256-293](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L256-L293) [src/stream_manager.cc457-500](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L457-L500)

## Implementation Details

### Thread Safety

The stream management system uses various synchronization primitives to ensure thread safety:

  * Each stream has its own mutex lock to protect operation list access
  * The stream manager has a global lock to protect stream list modifications
  * Semaphores control the simulation thread execution



These mechanisms ensure that concurrent access from the host application and simulation thread doesn't lead to race conditions.

Sources: [src/stream_manager.h246-247](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h#L246-L247) [src/stream_manager.h278-279](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h#L278-L279) [src/gpgpusim_entrypoint.h58-60](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.h#L58-L60)

### Stream Creation and Destruction

Streams can be dynamically created and destroyed during simulation:

  * `add_stream()` adds a new stream to the manager's list of streams
  * `destroy_stream()` removes a stream, ensuring it has completed all operations first



The default stream (stream zero) is always available and has special handling in the scheduler.

Sources: [src/stream_manager.cc386-408](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L386-L408)

### Handling Stream Termination

When the simulation needs to stop (e.g., due to reaching instruction limits), the stream manager provides a `stop_all_running_kernels()` method that:

  1. Identifies all running kernels
  2. Signals the GPU to stop them
  3. Cleans up the associated streams
  4. Prints statistics for the terminated streams



This ensures a clean shutdown of the simulation.

Sources: [src/stream_manager.cc316-342](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L316-L342)

## Usage Example

In the context of GPGPU-Sim, stream management is primarily used internally by the runtime API implementations. When a CUDA or OpenCL application makes API calls like `cudaMemcpy` or `cudaLaunchKernel`, these are translated into stream operations and pushed to the appropriate stream.

For example, when a CUDA kernel is launched:

  1. The runtime API creates a `kernel_info_t` object
  2. A `stream_operation` of type `stream_kernel_launch` is created
  3. This operation is pushed to the specified stream (or default stream)
  4. The simulation thread eventually executes this operation, launching the kernel in the GPU simulator



The system handles the dependencies and synchronization automatically, reflecting the semantics of CUDA/OpenCL streams.

Sources: [src/stream_manager.cc162-191](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L162-L191)

