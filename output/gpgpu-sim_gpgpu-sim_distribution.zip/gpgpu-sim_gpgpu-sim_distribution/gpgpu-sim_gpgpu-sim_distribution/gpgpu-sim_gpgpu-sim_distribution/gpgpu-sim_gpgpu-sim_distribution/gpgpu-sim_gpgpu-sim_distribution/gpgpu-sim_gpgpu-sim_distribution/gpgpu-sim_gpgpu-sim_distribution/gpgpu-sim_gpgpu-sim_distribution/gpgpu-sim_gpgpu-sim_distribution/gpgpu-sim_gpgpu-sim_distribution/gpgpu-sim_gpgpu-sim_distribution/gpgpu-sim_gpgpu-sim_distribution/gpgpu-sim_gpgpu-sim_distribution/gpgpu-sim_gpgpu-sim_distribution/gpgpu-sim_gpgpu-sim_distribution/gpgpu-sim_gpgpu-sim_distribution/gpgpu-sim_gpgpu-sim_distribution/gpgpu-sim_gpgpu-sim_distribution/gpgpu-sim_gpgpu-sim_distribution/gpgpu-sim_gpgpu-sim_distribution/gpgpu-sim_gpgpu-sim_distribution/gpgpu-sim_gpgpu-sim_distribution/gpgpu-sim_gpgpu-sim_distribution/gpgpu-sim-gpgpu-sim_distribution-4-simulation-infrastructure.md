---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/4-simulation-infrastructure
crawled_at: 2025-06-03T19:42:43.177640
---



# Simulation Infrastructure

Relevant source files

  * [src/cuda-sim/cuda-sim.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda-sim.h)
  * [src/debug.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/debug.cc)
  * [src/debug.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/debug.h)
  * [src/gpgpu-sim/icnt_wrapper.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/icnt_wrapper.cc)
  * [src/gpgpu-sim/icnt_wrapper.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/icnt_wrapper.h)
  * [src/gpgpu-sim/local_interconnect.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/local_interconnect.cc)
  * [src/gpgpu-sim/local_interconnect.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/local_interconnect.h)
  * [src/gpgpusim_entrypoint.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc)
  * [src/gpgpusim_entrypoint.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.h)
  * [src/stream_manager.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc)
  * [src/stream_manager.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h)



This document provides an overview of the simulation infrastructure in GPGPU-Sim, which forms the core execution framework for the simulator. This infrastructure manages the simulation execution flow, coordinates between different components, and maintains the overall state of the simulation.

For details about specific simulation components, please see [Core Simulation Components](/gpgpu-sim/gpgpu-sim_distribution/2-core-simulation-components). For information about CUDA/OpenCL runtime API implementation, refer to [API Runtime and Interfaces](/gpgpu-sim/gpgpu-sim_distribution/3-api-runtime-and-interfaces).

## Simulation Infrastructure Overview

The GPGPU-Sim simulation infrastructure consists of several interrelated components that work together to enable the cycle-accurate simulation of GPU execution. These components include:

  1. **GPGPUsim Context** : Maintains the global state of the simulator
  2. **Simulation Entry Point** : Controls initialization and manages simulation threads
  3. **Stream Management** : Handles CUDA/OpenCL streams and operation scheduling
  4. **Interconnect Simulation** : Models the on-chip network connecting cores and memory
  5. **Debugging Support** : Provides interactive debugging capabilities



These components collectively provide the foundation upon which the detailed microarchitecture simulation occurs.
[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.h40-76](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.h#L40-L76) [src/gpgpusim_entrypoint.cc29-39](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L29-L39) [src/stream_manager.h250-280](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h#L250-L280)

## GPGPUsim Context

The `GPGPUsim_ctx` class serves as the central repository for simulator state, holding references to all major components. It maintains the simulation threads, semaphores for synchronization, and references to the GPU model, stream manager, and configuration.
[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.h40-76](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.h#L40-L76) [src/gpgpusim_entrypoint.cc256-340](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L256-L340)

## Simulation Threads and Execution Flow

GPGPU-Sim supports two simulation execution modes:

  1. **Sequential Mode** : Executes one kernel at a time, appropriate for simpler workloads
  2. **Concurrent Mode** : Supports multiple concurrent kernels, used for modern workloads with multiple concurrent CUDA streams



The execution flow varies depending on mode but generally involves initializing the GPU, executing operations from the stream manager, and cycling the simulation until completion.
[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.cc61-185](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L61-L185) [src/gpgpusim_entrypoint.cc347-364](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L347-L364)

The simulation threads implement the core simulation loop, where the simulator:

  1. Initializes the GPU model
  2. Requests operations from the stream manager
  3. Performs cycle-accurate simulation of shader cores and memory system
  4. Checks for completion of kernels and other operations
  5. Collects and reports statistics



### Sequential Simulation Thread

The sequential simulation thread (`gpgpu_sim_thread_sequential`) executes one kernel at a time:
[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.cc61-84](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L61-L84)

### Concurrent Simulation Thread

The concurrent simulation thread (`gpgpu_sim_thread_concurrent`) supports multiple concurrent kernels:
[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.cc91-185](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L91-L185)

## Stream Management

The Stream Manager is a critical component that schedules and manages operations on GPU streams. It maintains multiple streams (CUDA streams), each containing a queue of operations to be executed on the GPU.
[/code]
[code] 
Sources: [src/stream_manager.h95-224](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h#L95-L224) [src/stream_manager.h225-248](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h#L225-L248) [src/stream_manager.h250-280](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h#L250-L280)

### Stream Operation Types

The Stream Manager handles several types of operations:

Operation Type| Description  
---|---  
`stream_kernel_launch`| Launches a GPU kernel for execution  
`stream_memcpy_host_to_device`| Copies data from host to device memory  
`stream_memcpy_device_to_host`| Copies data from device to host memory  
`stream_memcpy_device_to_device`| Copies data between device memory locations  
`stream_memcpy_to_symbol`| Copies data to a device symbol  
`stream_memcpy_from_symbol`| Copies data from a device symbol  
`stream_event`| Records an event in the stream  
`stream_wait_event`| Waits for an event to complete  
  
Sources: [src/stream_manager.h84-94](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h#L84-L94) [src/stream_manager.cc124-215](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L124-L215)

### Stream Operation Flow

The Stream Manager follows this process to execute operations:

  1. Operations are pushed to streams via the `push` method
  2. The simulation thread calls the `operation` method to execute the next operation
  3. The `operation` method selects the next operation using a scheduling policy
  4. The operation is executed via `do_operation` method
  5. For kernel operations, the kernel is launched on the GPU
  6. The GPU model notifies the Stream Manager when kernels complete
  7. The Stream Manager removes completed operations from streams



Sources: [src/stream_manager.cc249-500](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L249-L500)

## Interconnect Simulation

The interconnect simulation models the on-chip network that connects shader cores with memory partitions. GPGPU-Sim supports two interconnect models:

  1. **Local Crossbar (XBAR)** : A simpler crossbar-based interconnect model
  2. **Intersim2** : A detailed cycle-accurate network-on-chip simulator



These models are abstracted behind a common interface in the `icnt_wrapper` module.
[/code]
[code] 
Sources: [src/gpgpu-sim/icnt_wrapper.h34-68](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/icnt_wrapper.h#L34-L68) [src/gpgpu-sim/icnt_wrapper.cc35-198](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/icnt_wrapper.cc#L35-L198)

### LocalInterconnect Architecture

The `LocalInterconnect` class implements a crossbar-based interconnect model with two subnets:

  1. **Request Network** : Carries requests from shader cores to memory
  2. **Reply Network** : Carries responses from memory back to shader cores



Each subnet is implemented as an `xbar_router` that models contention and arbitrates access to outputs.
[/code]
[code] 
Sources: [src/gpgpu-sim/local_interconnect.h52-107](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/local_interconnect.h#L52-L107) [src/gpgpu-sim/local_interconnect.h110-137](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/local_interconnect.h#L110-L137) [src/gpgpu-sim/local_interconnect.cc294-432](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/local_interconnect.cc#L294-L432)

### Interconnect Wrapper

The `icnt_wrapper` module provides a common interface to different interconnect models. It defines function pointers for operations like `icnt_push`, `icnt_pop`, and `icnt_transfer`, which are bound to the appropriate model at initialization.

Sources: [src/gpgpu-sim/icnt_wrapper.h34-68](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/icnt_wrapper.h#L34-L68) [src/gpgpu-sim/icnt_wrapper.cc138-198](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/icnt_wrapper.cc#L138-L198)

## Debugging Support

GPGPU-Sim includes an interactive debugging infrastructure that allows examination of the simulation state, setting breakpoints, and inspecting memory. The debugger can be used to:

  1. Set breakpoints at specific PTX instructions
  2. Set watchpoints for memory locations
  3. Display pipeline state
  4. Single-step through simulation


[/code]
[code] 
Sources: [src/debug.h29-86](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/debug.h#L29-L86) [src/debug.cc47-218](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/debug.cc#L47-L218)

## Simulation Statistics and Timing

GPGPU-Sim collects and reports detailed statistics about the execution, including:

  1. Total simulation time
  2. Simulation rate (instructions/sec)
  3. Simulation rate (cycles/sec)
  4. Silicon slowdown factor (compared to real hardware)



The `print_simulation_time` method calculates and displays these metrics:
[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.cc366-393](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L366-L393)

## Summary

The simulation infrastructure in GPGPU-Sim provides the foundation for the cycle-accurate simulation of GPU architectures. It manages the execution flow, coordinates between components, and maintains the overall simulation state. The key components include:

  1. **GPGPUsim Context** : Central repository for simulation state
  2. **Simulation Threads** : Manage cycle-by-cycle execution
  3. **Stream Manager** : Schedules and manages operations on streams
  4. **Interconnect Simulation** : Models on-chip network communication
  5. **Debugging Support** : Provides interactive debugging capabilities



These components work together to enable detailed, cycle-accurate simulation of CUDA and OpenCL applications on a variety of GPU architectures.

For more details on specific aspects of the simulation infrastructure, please refer to:

  * [Entry Point and Initialization](/gpgpu-sim/gpgpu-sim_distribution/4.1-entry-point-and-initialization)
  * [Stream Management](/gpgpu-sim/gpgpu-sim_distribution/4.2-stream-management)
  * [Interconnect Simulation](/gpgpu-sim/gpgpu-sim_distribution/4.3-interconnect-simulation)
  * [Statistics Collection and Power Modeling](/gpgpu-sim/gpgpu-sim_distribution/4.4-statistics-collection-and-power-modeling)



