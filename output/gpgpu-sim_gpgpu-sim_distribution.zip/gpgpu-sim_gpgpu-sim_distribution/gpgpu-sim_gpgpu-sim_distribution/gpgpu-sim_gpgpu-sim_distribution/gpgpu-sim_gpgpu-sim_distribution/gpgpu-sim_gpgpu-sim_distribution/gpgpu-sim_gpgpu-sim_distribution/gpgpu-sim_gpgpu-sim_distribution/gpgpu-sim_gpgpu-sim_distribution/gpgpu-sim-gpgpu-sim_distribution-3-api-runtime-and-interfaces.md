---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/3-api-runtime-and-interfaces
crawled_at: 2025-06-03T19:42:15.622745
---



# API Runtime and Interfaces

Relevant source files

  * [.github/workflows/sst_integration.yml](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.github/workflows/sst_integration.yml)
  * [libcuda/cuda_api_object.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_api_object.h)
  * [libcuda/cuda_runtime_api.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc)
  * [libcuda/cuobjdump.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuobjdump.h)
  * [libcuda/cuobjdump.l](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuobjdump.l)
  * [libcuda/cuobjdump.y](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuobjdump.y)
  * [libcuda/gpgpu_context.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/gpgpu_context.h)
  * [libopencl/opencl_runtime_api.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc)
  * [src/cuda-sim/ptx_loader.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_loader.cc)
  * [src/cuda-sim/ptx_loader.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_loader.h)
  * [src/cuda-sim/ptxinfo.l](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptxinfo.l)
  * [src/cuda-sim/ptxinfo.y](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptxinfo.y)



This document describes the runtime API implementations and interfaces that allow applications written in CUDA and OpenCL to interact with the GPGPU-Sim simulator. It explains how the simulator intercepts and handles API calls from these applications to simulate their execution on a GPU. For information about the actual execution of PTX code, see [CUDA Simulation and PTX Execution](/gpgpu-sim/gpgpu-sim_distribution/2.2-cuda-simulation-and-ptx-execution).

## Architecture Overview

The API Runtime in GPGPU-Sim serves as a bridge between applications and the simulator core. It provides implementations of both CUDA and OpenCL APIs that mirror the behavior of their NVIDIA and OpenCL counterparts, allowing applications written for these APIs to run on the simulator without modification.
[/code]
[code] 
**API Runtime System Architecture**

Sources: [libcuda/cuda_runtime_api.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc) [libopencl/opencl_runtime_api.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc) [libcuda/gpgpu_context.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/gpgpu_context.h)

## API Components and Context

The API Runtime consists of several key components that work together to provide the CUDA and OpenCL interfaces. At the center of this system is the `gpgpu_context` class, which maintains the state of the simulation and provides access to the various components.
[/code]
[code] 
**Key API Classes and Relationships**

Sources: [libcuda/gpgpu_context.h11-84](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/gpgpu_context.h#L11-L84) [libcuda/cuda_api_object.h173-233](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_api_object.h#L173-L233) [libopencl/opencl_runtime_api.cc112-222](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L112-L222)

### Context Management

The simulation environment is managed through a singleton `gpgpu_context` object, which maintains all the necessary state for the simulation. This context is created by the `GPGPU_Context()` function and used throughout the simulator.
[/code]
[code] 
The `gpgpu_context` class contains pointers to various components of the simulator:

  * `api`: The CUDA runtime API implementation
  * `ptxinfo`: PTX information data
  * `ptx_parser`: PTX parser
  * `the_gpgpusim`: GPGPU simulation context
  * `func_sim`: Functional simulation component
  * `device_runtime`: CUDA device runtime
  * `stats`: PTX statistics



Sources: [libcuda/cuda_runtime_api.cc260-266](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L260-L266) [libcuda/gpgpu_context.h11-84](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/gpgpu_context.h#L11-L84)

## CUDA Runtime API

The CUDA Runtime API in GPGPU-Sim is implemented in `libcuda/cuda_runtime_api.cc`. It provides implementations of CUDA functions that intercept calls from CUDA applications and redirect them to the simulator.

### Execution Flow
[/code]
[code] 
**CUDA Kernel Launch Sequence**

Sources: [libcuda/cuda_runtime_api.cc524-982](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L524-L982)

### Key CUDA Runtime Functions

The CUDA Runtime API in GPGPU-Sim implements a wide range of CUDA functions. Here are some of the most important ones:

Function| Purpose| Implementation File  
---|---|---  
`cudaSetDeviceInternal`| Set the active CUDA device| cuda_runtime_api.cc  
`cudaGetDeviceInternal`| Get the current active CUDA device| cuda_runtime_api.cc  
`cudaRegisterFatBinaryInternal`| Register a CUDA fat binary (containing PTX code)| cuda_runtime_api.cc  
`cudaRegisterFunctionInternal`| Register a CUDA function| cuda_runtime_api.cc  
`cudaConfigureCallInternal`| Configure a kernel call (grid/block dimensions)| cuda_runtime_api.cc  
`cudaSetupArgumentInternal`| Set up arguments for a kernel call| cuda_runtime_api.cc  
`cudaLaunchInternal`| Launch a kernel| cuda_runtime_api.cc  
`cudaMemcpyInternal`| Copy memory between host and device| cuda_runtime_api.cc  
  
Sources: [libcuda/cuda_runtime_api.cc524-982](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L524-L982)

### Initialization and Device Management

The CUDA runtime in GPGPU-Sim initializes the simulator through the `GPGPUSim_Init()` function, which creates and initializes a GPGPU-Sim device. This function sets up the device properties based on the configuration parameters.
[/code]
[code] 
Sources: [libcuda/cuda_runtime_api.cc197-247](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L197-L247)

## OpenCL Runtime API

The OpenCL Runtime API in GPGPU-Sim is implemented in `libopencl/opencl_runtime_api.cc`. It provides an implementation of the OpenCL API that intercepts calls from OpenCL applications and redirects them to the simulator.

### OpenCL Objects

The OpenCL implementation in GPGPU-Sim includes several key classes that mirror the OpenCL API:

  * `_cl_context`: Represents an OpenCL context
  * `_cl_device_id`: Represents an OpenCL device
  * `_cl_command_queue`: Represents an OpenCL command queue
  * `_cl_mem`: Represents OpenCL memory objects
  * `_cl_program`: Represents an OpenCL program
  * `_cl_kernel`: Represents an OpenCL kernel


[/code]
[code] 
**OpenCL Object Relationships**

Sources: [libopencl/opencl_runtime_api.cc112-222](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L112-L222)

### OpenCL Program Processing

One of the key aspects of the OpenCL implementation is the conversion of OpenCL code to PTX for execution by the simulator. This is done through the `_cl_program::Build()` method, which compiles OpenCL code to PTX:

  1. The OpenCL source code is saved to a temporary file
  2. The NVIDIA OpenCL driver is invoked to compile the code to PTX
  3. The resulting PTX code is loaded into the simulator


[/code]
[code] 
Sources: [libopencl/opencl_runtime_api.cc438-599](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L438-L599)

## PTX and Code Extraction

GPGPU-Sim executes PTX (Parallel Thread Execution) code, which is NVIDIA's intermediate representation for GPU code. For CUDA applications, the PTX code is extracted from CUDA binaries. For OpenCL applications, the OpenCL code is compiled to PTX.

### PTX Extraction Flow
[/code]
[code] 
**PTX Extraction and Loading Process**

Sources: [libcuda/cuda_runtime_api.cc597-806](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L597-L806) [src/cuda-sim/ptx_loader.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_loader.cc)

### PTX Loader

The PTX loader is responsible for loading PTX code into the simulator. It can load PTX code from either a string or a file:

  * `gpgpu_ptx_sim_load_ptx_from_string`: Loads PTX code from a string
  * `gpgpu_ptx_sim_load_ptx_from_filename`: Loads PTX code from a file



The loader uses a PTX parser (`ptx_parser`) to parse the PTX code and build a symbol table, which is then used by the simulator to execute the code.
[/code]
[code] 
Sources: [src/cuda-sim/ptx_loader.cc169-203](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_loader.cc#L169-L203)

### CUOBJDUMP Utilities

The CUOBJDUMP utilities in GPGPU-Sim are used to extract PTX, ELF, and SASS code from CUDA binaries. These utilities are implemented in `libcuda/cuobjdump.y`, `libcuda/cuobjdump.l`, and `libcuda/cuobjdump.h`.

The main classes involved in this process are:

  * `cuobjdumpSection`: Base class for sections of code extracted from a CUDA binary
  * `cuobjdumpPTXSection`: Represents a PTX section
  * `cuobjdumpELFSection`: Represents an ELF section (which often includes SASS code)



The `cuda_runtime_api` class includes methods to extract code from CUDA binaries:

  * `cuobjdumpInit`: Initializes the CUOBJDUMP utilities
  * `extract_code_using_cuobjdump`: Extracts code from a CUDA binary
  * `extract_ptx_files_using_cuobjdump`: Extracts PTX files from a CUDA binary



Sources: [libcuda/cuobjdump.h18-79](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuobjdump.h#L18-L79) [libcuda/cuda_api_object.h173-233](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_api_object.h#L173-L233)

## Kernel Launch and Execution

The core functionality of the API runtime is to launch and execute kernels on the simulated GPU. This process involves several steps:

  1. Configure the kernel call with grid and block dimensions
  2. Set up the kernel arguments
  3. Launch the kernel
  4. Transfer control to the simulator
  5. Return results to the application



### CUDA Kernel Launch

In CUDA, the kernel launch process is split across several functions:

  1. `cudaConfigureCallInternal`: Sets up grid and block dimensions
  2. `cudaSetupArgumentInternal`: Sets up kernel arguments
  3. `cudaLaunchInternal`: Launches the kernel



The kernel configuration and arguments are stored in the `g_cuda_launch_stack` in the `cuda_runtime_api` class.
[/code]
[code] 
Sources: [libcuda/cuda_runtime_api.cc969-1043](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L969-L1043)

### OpenCL Kernel Launch

In OpenCL, the kernel launch process is managed through the `clEnqueueNDRangeKernel` function, which enqueues a kernel for execution. The kernel is represented by a `_cl_kernel` object, which contains the kernel function and its arguments.

The key steps in the OpenCL kernel launch are:

  1. Create a kernel object with `clCreateKernel`
  2. Set kernel arguments with `clSetKernelArg`
  3. Enqueue the kernel with `clEnqueueNDRangeKernel`


[/code]
[code] 
Sources: [libopencl/opencl_runtime_api.cc265-291](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L265-L291)

## Interface with Simulator Core

The API runtime interfaces with the simulator core through the `gpgpu_context` class, which provides access to the various components of the simulator:

  * `func_sim`: Handles functional simulation (executing PTX instructions)
  * `the_gpgpusim`: Manages the performance simulation (modeling GPU hardware)



### Simulator Initialization

The simulator is initialized through the `GPGPUSim_Init()` function, which creates and initializes a GPGPU-Sim device:
[/code]
[code] 
Sources: [libcuda/cuda_runtime_api.cc197-247](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L197-L247)

### Kernel Execution in the Simulator

When a kernel is launched, the API runtime creates a `kernel_info_t` object and passes it to the simulator:
[/code]
[code] 
The kernel is then executed by the simulator, which models the execution of each thread block on the simulated GPU cores.

Sources: [libcuda/cuda_runtime_api.cc1043-1060](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L1043-L1060) (This reference is notional since we don't have the exact line numbers for `gpgpu_cuda_ptx_sim_init_grid` implementation)

## Error Handling and Debugging

GPGPU-Sim provides several utilities for error handling and debugging:

  * `cuda_not_implemented`: Reports unimplemented CUDA functions
  * `gpgpusim_ptx_error_impl`: Reports PTX errors
  * `gpgpusim_ptx_assert_impl`: Asserts conditions in PTX code


[/code]
[code] 
Sources: [libcuda/cuda_runtime_api.cc288-298](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L288-L298)

## Summary

The API Runtime and Interfaces in GPGPU-Sim provide a critical link between applications and the simulator. By implementing the CUDA and OpenCL APIs, GPGPU-Sim allows applications written for these APIs to be run on the simulator without modification. The API implementations intercept calls from applications, extract and process PTX code, and redirect execution to the simulator core.

Key components of the API Runtime include:

  * CUDA Runtime API implementation
  * OpenCL Runtime API implementation
  * PTX Loader and Parser
  * CUOBJDUMP utilities for code extraction
  * Integration with the simulator core through the `gpgpu_context` class



Together, these components enable a seamless experience for developers, allowing them to simulate GPU execution of their applications with high fidelity.

