---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/1-overview
crawled_at: 2025-06-03T19:42:26.877667
---



# Overview

Relevant source files

  * [CHANGES](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/CHANGES)
  * [Makefile](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile)
  * [libcuda/cuda_api.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_api.h)
  * [linux-so-version.txt](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/linux-so-version.txt)
  * [setup_environment](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/setup_environment)
  * [src/abstract_hardware_model.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.cc)
  * [src/abstract_hardware_model.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h)
  * [src/gpgpu-sim/gpu-sim.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.cc)
  * [src/gpgpu-sim/gpu-sim.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h)
  * [src/gpgpu-sim/shader.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc)
  * [src/gpgpu-sim/shader.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h)
  * [version](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/version)
  * [version_detection.mk](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/version_detection.mk)



GPGPU-Sim is a detailed, cycle-accurate simulator designed to model the behavior and performance of modern Graphics Processing Units (GPUs) when running general-purpose computations through CUDA or OpenCL. This document provides a high-level introduction to the GPGPU-Sim architecture, its key components, and how they interact to form a complete GPU simulation environment.

This overview presents the fundamental concepts and architecture of GPGPU-Sim. For detailed information about specific components, refer to their respective dedicated wiki pages.

## Purpose and Scope

GPGPU-Sim serves multiple purposes:

  1. **Research Platform** : Enables computer architecture researchers to experiment with new GPU designs and evaluate their performance without needing hardware implementations
  2. **Educational Tool** : Helps students understand the complex internals of GPU architectures
  3. **Performance Analysis** : Allows developers to analyze the performance characteristics of their CUDA/OpenCL applications in detail



The simulator provides cycle-accurate modeling of GPU execution, memory hierarchy, interconnection networks, and power consumption. It supports multiple GPU architectures from Fermi through Ampere and can be configured to simulate different hardware configurations.

## System Architecture

GPGPU-Sim is structured as a multi-layer system that integrates with CUDA/OpenCL applications, providing both functional correctness and performance modeling.
[/code]
[code] 
Sources: [src/gpgpu-sim/gpu-sim.h32-711](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h#L32-L711) [src/gpgpu-sim/shader.h32-636](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L32-L636) [src/abstract_hardware_model.h32-645](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L32-L645)

### Front-End Components

The front-end of GPGPU-Sim interfaces with CUDA/OpenCL applications and provides the functional simulation:

  1. **Runtime API** : Implements the CUDA/OpenCL API functions, intercepting calls from applications and forwarding them to the simulator
  2. **PTX Parser/Interpreter** : Parses and interprets PTX (Parallel Thread Execution) code, NVIDIA's intermediate representation for CUDA programs
  3. **Functional Simulation** : Executes the PTX instructions to ensure functional correctness



### Back-End Components

The back-end focuses on cycle-accurate performance modeling:

  1. **Performance Model (gpu-sim)** : Coordinates the simulation of shader cores, memory system, and interconnection network
  2. **Shader Core Model (shader_core_ctx)** : Models the execution of warps in shader cores, including scheduling, pipeline stages, and execution units
  3. **Memory System** : Models the memory hierarchy, including caches, shared memory, and DRAM
  4. **Interconnection Network (intersim2)** : Models the on-chip network connecting shader cores to memory partitions



### Support Systems

Several supporting systems enhance the simulator:

  1. **Configuration System** : Allows detailed configuration of the simulated hardware
  2. **Statistics Collection** : Gathers performance metrics during simulation
  3. **Power Model (AccelWattch)** : Estimates power consumption based on activity statistics



## Execution Flow

The following diagram illustrates how a typical CUDA kernel flows through GPGPU-Sim:
[/code]
[code] 
Sources: [src/abstract_hardware_model.cc181-210](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.cc#L181-L210) [src/gpgpu-sim/gpu-sim.cc32-102](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.cc#L32-L102)

## Core Simulator Components

### Shader Core Architecture

The shader core is one of the most important components in GPGPU-Sim, implementing the execution model of GPU streaming multiprocessors.
[/code]
[code] 
Sources: [src/gpgpu-sim/shader.cc468-505](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L468-L505) [src/gpgpu-sim/shader.h99-334](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L99-L334) [src/gpgpu-sim/shader.cc93-99](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L93-L99) [src/gpgpu-sim/shader.cc271-467](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L271-L467)

Key classes and components of the shader core:

  * **shader_core_ctx** : The main class that models a GPU streaming multiprocessor
  * **shd_warp_t** : Represents a warp (group of threads executed in lockstep)
  * **scheduler_unit** : Models warp scheduling policies (GTO, LRR, etc.)
  * **simt_stack** : Implements the SIMT execution model with divergence handling
  * **opndcoll_rfu_t** : Models the operand collector and register file unit
  * **Execution Units** : Various functional units (SP, SFU, DP, LDST, etc.)



### Memory Hierarchy

GPGPU-Sim implements a comprehensive memory hierarchy that models the complex memory system of modern GPUs:
[/code]
[code] 
Sources: [src/gpgpu-sim/gpu-sim.h213-711](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h#L213-L711) [src/gpgpu-sim/shader.cc101-185](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L101-L185)

Key memory components:

  * **L1 Caches** : Per-shader L1 instruction, data, texture, and constant caches
  * **Shared Memory** : Fast, programmer-managed memory shared by threads in a block
  * **Interconnection Network** : Models the on-chip network connecting cores to memory
  * **L2 Cache** : Unified L2 cache shared across all shader cores
  * **Memory Controllers** : Handle access to DRAM with various scheduling policies
  * **DRAM** : Models GDDR memory with configurable timing parameters



## Configuration System

GPGPU-Sim is highly configurable, allowing researchers to model different GPU architectures and configurations:
[/code]
[code] 
Sources: [src/gpgpu-sim/gpu-sim.h138-211](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h#L138-L211) [src/gpgpu-sim/gpu-sim.h328-711](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h#L328-L711) [CHANGES1-62](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/CHANGES#L1-L62)

The configuration system allows users to define:

  * **Core parameters** : Number of cores, warp size, scheduling policies, etc.
  * **Memory system** : Cache sizes and configurations, DRAM timing, etc.
  * **Interconnection network** : Topology, routing algorithm, etc.
  * **Power model** : Power estimation parameters



## Build System and Environment

GPGPU-Sim provides a comprehensive build system and environment setup to facilitate compilation and execution:
[/code]
[code] 
Sources: [setup_environment1-174](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/setup_environment#L1-L174) [Makefile1-100](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L1-L100) [version_detection.mk1-50](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/version_detection.mk#L1-L50)

Key aspects of the build system:

  1. **Environment Setup** : The `setup_environment` script configures environment variables like `GPGPUSIM_ROOT`, `CUDA_INSTALL_PATH`, and library paths
  2. **Build Configuration** : Supports both debug and release builds with different optimization levels
  3. **Library Generation** : Creates `libcudart.so`, `libcuda.so`, and `libOpenCL.so` to intercept CUDA/OpenCL calls
  4. **Modularity** : The system is built from multiple libraries that can be compiled separately



## Version and Compatibility

GPGPU-Sim 4.2.0 supports a wide range of CUDA versions and GPU architectures:

Feature| Support  
---|---  
CUDA Versions| 2.3 to 11.0+  
GPU Architectures| Fermi, Kepler, Maxwell, Pascal, Volta, Turing, Ampere  
Operating Systems| Linux, macOS (limited support)  
Features| Tensor Cores, Dynamic Parallelism, Cooperative Groups, etc.  
  
Sources: [CHANGES1-62](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/CHANGES#L1-L62) [version1-2](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/version#L1-L2) [setup_environment50-54](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/setup_environment#L50-L54)

## Key Classes and Relationships
[/code]
[code] 
Sources: [src/gpgpu-sim/gpu-sim.h32-711](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h#L32-L711) [src/gpgpu-sim/shader.h32-636](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L32-L636) [src/abstract_hardware_model.h32-645](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L32-L645)

This diagram shows the key classes in GPGPU-Sim and their relationships:

  * **gpgpu_sim** : Main simulator class that coordinates all components
  * **gpgpu_t** : Handles functional simulation and memory management
  * **simt_core_cluster** : Groups of shader cores that share resources
  * **shader_core_ctx** : Models individual shader cores with execution pipelines
  * **memory_partition_unit** : Manages L2 cache and DRAM controllers
  * **interconnect_interface** : Handles communication between cores and memory



## Summary

GPGPU-Sim provides a comprehensive simulation environment for GPU computing:

  1. **Functional Correctness** : Accurately executes CUDA/OpenCL applications
  2. **Performance Modeling** : Provides cycle-accurate performance estimation
  3. **Flexibility** : Supports multiple GPU architectures and configurations
  4. **Analysis** : Provides detailed statistics and power modeling



This overview covered the high-level architecture and key components of GPGPU-Sim. For more detailed information about specific subsystems, refer to their respective wiki pages.

Sources: [src/gpgpu-sim/gpu-sim.h32-102](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h#L32-L102) [src/gpgpu-sim/shader.h32-102](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L32-L102) [CHANGES1-62](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/CHANGES#L1-L62)

