---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/5.2-gpu-architecture-configurations
crawled_at: 2025-06-03T19:42:23.467107
---



# GPU Architecture Configurations

Relevant source files

  * [configs/tested-cfgs/SM2_GTX480/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM2_GTX480/gpgpusim.config)
  * [configs/tested-cfgs/SM3_KEPLER_TITAN/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM3_KEPLER_TITAN/gpgpusim.config)
  * [configs/tested-cfgs/SM6_TITANX/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM6_TITANX/gpgpusim.config)
  * [configs/tested-cfgs/SM75_RTX2060/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM75_RTX2060/gpgpusim.config)
  * [configs/tested-cfgs/SM75_RTX2060_S/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM75_RTX2060_S/gpgpusim.config)
  * [configs/tested-cfgs/SM7_GV100/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_GV100/gpgpusim.config)
  * [configs/tested-cfgs/SM7_QV100/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_QV100/gpgpusim.config)
  * [configs/tested-cfgs/SM7_TITANV/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_TITANV/gpgpusim.config)
  * [configs/tested-cfgs/SM86_RTX3070/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM86_RTX3070/gpgpusim.config)



## Purpose and Scope

This document provides a comprehensive overview of the GPU architecture configurations available in GPGPU-Sim. It details the predefined configuration files that model specific NVIDIA GPU architectures, from Fermi (2010) to Ampere (2020). For information about how the configuration system works and how configuration parameters are processed, see [Configuration System](/gpgpu-sim/gpgpu-sim_distribution/5.1-configuration-system).

These configuration files define the simulated GPU hardware characteristics, including core organization, memory hierarchy, execution units, and timing parameters. Selecting the appropriate configuration file allows users to simulate their CUDA applications on different GPU generations with cycle-accurate precision.

## Supported GPU Architecture Configurations

GPGPU-Sim includes configuration files for several generations of NVIDIA GPU architectures, spanning a decade of GPU development. Each configuration file is named according to its compute capability and representative GPU model.

### Architecture Timeline and Compute Capabilities
[/code]
[code] 
Sources: [configs/tested-cfgs/SM2_GTX480/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM2_GTX480/gpgpusim.config) [configs/tested-cfgs/SM3_KEPLER_TITAN/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM3_KEPLER_TITAN/gpgpusim.config) [configs/tested-cfgs/SM6_TITANX/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM6_TITANX/gpgpusim.config) [configs/tested-cfgs/SM7_TITANV/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_TITANV/gpgpusim.config) [configs/tested-cfgs/SM7_QV100/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_QV100/gpgpusim.config) [configs/tested-cfgs/SM75_RTX2060/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM75_RTX2060/gpgpusim.config) [configs/tested-cfgs/SM75_RTX2060_S/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM75_RTX2060_S/gpgpusim.config) [configs/tested-cfgs/SM86_RTX3070/gpgpusim.config](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM86_RTX3070/gpgpusim.config)

### Comparison of Key Architecture Parameters

Architecture| Config File| Compute Capability| SMs| Memory Type| L1/Shared| L2 Cache  
---|---|---|---|---|---|---  
Fermi| SM2_GTX480| 2.0| 15| GDDR5 (6 partitions)| 16/48 KB configurable| 768 KB  
Kepler| SM3_KEPLER_TITAN| 3.5| 14| GDDR5 (12 partitions)| 16/48 KB configurable| 1.5 MB  
Pascal| SM6_TITANX| 6.1| 28| GDDR5X (12 partitions)| 24 KB / 96 KB| 3 MB  
Volta| SM7_TITANV| 7.0| 80| HBM2 (24 partitions)| Unified 128 KB (0-96 KB shared)| 4.5 MB  
Volta| SM7_QV100| 7.0| 80| HBM2 (32 partitions)| Unified 128 KB (0-96 KB shared)| 6 MB  
Turing| SM75_RTX2060| 7.5| 30| GDDR6 (12 partitions)| 96 KB / 65 KB| 4 MB  
Turing| SM75_RTX2060_S| 7.5| 34| GDDR6 (16 partitions)| 65 KB| 4 MB  
Ampere| SM86_RTX3070| 8.6| 46| GDDR6 (16 partitions)| Unified 128 KB (0-100 KB shared)| 4 MB  
  
Sources: [configs/tested-cfgs/SM7_TITANV/gpgpusim.config32-41](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_TITANV/gpgpusim.config#L32-L41) [configs/tested-cfgs/SM75_RTX2060/gpgpusim.config24-31](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM75_RTX2060/gpgpusim.config#L24-L31) [configs/tested-cfgs/SM86_RTX3070/gpgpusim.config24-31](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM86_RTX3070/gpgpusim.config#L24-L31)

## Configuration File Structure and Key Parameters

The GPU architecture configuration files define all aspects of the simulated hardware. Understanding the key parameter categories is essential for using or customizing these configurations.
[/code]
[code] 
Sources: [configs/tested-cfgs/SM7_TITANV/gpgpusim.config11-201](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_TITANV/gpgpusim.config#L11-L201) [configs/tested-cfgs/SM75_RTX2060/gpgpusim.config1-170](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM75_RTX2060/gpgpusim.config#L1-L170)

### Major Parameter Categories

  1. **Compute Capability and Core Organization**

     * `-gpgpu_compute_capability_major`, `-gpgpu_compute_capability_minor`: Define the CUDA compute capability
     * `-gpgpu_n_clusters`, `-gpgpu_n_cores_per_cluster`: Define the number of SMs
     * `-gpgpu_n_mem`, `-gpgpu_n_sub_partition_per_mchannel`: Define memory partitions
  2. **Core Resources and Pipeline**

     * `-gpgpu_shader_registers`: Total registers per SM
     * `-gpgpu_shader_core_pipeline`: Defines pipeline width and warp size
     * `-gpgpu_num_sp_units`, `-gpgpu_num_sfu_units`, etc.: Number of execution units
  3. **Memory Hierarchy**

     * `-gpgpu_cache:dl1`: L1 data cache configuration
     * `-gpgpu_shmem_size`: Shared memory size
     * `-gpgpu_cache:dl2`: L2 cache configuration
     * DRAM configuration parameters
  4. **Instruction Timing**

     * `-ptx_opcode_latency_int`, `-ptx_opcode_latency_fp`: Instruction execution latencies
     * `-ptx_opcode_initiation_int`, `-ptx_opcode_initiation_fp`: Instruction throughput
  5. **Warp Scheduling**

     * `-gpgpu_num_sched_per_core`: Number of schedulers per SM
     * `-gpgpu_scheduler`: Scheduling policy (gto, lrr)
     * `-gpgpu_max_insn_issue_per_warp`: Maximum instructions issued per warp per cycle
  6. **Interconnect and Statistics**

     * Network configuration and statistic collection parameters



Sources: [configs/tested-cfgs/SM7_TITANV/gpgpusim.config11-75](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_TITANV/gpgpusim.config#L11-L75) [configs/tested-cfgs/SM7_TITANV/gpgpusim.config82-201](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_TITANV/gpgpusim.config#L82-L201)

## Execution Units Across Architectures

Each GPU architecture features different execution unit configurations, reflecting the evolution of NVIDIA's GPU designs.
[/code]
[code] 
Sources: [configs/tested-cfgs/SM2_GTX480/gpgpusim.config43-46](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM2_GTX480/gpgpusim.config#L43-L46) [configs/tested-cfgs/SM3_KEPLER_TITAN/gpgpusim.config50-55](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM3_KEPLER_TITAN/gpgpusim.config#L50-L55) [configs/tested-cfgs/SM6_TITANX/gpgpusim.config79-83](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM6_TITANX/gpgpusim.config#L79-L83) [configs/tested-cfgs/SM7_TITANV/gpgpusim.config56-65](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_TITANV/gpgpusim.config#L56-L65) [configs/tested-cfgs/SM75_RTX2060/gpgpusim.config43-50](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM75_RTX2060/gpgpusim.config#L43-L50) [configs/tested-cfgs/SM86_RTX3070/gpgpusim.config43-50](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM86_RTX3070/gpgpusim.config#L43-L50)

## Memory Hierarchy Evolution

The memory hierarchy has evolved significantly across GPU generations, with major changes in cache organization, memory technology, and bandwidth.
[/code]
[code] 
Sources: [configs/tested-cfgs/SM2_GTX480/gpgpusim.config60-71](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM2_GTX480/gpgpusim.config#L60-L71) [configs/tested-cfgs/SM7_TITANV/gpgpusim.config139-166](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_TITANV/gpgpusim.config#L139-L166) [configs/tested-cfgs/SM75_RTX2060/gpgpusim.config85-110](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM75_RTX2060/gpgpusim.config#L85-L110) [configs/tested-cfgs/SM86_RTX3070/gpgpusim.config85-118](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM86_RTX3070/gpgpusim.config#L85-L118)

## Key Architecture-Specific Features

### Fermi (SM2_GTX480)

  * First architecture with unified L1/L2 cache hierarchy
  * Configurable L1 cache and shared memory (16KB/48KB or 48KB/16KB)
  * 2 warp schedulers per SM
  * Relatively simple execution units: 2 SP, 1 SFU



Sources: [configs/tested-cfgs/SM2_GTX480/gpgpusim.config1-162](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM2_GTX480/gpgpusim.config#L1-L162)

### Kepler (SM3_KEPLER_TITAN)

  * Increased execution resources: 6 SP, 2 SFU, 4 DP units per SM
  * 4 warp schedulers per SM
  * Larger L2 cache (1.5MB vs 768KB in Fermi)
  * Higher memory bandwidth with more memory partitions



Sources: [configs/tested-cfgs/SM3_KEPLER_TITAN/gpgpusim.config1-183](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM3_KEPLER_TITAN/gpgpusim.config#L1-L183)

### Pascal (SM6_TITANX)

  * Increased SM count (28 SMs)
  * 4 SP units and 4 SFU units per SM
  * 3MB L2 cache
  * GDDR5X memory with 384-bit interface



Sources: [configs/tested-cfgs/SM6_TITANX/gpgpusim.config1-207](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM6_TITANX/gpgpusim.config#L1-L207)

### Volta (SM7_TITANV/QV100/GV100)

  * Introduction of tensor cores for deep learning acceleration
  * Dedicated INT units, allowing concurrent execution of FP and INT operations
  * Sub-core model with isolated schedulers
  * Unified L1/shared memory design with configurable partitioning
  * HBM2 memory with significantly higher bandwidth
  * 4 schedulers per SM, each with its own register file


[code] 
    -gpgpu_sub_core_model 1
    -gpgpu_enable_specialized_operand_collector 0
    -gpgpu_operand_collector_num_units_gen 8
    -gpgpu_operand_collector_num_in_ports_gen 8
    -gpgpu_operand_collector_num_out_ports_gen 8
    
[/code]

Sources: [configs/tested-cfgs/SM7_TITANV/gpgpusim.config1-204](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_TITANV/gpgpusim.config#L1-L204) [configs/tested-cfgs/SM7_QV100/gpgpusim.config41-237](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_QV100/gpgpusim.config#L41-L237)

### Turing (SM75_RTX2060/RTX2060S)

  * Enhanced tensor cores
  * 4 schedulers per SM with specialized operand collectors
  * Further optimized INT execution alongside FP operations
  * GDDR6 memory with higher bandwidth
  * Adaptive cache configuration support



Sources: [configs/tested-cfgs/SM75_RTX2060/gpgpusim.config1-179](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM75_RTX2060/gpgpusim.config#L1-L179) [configs/tested-cfgs/SM75_RTX2060_S/gpgpusim.config30-211](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM75_RTX2060_S/gpgpusim.config#L30-L211)

### Ampere (SM86_RTX3070)

  * Third-generation tensor cores
  * Increased SM count (46 SMs)
  * Enhanced unified L1/shared memory design
  * Higher instruction throughput for FP32 operations
  * GDDR6 memory with increased bandwidth



Sources: [configs/tested-cfgs/SM86_RTX3070/gpgpusim.config1-181](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM86_RTX3070/gpgpusim.config#L1-L181)

## Using and Customizing Configurations

### Selecting a Configuration

To use a specific GPU architecture configuration, provide the path to the desired configuration file when launching GPGPU-Sim:
[/code]
[code] 
### Common Customization Scenarios
[/code]
[code] 
#### Scaling Compute Resources

To model a GPU with more or fewer compute resources:
[code] 
    # Increase/decrease number of SMs
    -gpgpu_n_clusters 60
    
    # Adjust cores per cluster (typically 1, but 2 for some Volta configs)
    -gpgpu_n_cores_per_cluster 1
    
    # Change number of execution units
    -gpgpu_num_sp_units 6
    -gpgpu_num_sfu_units 2
    
[/code]

#### Modifying Memory Configuration

To adjust cache sizes or memory organization:
[code] 
    # Change L1 cache configuration
    -gpgpu_cache:dl1 S:4:128:96,L:L:m:L:L,A:512:8,16:0,32
    
    # Adjust shared memory size
    -gpgpu_shmem_size 81920
    
    # Modify L2 cache
    -gpgpu_cache:dl2 S:32:128:16,L:B:m:L:P,A:192:4,32:0,32
    
    # Change memory partition count
    -gpgpu_n_mem 24
    
[/code]

#### Adjusting Clock Domains

To modify the operating frequencies:
[code] 
    # Format: Core:Interconnect:L2:DRAM (MHz)
    -gpgpu_clock_domains 1500.0:1500.0:1500.0:850.0
    
[/code]

### Validation Considerations

When customizing configurations, consider:

  1. **Parameter Consistency** : Many parameters are interrelated and must be adjusted together
  2. **Hardware Fidelity** : Ensure the modified configuration still represents a realistic GPU
  3. **Benchmark Verification** : Validate the configuration with known benchmarks
  4. **Performance Impact** : Consider how changes affect simulation time and accuracy



## Conclusion

GPGPU-Sim provides detailed configuration files for modeling GPU architectures from Fermi to Ampere. These configurations capture the key architectural features and evolution of NVIDIA GPUs over time. By understanding and leveraging these configurations, users can accurately simulate GPU performance for various applications and research scenarios.

For information about how to run tests with these configurations, see [Continuous Integration and Testing](/gpgpu-sim/gpgpu-sim_distribution/5.3-continuous-integration-and-testing).

