---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/2.3-memory-system
crawled_at: 2025-06-03T19:42:10.623038
---



# Memory System

Relevant source files

  * [src/gpgpu-sim/addrdec.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/addrdec.cc)
  * [src/gpgpu-sim/addrdec.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/addrdec.h)
  * [src/gpgpu-sim/dram.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.cc)
  * [src/gpgpu-sim/dram.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.h)
  * [src/gpgpu-sim/mem_latency_stat.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/mem_latency_stat.cc)
  * [src/gpgpu-sim/mem_latency_stat.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/mem_latency_stat.h)



## Purpose and Scope

This document describes the memory system in GPGPU-Sim, which models the behavior of GPU DRAM memory including memory partitioning, address translation, DRAM timing, request scheduling, and performance statistics collection. For information about shader core caches (L1), see [Shader Core Simulation](/gpgpu-sim/gpgpu-sim_distribution/2.1-shader-core-simulation), and for L2 cache specifics, see the relevant sections of [Core Simulation Components](/gpgpu-sim/gpgpu-sim_distribution/2-core-simulation-components).

## Memory Hierarchy Overview

The GPGPU-Sim memory system simulates the DRAM subsystem of a modern GPU. The memory subsystem handles memory requests after they leave the L2 cache and interfaces with the interconnection network that connects the shader cores to the memory partitions.
[/code]
[code] 
Sources: [src/gpgpu-sim/dram.h112-117](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.h#L112-L117) [src/gpgpu-sim/addrdec.h60-94](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/addrdec.h#L60-L94) [src/gpgpu-sim/mem_latency_stat.h37-126](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/mem_latency_stat.h#L37-L126)

## DRAM Organization and Components

The DRAM memory system in GPGPU-Sim models a multi-channel DRAM architecture typical of modern GPUs. Each memory partition connects to a DRAM channel, which is composed of banks organized into bank groups.
[/code]
[code] 
Sources: [src/gpgpu-sim/dram.h97-98](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.h#L97-L98) [src/gpgpu-sim/dram.h78-98](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.h#L78-L98) [src/gpgpu-sim/dram.cc48-117](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.cc#L48-L117)

### Key DRAM Components

  1. **DRAM Channel** : A memory partition connects to one DRAM channel
  2. **Bank Groups** : Banks are organized into groups that share timing constraints
  3. **Banks** : Individual storage units with their own row buffers and state machines
  4. **Row Buffer** : Stores the currently active row in a bank



The DRAM system tracks several states and parameters for each bank:

Component| Description| Key Variables  
---|---|---  
Bank| Storage unit| `state` (IDLE/ACTIVE), `curr_row`, timing counters  
Bank Group| Group of banks| `CCDLc` (Column-to-Column Delay between banks in a group)  
DRAM Chip| Collection of bank groups| Timing parameters (tRCD, tCAS, tRP, etc.)  
  
Sources: [src/gpgpu-sim/dram.h73-98](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.h#L73-L98) [src/gpgpu-sim/dram.cc97-117](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.cc#L97-L117)

## Address Translation

Memory addresses in GPGPU-Sim are translated from a linear address space to a physical DRAM location through the address decoder.
[/code]
[code] 
Sources: [src/gpgpu-sim/addrdec.h60-94](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/addrdec.h#L60-L94) [src/gpgpu-sim/addrdec.cc77-94](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/addrdec.cc#L77-L94) [src/gpgpu-sim/dram.cc197-245](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.cc#L197-L245)

### Address Mapping Schemes

GPGPU-Sim supports several address mapping schemes that define how linear addresses map to DRAM components:

  1. **Linear Bank Indexing** : Directly uses bits from the address
  2. **Bitwise XOR Bank Indexing** : XORs bank bits with lower bits of the page address
  3. **IPOLY Bank Indexing** : Uses polynomial hashing for better conflict avoidance
  4. **Custom Bank Indexing** : Allows user-defined address mapping



Memory partition selection can use different indexing functions:

  1. **Consecutive** : Sequential partitioning
  2. **Bitwise Permutation** : Uses bitwise operations for mapping
  3. **IPOLY** : Improves parallelism through polynomial hashing
  4. **Random** : For experimental purposes



Sources: [src/gpgpu-sim/addrdec.h39-46](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/addrdec.h#L39-L46) [src/gpgpu-sim/addrdec.cc197-207](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/addrdec.cc#L197-L207) [src/gpgpu-sim/addrdec.cc132-186](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/addrdec.cc#L132-L186)

## Memory Request Processing

The DRAM controller handles memory requests through a sophisticated pipeline that models real-world timing constraints and command scheduling.
[/code]
[code] 
Sources: [src/gpgpu-sim/dram.cc247-266](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.cc#L247-L266) [src/gpgpu-sim/dram.cc272-284](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.cc#L272-L284) [src/gpgpu-sim/dram.cc290-553](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.cc#L290-L553) [src/gpgpu-sim/dram.cc555-633](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.cc#L555-L633) [src/gpgpu-sim/dram.cc635-684](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.cc#L635-L684)

### DRAM Request Queues

GPGPU-Sim uses several queues to manage memory requests:

Queue| Description| Implementation  
---|---|---  
MRQQ| Memory Request Queue| Incoming requests wait here  
RWQ| Read-Write Queue| Active transfers  
Return Queue| Completed requests| Requests ready to return to shader core  
  
Sources: [src/gpgpu-sim/dram.cc118-124](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.cc#L118-L124) [src/gpgpu-sim/dram.h169-173](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.h#L169-L173)

### DRAM Schedulers

GPGPU-Sim implements multiple DRAM scheduling policies:

  1. **FIFO** : First-In-First-Out scheduling
  2. **FR-FCFS** : First-Ready First-Come-First-Served, which prioritizes: 
     * Row buffer hits (requests to currently open rows)
     * Older requests when there are ties



Sources: [src/gpgpu-sim/dram.cc272-284](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.cc#L272-L284) [src/gpgpu-sim/dram.cc323-333](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.cc#L323-L333)

## DRAM Timing Model

The DRAM timing model enforces constraints found in real DRAM devices:
[/code]
[code] 
Sources: [src/gpgpu-sim/dram.h78-98](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.h#L78-L98) [src/gpgpu-sim/dram.cc472-548](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.cc#L472-L548) [src/gpgpu-sim/dram.cc555-633](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.cc#L555-L633)

### Key Timing Parameters

Parameter| Description| Usage in Code  
---|---|---  
tRCD| Row-to-Column Delay| Time between ACT and RD/WR  
tRCDWR| Row-to-Column Write Delay| Time between ACT and WR  
tCCD| Column-to-Column Delay| Time between consecutive RD or WR commands  
tCCDL| Column-to-Column Delay (same bank group)| Time between RD/WR in same group  
tRAS| Row Access Strobe| Minimum time row must remain open  
tRP| Row Precharge| Time to precharge a row  
tRC| Row Cycle| tRAS + tRP  
tRTW| Read-to-Write| Delay when switching from read to write  
tWTR| Write-to-Read| Delay when switching from write to read  
tBL| Burst Length| Number of cycles for data transfer  
  
Sources: [src/gpgpu-sim/dram.h79-86](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.h#L79-L86) [src/gpgpu-sim/dram.cc74-78](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.cc#L74-L78) [src/gpgpu-sim/dram.cc159-162](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.cc#L159-L162)

## Memory Statistics Collection

GPGPU-Sim collects detailed statistics about memory system performance to help evaluate GPU designs.
[/code]
[code] 
Sources: [src/gpgpu-sim/mem_latency_stat.h37-126](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/mem_latency_stat.h#L37-L126) [src/gpgpu-sim/mem_latency_stat.cc49-186](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/mem_latency_stat.cc#L49-L186)

### Key Statistics Collected

Category| Metrics| Purpose  
---|---|---  
Latency| Request latency, queue latency| Measure memory performance  
Utilization| Bank activity, bandwidth utilization| Measure resource efficiency  
Locality| Row buffer hits| Evaluate spatial locality  
Parallelism| Bank-level parallelism| Measure parallel request processing  
Traffic| Read/write counts by bank| Monitor traffic distribution  
  
Key functions for statistics collection:

  * `memlatstat_done()`: Records request completion and latency
  * `memlatstat_dram_access()`: Records DRAM access statistics
  * `memlatstat_read_done()`: Finalizes read request statistics



Sources: [src/gpgpu-sim/mem_latency_stat.cc188-202](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/mem_latency_stat.cc#L188-L202) [src/gpgpu-sim/mem_latency_stat.cc204-228](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/mem_latency_stat.cc#L204-L228) [src/gpgpu-sim/mem_latency_stat.cc230-266](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/mem_latency_stat.cc#L230-L266)

## Configuration Options

The memory system is highly configurable through various parameters:

Category| Configuration Options| Description  
---|---|---  
Organization| `gpgpu_n_mem`, `gpgpu_n_sub_partition_per_mc`| Memory channels and sub-partitions  
Timing| `gpgpu_dram_timing_spec`| DRAM timing parameters  
Scheduling| `gpgpu_dram_sched`, `gpgpu_frfcfs_dram_sched_queue_size`| Scheduler type and queue size  
Address Mapping| `gpgpu_mem_addr_mapping`| Address mapping scheme  
Advanced| `gpgpu_dram_seperate_write_queue_enable`| Separate read/write queues  
  
Sources: [src/gpgpu-sim/dram.cc164-178](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/dram.cc#L164-L178) [src/gpgpu-sim/addrdec.cc56-75](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/addrdec.cc#L56-L75)

## Conclusion

The GPGPU-Sim memory system provides a detailed and configurable model of a GPU DRAM subsystem, including memory partitioning, address translation, request scheduling, and timing constraints. It enables accurate simulation of memory behavior for GPU architecture research and performance analysis.

