---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/2.1-shader-core-simulation
crawled_at: 2025-06-03T19:42:36.045665
---



# Shader Core Simulation

Relevant source files

  * [src/abstract_hardware_model.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.cc)
  * [src/abstract_hardware_model.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h)
  * [src/gpgpu-sim/gpu-sim.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.cc)
  * [src/gpgpu-sim/gpu-sim.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h)
  * [src/gpgpu-sim/shader.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc)
  * [src/gpgpu-sim/shader.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h)



## Purpose and Scope

This document provides a detailed explanation of the shader core simulation component within GPGPU-Sim. The shader core represents the primary computational unit of a GPU, responsible for executing CUDA/OpenCL kernels through a collection of warps (groups of threads that execute in lockstep). This page focuses on how GPGPU-Sim models the internal architecture, pipeline stages, scheduling mechanisms, and execution units of GPU shader cores.

For memory hierarchy simulation, see [Memory System](/gpgpu-sim/gpgpu-sim_distribution/2.3-memory-system). For thread management details, see [Execution Model and Thread Management](/gpgpu-sim/gpgpu-sim_distribution/2.4-execution-model-and-thread-management).

## Shader Core Architecture Overview

The shader core (also known as an SM - Streaming Multiprocessor in NVIDIA terminology) is modeled in GPGPU-Sim primarily through the `shader_core_ctx` class, which simulates the execution pipeline, functional units, register files, and scheduling logic.
[/code]
[code] 
Sources: [src/gpgpu-sim/shader.h350-490](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L350-L490) [src/gpgpu-sim/shader.cc468-504](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L468-L504)

## Core Initialization and Setup

A shader core is initialized with a configuration that specifies the number of warps, functional units, register file size, etc. The initialization process creates:

  1. Front-end pipeline (instruction fetch and decode)
  2. Execution pipeline with functional units
  3. Warp schedulers
  4. SIMT stacks for managing control flow divergence
  5. Memory interfaces for handling memory requests


[/code]
[code] 
Sources: [src/gpgpu-sim/shader.cc101-271](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L101-L271) [src/gpgpu-sim/shader.cc271-467](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L271-L467)

## Pipeline Structure

The shader core models a pipeline with multiple stages. Each stage is represented by a register set that holds instructions at that stage.
[/code]
[code] 
The pipeline stages are implemented as register sets in the `m_pipeline_reg` vector with the following indices:

Pipeline Stage| Index| Description  
---|---|---  
IF_ID| 0| Instruction Fetch to Decode  
ID_OC_SP| 1| Issue to SP units  
ID_OC_SFU| 2| Issue to SFU units  
ID_OC_MEM| 3| Issue to memory units  
OC_EX_SP| 4| Operand collection to SP execute  
OC_EX_SFU| 5| Operand collection to SFU execute  
OC_EX_MEM| 6| Operand collection to memory execute  
EX_WB| 7| Execute to writeback  
ID_OC_DP| 8| Issue to DP units (if available)  
OC_EX_DP| 9| Operand collection to DP execute  
ID_OC_INT| 10| Issue to INT units (if available)  
OC_EX_INT| 11| Operand collection to INT execute  
ID_OC_TENSOR| 12| Issue to Tensor Core units (if available)  
OC_EX_TENSOR| 13| Operand collection to Tensor Core execute  
  
Sources: [src/gpgpu-sim/shader.cc101-124](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L101-L124) [src/gpgpu-sim/shader.h33-67](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L33-L67)

## Warp Management

Warps are the basic unit of execution in a GPU. Each warp contains multiple threads (typically 32) that execute the same instruction in lockstep. The shader core keeps track of warps using the `shd_warp_t` class.
[/code]
[code] 
The state of a warp is determined by:

  * Active mask (`m_active_threads`): Which threads are active
  * Program counter (`m_next_pc`): Address of the next instruction
  * Instruction buffer (`m_ibuffer`): Buffered instructions ready to execute
  * Completed threads count (`n_completed`): Threads that have completed execution



Sources: [src/gpgpu-sim/shader.h103-334](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L103-L334) [src/abstract_hardware_model.h433-436](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L433-L436)

## SIMT Stack for Divergence Control

The SIMT (Single Instruction, Multiple Thread) stack keeps track of control flow divergence within a warp. When threads in a warp take different paths at a branch, the SIMT stack records the divergence and reconvergence points.
[/code]
[code] 
The `simt_stack` class is responsible for:

  1. Tracking active threads for each divergent path
  2. Managing reconvergence points
  3. Updating the active mask of the warp



Sources: [src/abstract_hardware_model.h439-481](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L439-L481) [src/abstract_hardware_model.cc930-1046](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.cc#L930-L1046)

## Scheduling Algorithms

Shader cores use different scheduling algorithms to determine which warp to execute next. This is implemented through the `scheduler_unit` class and its subclasses.
[/code]
[code] 
The scheduling algorithms include:

  * **LRR (Loose Round Robin)** : Cycles through warps in order
  * **GTO (Greedy Then Oldest)** : Prioritizes older warps that have made more progress
  * **Two-Level** : Maintains an active warp list with inner and outer scheduling policies
  * **RRR (Strict Round Robin)** : Strict round-robin scheduling
  * **SWL (Static Warp Limiting)** : Limits the number of concurrently executing warps
  * **Oldest First** : Prioritizes warps based on age



The scheduler selection is controlled by the `gpgpu_scheduler_string` configuration parameter.

Sources: [src/gpgpu-sim/shader.h376-616](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L376-L616) [src/gpgpu-sim/shader.cc187-269](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L187-L269)

## Execution Units and Functional Units

The shader core contains various functional units that execute different types of instructions. These are implemented as subclasses of `simd_function_unit`.
[/code]
[code] 
The number and configuration of these units depend on the GPU architecture being simulated:

Unit Type| Configuration Parameter| Description  
---|---|---  
SP Units| gpgpu_num_sp_units| Single-precision floating-point units  
SFU Units| gpgpu_num_sfu_units| Special function units (transcendentals, etc.)  
DP Units| gpgpu_num_dp_units| Double-precision floating-point units  
INT Units| gpgpu_num_int_units| Integer units  
Tensor Units| gpgpu_num_tensor_core_units| Tensor core units  
Specialized Units| m_specialized_unit| Custom specialized units  
  
Sources: [src/gpgpu-sim/shader.cc411-449](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L411-L449) [src/abstract_hardware_model.h109-139](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L109-L139)

## Operand Collection

The Operand Collector is responsible for fetching operands from the register file before instruction execution. It's implemented in the `opndcoll_rfu_t` class.
[/code]
[code] 
The operand collector can be configured with specialized collection units for different instruction types or used in a generic mode. The configuration parameters control:

  * Number of collection units per type
  * Number of input ports
  * Number of output ports
  * Register bank configuration



Sources: [src/gpgpu-sim/shader.h639-921](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L639-L921) [src/gpgpu-sim/shader.cc275-399](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L275-L399)

## Memory Access and Coalescing

Memory access instructions generate memory requests through a coalescing mechanism that combines requests from multiple threads in a warp.
[/code]
[code] 
Memory coalescing depends on:

  1. Memory space (global, shared, constant, texture)
  2. GPU architecture (coalescing rules differ by architecture)
  3. Address patterns (consecutive, strided, random)
  4. Data size (byte, word, double word)



Sources: [src/abstract_hardware_model.cc286-747](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.cc#L286-L747) [src/gpgpu-sim/shader.h777-786](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L777-L786)

## Shader Core Cycle Simulation

The simulation of each cycle in the shader core involves several key phases:
[/code]
[code] 
During each cycle, the shader core:

  1. Fetches instructions for active warps
  2. Decodes instructions and places them in the appropriate pipeline registers
  3. Schedules ready warps for execution
  4. Collects operands for scheduled instructions
  5. Executes instructions on appropriate functional units
  6. Writes back results to registers
  7. Processes memory requests and responses



Sources: [src/gpgpu-sim/shader.cc101-124](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L101-L124) [src/gpgpu-sim/gpu-sim.cc32-101](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.cc#L32-L101)

## Statistics Collection

The shader core collects various statistics to measure performance:

Statistic| Description  
---|---  
Instruction counts| Number of instructions executed per type  
Warp occupancy| Number of active warps over time  
Pipeline stalls| Reasons for pipeline stalls  
Memory access patterns| Global, shared, constant memory accesses  
Bank conflicts| Shared memory bank conflicts, L1 cache bank conflicts  
Divergence metrics| Control flow divergence statistics  
Scheduler stats| Warp scheduling decisions  
  
These statistics are managed by the `shader_core_stats` class and can be visualized and analyzed after simulation.

Sources: [src/gpgpu-sim/shader.cc617-842](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L617-L842) [src/gpgpu-sim/shader.h59-67](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L59-L67)

## Configuration Parameters

The shader core behavior is highly configurable through various parameters:

Parameter| Description| Default  
---|---|---  
gpgpu_shader_core_pipeline| Basic pipeline configuration| "1024:32"  
gpgpu_num_sp_units| Number of SP units| 1  
gpgpu_num_sfu_units| Number of SFU units| 1  
gpgpu_num_dp_units| Number of DP units| 0  
gpgpu_num_int_units| Number of INT units| 0  
gpgpu_scheduler| Warp scheduler algorithm| "gto"  
gpgpu_num_sched_per_core| Number of schedulers per core| 1  
gpgpu_max_insn_issue_per_warp| Maximum instructions issued per warp| 2  
gpgpu_shader_registers| Number of registers per shader core| 8192  
gpgpu_sub_core_model| Sub-core model enable| 0  
gpgpu_operand_collector_num_units_*| Operand collector configuration| varies  
  
These parameters are defined in the `shader_core_config` class and initialized from the configuration file.

Sources: [src/gpgpu-sim/gpu-sim.cc328-595](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.cc#L328-L595) [src/gpgpu-sim/shader.h383-456](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L383-L456)

