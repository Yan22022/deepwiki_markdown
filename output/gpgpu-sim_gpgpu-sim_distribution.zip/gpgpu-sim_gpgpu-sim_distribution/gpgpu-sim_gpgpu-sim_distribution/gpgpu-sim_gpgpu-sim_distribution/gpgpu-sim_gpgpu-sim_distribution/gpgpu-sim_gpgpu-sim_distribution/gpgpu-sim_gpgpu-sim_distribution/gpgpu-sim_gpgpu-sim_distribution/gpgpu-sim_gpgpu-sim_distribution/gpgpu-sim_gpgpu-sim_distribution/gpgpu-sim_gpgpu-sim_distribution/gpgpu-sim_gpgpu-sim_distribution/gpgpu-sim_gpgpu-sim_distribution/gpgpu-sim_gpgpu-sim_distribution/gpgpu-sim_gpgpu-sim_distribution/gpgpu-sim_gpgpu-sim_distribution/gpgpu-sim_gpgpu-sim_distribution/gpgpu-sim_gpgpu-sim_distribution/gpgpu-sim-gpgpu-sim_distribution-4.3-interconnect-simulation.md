---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/4.3-interconnect-simulation
crawled_at: 2025-06-03T19:42:32.480089
---



# Interconnect Simulation

Relevant source files

  * [src/gpgpu-sim/icnt_wrapper.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/icnt_wrapper.cc)
  * [src/gpgpu-sim/icnt_wrapper.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/icnt_wrapper.h)
  * [src/gpgpu-sim/local_interconnect.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/local_interconnect.cc)
  * [src/gpgpu-sim/local_interconnect.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/local_interconnect.h)



## Introduction

The Interconnect Simulation subsystem in GPGPU-Sim models the on-chip network that connects shader cores (compute units) and memory partitions in a GPU. This component is critical for accurate performance modeling as it simulates how memory requests and responses travel between processing elements and memory subsystems.

GPGPU-Sim provides two interconnect implementation options: a detailed network simulator (InterSim2) and a simpler crossbar router (LocalInterconnect). The interconnection network typically consists of request and reply networks for bi-directional communication between shader cores and memory partitions.

For details about the memory system that connects to this network, see [Memory System](/gpgpu-sim/gpgpu-sim_distribution/2.3-memory-system).

Sources: [src/gpgpu-sim/icnt_wrapper.h34-64](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/icnt_wrapper.h#L34-L64) [src/gpgpu-sim/icnt_wrapper.cc164-197](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/icnt_wrapper.cc#L164-L197)

## Interconnect Architecture Overview

The interconnect simulation provides a functional interface that handles the following operations:

  * Buffering and transfer of memory requests and responses
  * Modeling of network congestion and conflicts
  * Statistics collection for network performance analysis



GPGPU-Sim supports two interconnection network modes:

  1. **InterSim2** \- A detailed, cycle-accurate network simulator with configurable topologies, routing algorithms, and flow control mechanisms
  2. **LocalInterconnect** \- A simpler crossbar router implementation with configurable arbitration algorithms


[/code]
[code] 
The diagram above shows how the interconnect fits into the GPGPU-Sim architecture. The Interconnect Wrapper provides a unified interface for the rest of the simulator, regardless of which interconnect implementation is used.

Sources: [src/gpgpu-sim/icnt_wrapper.h34-64](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/icnt_wrapper.h#L34-L64) [src/gpgpu-sim/icnt_wrapper.cc47-52](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/icnt_wrapper.cc#L47-L52)

## Interconnect Wrapper Interface

GPGPU-Sim uses function pointers to create a unified interface to different interconnect implementations. This wrapper interface is defined in `icnt_wrapper.h` and initialized in `icnt_wrapper.cc`.
[/code]
[code] 
The key functions in the interconnect wrapper interface are:

Function| Description  
---|---  
`icnt_create`| Creates the interconnect network with specified number of shader cores and memory partitions  
`icnt_init`| Initializes the interconnect network  
`icnt_has_buffer`| Checks if the network has buffer space at the specified input port  
`icnt_push`| Inserts a packet into the network from input port to output port  
`icnt_pop`| Retrieves a packet from the network at the specified output port  
`icnt_transfer`| Advances the network simulation by one cycle  
`icnt_busy`| Checks if there are any packets in transit in the network  
`icnt_display_stats`| Displays network statistics  
  
The network mode is selected via the configuration parameter `g_network_mode`, which can be set to `INTERSIM` (1) or `LOCAL_XBAR` (2).

Sources: [src/gpgpu-sim/icnt_wrapper.h36-61](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/icnt_wrapper.h#L36-L61) [src/gpgpu-sim/icnt_wrapper.cc139-161](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/icnt_wrapper.cc#L139-L161) [src/gpgpu-sim/icnt_wrapper.cc164-197](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/icnt_wrapper.cc#L164-L197)

## LocalInterconnect Implementation

The `LocalInterconnect` class implements a simplified crossbar router model. It creates two separate networks (subnets) for requests and responses when configured with `subnets=2`:

  1. **Request Network (REQ_NET)** \- Carries memory requests from shader cores to memory partitions
  2. **Reply Network (REPLY_NET)** \- Carries memory responses from memory partitions back to shader cores


[/code]
[code] 
The `xbar_router` class handles the actual routing of packets within each subnet. It maintains input and output buffers for each node (shader cores and memory partitions) and handles packet transfer according to the configured arbitration algorithm.

### Buffer Structure and Packet Flow
[/code]
[code] 
The packet flow through the `xbar_router` is as follows:

  1. Packets are pushed into the appropriate input buffer of the router
  2. During each cycle (`Advance()`), the router's arbitration algorithm selects which packets to move from input to output buffers
  3. Packets are then popped from the output buffers by the destination devices



Sources: [src/gpgpu-sim/local_interconnect.h110-137](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/local_interconnect.h#L110-L137) [src/gpgpu-sim/local_interconnect.cc284-432](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/local_interconnect.cc#L284-L432) [src/gpgpu-sim/local_interconnect.h52-108](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/local_interconnect.h#L52-L108) [src/gpgpu-sim/local_interconnect.cc40-279](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/local_interconnect.cc#L40-L279)

## Arbitration Algorithms

The `xbar_router` supports two arbitration algorithms for resolving conflicts when multiple input ports want to send to the same output port:

  1. **Naive Round-Robin (NAIVE_RR)** \- A simple round-robin scheme that cycles through input ports
  2. **iSLIP** \- An iterative, round-robin based algorithm that provides better fairness and higher throughput



### Naive Round-Robin (NAIVE_RR)

The NAIVE_RR algorithm cycles through input ports in a fixed order, checking for packets to transfer. If a packet's destination output buffer has space and hasn't been used this cycle, the packet is transferred.
[/code]
[code] 
### iSLIP Arbitration

The iSLIP algorithm, as described in Nick McKeown's paper "The iSLIP scheduling algorithm for input-queued switches", provides better performance for the interconnect. It works as follows:

  1. For each output port, it cycles through input ports in round-robin order
  2. When it finds an input with a packet for this output, it transfers the packet
  3. Upon successful transfer, it updates round-robin pointers to maintain fairness



This algorithm reduces the likelihood of starvation and provides better fairness compared to simpler arbitration schemes.

Sources: [src/gpgpu-sim/local_interconnect.cc114-173](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/local_interconnect.cc#L114-L173) [src/gpgpu-sim/local_interconnect.cc174-270](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/local_interconnect.cc#L174-L270) [src/gpgpu-sim/local_interconnect.h40](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/local_interconnect.h#L40-L40)

## Configuration and Statistics

### Configuration Options

The interconnect can be configured through various parameters in the simulator configuration files:

Parameter| Description| Default  
---|---|---  
`-network_mode`| Interconnection network mode (1=INTERSIM, 2=LOCAL_XBAR)| 1  
`-inter_config_file`| Configuration file for InterSim2 (when using network_mode=1)| "mesh"  
`-icnt_in_buffer_limit`| Input buffer size limit| 64  
`-icnt_out_buffer_limit`| Output buffer size limit| 64  
`-icnt_subnets`| Number of subnets (typically 2: request and reply)| 2  
`-icnt_arbiter_algo`| Arbitration algorithm (0=NAIVE_RR, 1=iSLIP)| 1  
`-icnt_verbose`| Verbose output for debugging| 0  
`-icnt_grant_cycles`| Number of cycles per grant in iSLIP| 1  
  
These configuration options are registered in the `icnt_reg_options` function.

### Statistics Collection

The interconnect simulation collects numerous statistics to help analyze network performance:

Statistic| Description  
---|---  
`packets_num`| Total number of packets injected into the network  
`cycles`| Total number of simulation cycles  
`conflicts`| Number of routing conflicts  
`in_buffer_full`| Number of times input buffers were full  
`out_buffer_full`| Number of times output buffers were full  
`in_buffer_util`| Input buffer utilization  
`out_buffer_util`| Output buffer utilization  
  
These statistics are reported separately for the request and reply networks, providing detailed information about network performance and potential bottlenecks.

Sample statistics output:
[code] 
    Req_Network_injected_packets_num = [number]
    Req_Network_cycles = [number]
    Req_Network_injected_packets_per_cycle = [number]
    Req_Network_conflicts_per_cycle = [number]
    Req_Network_conflicts_per_cycle_util = [number]
    Req_Bank_Level_Parallism = [number]
    Req_Network_in_buffer_full_per_cycle = [number]
    Req_Network_in_buffer_avg_util = [number]
    Req_Network_out_buffer_full_per_cycle = [number]
    Req_Network_out_buffer_avg_util = [number]
    
    Reply_Network_injected_packets_num = [number]
    Reply_Network_cycles = [number]
    Reply_Network_injected_packets_per_cycle = [number]
    Reply_Network_conflicts_per_cycle = [number]
    Reply_Network_conflicts_per_cycle_util = [number]
    Reply_Bank_Level_Parallism = [number]
    Reply_Network_in_buffer_full_per_cycle = [number]
    Reply_Network_in_buffer_avg_util = [number]
    Reply_Network_out_buffer_full_per_cycle = [number]
    Reply_Network_out_buffer_avg_util = [number]
    
[/code]

Sources: [src/gpgpu-sim/icnt_wrapper.cc139-161](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/icnt_wrapper.cc#L139-L161) [src/gpgpu-sim/local_interconnect.cc378-424](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/local_interconnect.cc#L378-L424)

