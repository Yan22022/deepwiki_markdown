---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/1.1-architecture-overview
crawled_at: 2025-06-03T19:42:47.607990
---



# Architecture Overview

Relevant source files

  * [src/abstract_hardware_model.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.cc)
  * [src/abstract_hardware_model.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h)
  * [src/cuda-sim/cuda-sim.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda-sim.h)
  * [src/debug.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/debug.cc)
  * [src/debug.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/debug.h)
  * [src/gpgpu-sim/gpu-sim.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.cc)
  * [src/gpgpu-sim/gpu-sim.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h)
  * [src/gpgpu-sim/shader.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc)
  * [src/gpgpu-sim/shader.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h)
  * [src/gpgpusim_entrypoint.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc)
  * [src/gpgpusim_entrypoint.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.h)
  * [src/stream_manager.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc)
  * [src/stream_manager.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h)



This document provides a comprehensive overview of the GPGPU-Sim architecture, explaining the major components and their interactions. It serves as a foundation for understanding how the simulator models modern GPUs at a detailed level. For build system setup, see [Build System and Setup](/gpgpu-sim/gpgpu-sim_distribution/1.2-build-system-and-setup), and for detailed codebase organization, see [Codebase Organization](/gpgpu-sim/gpgpu-sim_distribution/1.3-codebase-organization).

## High-Level Architecture

GPGPU-Sim is designed as a cycle-accurate GPU simulator with two main simulation paths:

  1. **Functional simulation** : Executes PTX instructions to model correct program behavior
  2. **Performance simulation** : Models cycle-by-cycle hardware execution to estimate performance


[/code]
[code] 
Sources: [src/gpgpu-sim/gpu-sim.h40-70](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h#L40-L70) [src/abstract_hardware_model.h382-429](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L382-L429) [src/gpgpu-sim/shader.h469-505](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L469-L505) [src/stream_manager.h219-245](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h#L219-L245) [src/cuda-sim/cuda-sim.h118-136](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda-sim.h#L118-L136)

## Simulation Flow

The simulation process follows a specific flow from user application to kernel execution and completion:
[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.cc91-185](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L91-L185) [src/stream_manager.cc126-164](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L126-L164) [src/gpgpu-sim/gpu-sim.cc1254-1325](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.cc#L1254-L1325)

## Core Simulation Components

### Context and Configuration Classes

The simulator's configuration and execution context are managed through several key classes:
[/code]
[code] 
Sources: [src/gpgpusim_entrypoint.h40-75](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.h#L40-L75) [src/gpgpu-sim/gpu-sim.h409-474](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h#L409-L474) [src/abstract_hardware_model.h382-429](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L382-L429)

### Shader Core Architecture

The shader core (`shader_core_ctx`) is a central component that models the execution units of a GPU SM (Streaming Multiprocessor):
[/code]
[code] 
The shader core manages:

  * Pipeline stages (fetch, decode, execute, writeback)
  * Warp scheduling with various policies (LRR, GTO, etc.)
  * Operand collection from register files
  * Execution through functional units
  * Memory access via the load/store unit



Sources: [src/gpgpu-sim/shader.cc98-467](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L98-L467) [src/gpgpu-sim/shader.h350-390](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L350-L390) [src/gpgpu-sim/shader.h638-675](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L638-L675)

### Memory Hierarchy

GPGPU-Sim models a complete memory hierarchy similar to modern GPUs:
[/code]
[code] 
Key aspects of the memory system:

  * Multiple L1 cache types (instruction, data, texture, constant)
  * Shared memory per shader core
  * Shared L2 cache across the GPU
  * DRAM memory system with configurable parameters
  * Interconnect network between L1 and L2



Sources: [src/gpgpu-sim/gpu-sim.h213-404](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h#L213-L404) [src/gpgpu-sim/shader.cc173-184](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L173-L184) [src/abstract_hardware_model.h486-508](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L486-L508)

## Execution Management

### Stream and Kernel Handling

Kernels and memory operations are managed through the stream management system:
[/code]
[code] 
The execution flow is as follows:

  1. User application launches kernels/operations through the CUDA/OpenCL runtime
  2. Operations are queued in the appropriate stream
  3. Stream manager processes operations
  4. For kernels, functional simulation occurs, followed by performance simulation
  5. Results are returned once operations complete



Sources: [src/stream_manager.h84-224](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h#L84-L224) [src/stream_manager.cc76-107](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L76-L107) [src/stream_manager.cc124-164](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L124-L164) [src/abstract_hardware_model.h226-378](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L226-L378)

### CUDA Simulation and PTX Execution

The front-end of GPGPU-Sim handles CUDA/PTX execution:
[/code]
[code] 
Functional simulation:

  * Executes PTX instructions semantically without timing
  * Manages thread state and memory accesses
  * Provides correct results that performance simulation will model timing for



Sources: [src/cuda-sim/cuda-sim.h118-205](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda-sim.h#L118-L205) [src/stream_manager.cc163-190](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L163-L190) [src/gpgpusim_entrypoint.cc217-224](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpusim_entrypoint.cc#L217-L224)

## Performance Simulation Pipeline

The performance simulation happens through a cycle-by-cycle execution model:
[/code]
[code] 
During each cycle:

  1. Each shader core processes its pipeline stages
  2. Warp schedulers select ready warps for execution
  3. Functional units execute instructions
  4. Memory requests are sent through the interconnect
  5. Memory system (L2, DRAM) processes requests
  6. Results propagate back through the pipeline



Sources: [src/gpgpu-sim/gpu-sim.cc1273-1325](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.cc#L1273-L1325) [src/gpgpu-sim/shader.cc100-467](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L100-L467) [src/stream_manager.cc126-164](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.cc#L126-L164)

## Configuration System

GPGPU-Sim's behavior is highly configurable through configuration files:
[/code]
[code] 
The configuration system allows detailed specification of:

  * General GPU parameters (core count, frequency, etc.)
  * Shader core details (pipeline width, functional units, etc.)
  * Memory system (cache sizes, DRAM parameters, etc.)
  * Interconnection network topology and parameters



Sources: [src/gpgpu-sim/gpu-sim.cc100-233](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.cc#L100-L233) [src/gpgpu-sim/gpu-sim.cc328-604](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.cc#L328-L604) [src/gpgpu-sim/gpu-sim.h235-404](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h#L235-L404) [src/gpgpu-sim/gpu-sim.h409-473](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h#L409-L473)

## Summary

GPGPU-Sim provides a comprehensive GPU simulation framework that combines:

  1. Functional simulation through PTX execution
  2. Detailed performance modeling of GPU components
  3. Extensive configurability to model different GPU architectures



The simulator consists of multiple interacting components that together implement a complete GPU simulation environment. It can be used to evaluate GPU architecture designs, analyze performance bottlenecks, and study the behavior of GPU applications in a controlled, observable environment.

Sources: [src/gpgpu-sim/gpu-sim.h33-70](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h#L33-L70) [src/gpgpu-sim/shader.h33-70](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L33-L70) [src/abstract_hardware_model.h32-70](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L32-L70) [src/stream_manager.h29-70](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/stream_manager.h#L29-L70) [src/cuda-sim/cuda-sim.h29-70](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/cuda-sim.h#L29-L70)

