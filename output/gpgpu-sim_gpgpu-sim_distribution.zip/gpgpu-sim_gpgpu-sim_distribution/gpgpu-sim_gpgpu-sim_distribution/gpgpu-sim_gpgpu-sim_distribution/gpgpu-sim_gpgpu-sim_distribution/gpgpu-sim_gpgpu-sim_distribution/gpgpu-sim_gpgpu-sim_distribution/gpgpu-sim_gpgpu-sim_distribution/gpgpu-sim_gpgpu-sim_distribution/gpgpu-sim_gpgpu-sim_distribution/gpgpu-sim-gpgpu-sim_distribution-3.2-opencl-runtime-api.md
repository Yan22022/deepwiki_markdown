---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/3.2-opencl-runtime-api
crawled_at: 2025-06-03T19:42:17.320895
---



# OpenCL Runtime API

Relevant source files

  * [.github/workflows/sst_integration.yml](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.github/workflows/sst_integration.yml)
  * [libcuda/cuda_api_object.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_api_object.h)
  * [libcuda/cuobjdump.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuobjdump.h)
  * [libcuda/cuobjdump.l](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuobjdump.l)
  * [libcuda/cuobjdump.y](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuobjdump.y)
  * [libcuda/gpgpu_context.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/gpgpu_context.h)
  * [libopencl/opencl_runtime_api.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc)



## Purpose and Scope

This document describes the OpenCL Runtime API implementation in GPGPU-Sim, which allows OpenCL applications to be simulated on the GPGPU-Sim environment. The implementation provides a subset of the OpenCL 1.0 API functionality necessary to run OpenCL kernels on the simulated GPU hardware.

For information about the CUDA Runtime API implementation, see [CUDA Runtime API](/gpgpu-sim/gpgpu-sim_distribution/3.1-cuda-runtime-api).

## Overview

The OpenCL Runtime API in GPGPU-Sim serves as a bridge between OpenCL applications and the GPU simulation core. It translates OpenCL API calls into operations that can be executed by the simulator, allowing researchers to study the performance of OpenCL kernels on various GPU architectures.
[/code]
[code] 
Sources: [libopencl/opencl_runtime_api.cc112-222](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L112-L222) [libopencl/opencl_runtime_api.cc659-670](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L659-L670)

## Key Components

The OpenCL Runtime API implementation consists of several key components that work together to support OpenCL applications:

### Platform and Device Management

GPGPU-Sim presents itself as a single OpenCL platform with one or more devices. The implementation handles device enumeration, property queries, and selection.
[/code]
[code] 
Sources: [libopencl/opencl_runtime_api.cc130-138](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L130-L138) [libopencl/opencl_runtime_api.cc226-228](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L226-L228)

### Context and Command Queue

OpenCL contexts and command queues manage the execution environment for kernels.
[/code]
[code] 
Sources: [libopencl/opencl_runtime_api.cc112-128](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L112-L128) [libopencl/opencl_runtime_api.cc140-158](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L140-L158)

### Memory Objects

Memory objects (`_cl_mem`) represent memory buffers accessible by both the host and device.
[/code]
[code] 
Sources: [libopencl/opencl_runtime_api.cc160-171](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L160-L171) [libopencl/opencl_runtime_api.cc306-357](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L306-L357)

### Program and Kernel Management

Programs and kernels are central to OpenCL execution. The implementation handles program compilation, kernel creation, and kernel execution.
[/code]
[code] 
Sources: [libopencl/opencl_runtime_api.cc173-195](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L173-L195) [libopencl/opencl_runtime_api.cc197-222](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L197-L222) [libopencl/opencl_runtime_api.cc405-423](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L405-L423) [libopencl/opencl_runtime_api.cc246-304](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L246-L304)

## OpenCL to PTX Compilation Process

A critical part of the OpenCL Runtime API is the compilation of OpenCL source code to PTX, which can then be executed by GPGPU-Sim.
[/code]
[code] 
Sources: [libopencl/opencl_runtime_api.cc438-598](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L438-L598)

The OpenCL to PTX compilation process involves:

  1. Writing the OpenCL source to a temporary file
  2. Using NVIDIA's OpenCL driver (via the `nvopencl_wrapper` utility) to convert OpenCL to PTX
  3. Loading the generated PTX into GPGPU-Sim
  4. Registering kernel functions for later execution



## Kernel Execution Flow

When an OpenCL kernel is executed, the following flow occurs:
[/code]
[code] 
Sources: [libopencl/opencl_runtime_api.cc881-988](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L881-L988)

The kernel execution involves several steps:

  1. Calculating grid and block dimensions based on the global and local work sizes
  2. Binding kernel arguments to the PTX implementation
  3. Setting up OpenCL-specific global variables (`_global_size`, `_work_dim`, etc.)
  4. Executing the kernel either in functional mode (for correctness) or performance mode (for timing)



## OpenCL API Functions

The OpenCL Runtime API implementation in GPGPU-Sim supports the following key functions:

Function| Description| Implementation Status  
---|---|---  
`clCreateContextFromType`| Creates an OpenCL context from a device type| Complete  
`clCreateContext`| Creates an OpenCL context from specified devices| Complete  
`clGetContextInfo`| Gets information about a context| Partial  
`clCreateCommandQueue`| Creates a command queue| Complete  
`clCreateBuffer`| Creates a buffer object| Complete  
`clCreateProgramWithSource`| Creates a program object from source code| Complete  
`clBuildProgram`| Builds (compiles and links) a program| Complete  
`clCreateKernel`| Creates a kernel object| Complete  
`clSetKernelArg`| Sets the argument value for a kernel| Complete  
`clEnqueueNDRangeKernel`| Enqueues a command to execute a kernel| Complete  
`clEnqueueReadBuffer`| Reads from a buffer object to host memory| Complete  
`clEnqueueWriteBuffer`| Writes to a buffer object from host memory| Complete  
`clCreateProgramWithBinary`| Creates a program object from binaries| Not implemented  
`clGetEventProfilingInfo`| Gets profiling information| Not implemented  
  
Sources: [libopencl/opencl_runtime_api.cc694-1392](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L694-L1392)

## Memory Management

The OpenCL Runtime API implementation manages memory between the host and device:
[/code]
[code] 
Sources: [libopencl/opencl_runtime_api.cc317-357](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L317-L357) [libopencl/opencl_runtime_api.cc370-386](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L370-L386)

The memory management involves:

  1. Creating memory objects with different flags (`CL_MEM_USE_HOST_PTR`, `CL_MEM_COPY_HOST_PTR`, etc.)
  2. Allocating GPU memory using `gpu_malloc()`
  3. Copying data between host and device using `memcpy_to_gpu()` and `memcpy_from_gpu()`
  4. Tracking memory objects in the context's maps (`m_hostptr_to_cl_mem` and `m_devptr_to_cl_mem`)



## Integration with GPGPU-Sim

The OpenCL Runtime API integrates with GPGPU-Sim through the `gpgpu_context` class, which provides access to the simulator's functionality:
[/code]
[code] 
Sources: [libcuda/gpgpu_context.h11-84](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/gpgpu_context.h#L11-L84) [libopencl/opencl_runtime_api.cc659-670](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L659-L670)

The integration points include:

  1. Initialization of GPGPU-Sim through `GPGPUSim_Init()`
  2. Loading PTX code into the simulator using `gpgpu_ptx_sim_load_ptx_from_string()`
  3. Executing kernels using `gpgpu_opencl_ptx_sim_main_perf()` or `gpgpu_opencl_ptx_sim_main_func()`
  4. Accessing simulator features through the `gpgpu_context` class



## Limitations and Notes

The OpenCL Runtime API implementation in GPGPU-Sim has several limitations and assumptions:

  1. **Limited API Support** : The implementation focuses on core functionality needed to run OpenCL kernels. Some API functions are not implemented or have limited functionality.

  2. **NVIDIA Dependency** : The OpenCL to PTX compilation process relies on NVIDIA's OpenCL driver, requiring users to have the NVIDIA OpenCL implementation installed.

  3. **OpenCL 1.0 Focus** : The implementation primarily supports OpenCL 1.0 functionality, with limited support for newer OpenCL versions.

  4. **Remote Compilation Support** : The implementation includes support for remote compilation, allowing PTX generation on a separate machine.

  5. **Debug and Warning Messages** : The implementation includes various warning and error messages to help users diagnose issues.




Sources: [libopencl/opencl_runtime_api.cc235-244](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L235-L244) [libopencl/opencl_runtime_api.cc672-681](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L672-L681)

## Example Usage Flow

Below is an example flow for using the OpenCL Runtime API in GPGPU-Sim:
[/code]
[code] 
Sources: [libopencl/opencl_runtime_api.cc694-1392](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libopencl/opencl_runtime_api.cc#L694-L1392)

