---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/2.2-cuda-simulation-and-ptx-execution
crawled_at: 2025-06-03T19:42:37.868549
---



# CUDA Simulation and PTX Execution

Relevant source files

  * [src/cuda-sim/ptx_sim.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.cc)
  * [src/cuda-sim/ptx_sim.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h)



## Purpose and Scope

This document describes the CUDA simulation and PTX execution process in GPGPU-Sim. It covers how CUDA kernels are loaded, how PTX (Parallel Thread Execution) instructions are simulated, and the thread execution model that enables functional simulation of CUDA applications.

This page focuses on the functional simulation aspects rather than performance modeling. For information about how the performance aspects are simulated, see [Shader Core Simulation](/gpgpu-sim/gpgpu-sim_distribution/2.1-shader-core-simulation) and [Memory System](/gpgpu-sim/gpgpu-sim_distribution/2.3-memory-system).

## CUDA Simulation Process Overview

GPGPU-Sim intercepts CUDA API calls from applications and simulates their execution through PTX, NVIDIA's intermediate representation language. The simulator first executes the PTX instructions functionally to determine program behavior, and then performs cycle-accurate performance simulation.
[/code]
[code] 
Sources: [src/cuda-sim/ptx_sim.h290-519](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h#L290-L519) [src/cuda-sim/ptx_sim.cc150-187](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.cc#L150-L187)

## Thread Hierarchy and Execution Model

GPGPU-Sim models the CUDA thread hierarchy, including threads, warps, and thread blocks (CTAs). The simulation creates and manages these entities to match NVIDIA's execution model.
[/code]
[code] 
Sources: [src/cuda-sim/ptx_sim.h290-519](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h#L290-L519) [src/cuda-sim/ptx_sim.cc293-464](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.cc#L293-L464)

### Thread Information

The `ptx_thread_info` class is the central data structure representing a CUDA thread in the simulator. Each thread contains:

  * Thread/block/grid identifiers (TID, CTAID, NTID, NCTAID)
  * Program counter (PC) and next PC (NPC)
  * Register state and symbol table
  * Call stack for function calls
  * Memory access information
  * Hardware mapping (SM ID, warp ID, etc.)



A thread's execution state is maintained throughout simulation, allowing for cycle-accurate modeling of thread behavior.

Thread State Component| Purpose  
---|---  
Program Counter (PC)| Current instruction address  
Next PC (NPC)| Next instruction to execute  
Register File| Thread's register state  
Call Stack| Function call hierarchy  
Symbol Table| Maps symbols to values  
Memory Spaces| Local, shared, and global memory access  
Thread Status| Running, blocked, completed  
  
Sources: [src/cuda-sim/ptx_sim.h290-519](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h#L290-L519) [src/cuda-sim/ptx_sim.cc150-187](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.cc#L150-L187)

### CTA and Warp Management

Thread blocks (CTAs) and warps are managed by the `ptx_cta_info` and `ptx_warp_info` classes:

  * `ptx_cta_info`: Tracks threads in a CTA, barrier synchronization, and thread completion
  * `ptx_warp_info`: Tracks warp state and completed threads within a warp


[/code]
[code] 
Sources: [src/cuda-sim/ptx_sim.h158-191](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h#L158-L191) [src/cuda-sim/ptx_sim.cc41-144](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.cc#L41-L144)

## PTX Execution Process

PTX instructions are executed by the simulator on a per-thread basis. The execution flow involves instruction fetch, operand retrieval, operation execution, and result storage.
[/code]
[code] 
Sources: [src/cuda-sim/ptx_sim.cc293-305](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.cc#L293-L305) [src/cuda-sim/ptx_sim.cc544-546](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.cc#L544-L546)

### Register Management

Registers in PTX simulation are managed through the `ptx_reg_t` union, which supports different data types (integer, floating-point, predicate) and sizes. The register file for a thread is maintained in the `m_regs` member of `ptx_thread_info`.
[/code]
[code] 
Sources: [src/cuda-sim/ptx_sim.h62-150](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h#L62-L150)

### Built-in Variables and Special Registers

CUDA provides built-in variables like `threadIdx`, `blockIdx`, etc., which are accessed via the `get_builtin` method in `ptx_thread_info`. These provide threads with their position in the execution hierarchy.

Built-in Register| Description| Access Method  
---|---|---  
`%tid`| Thread ID within block| `get_builtin(TID_REG, dim)`  
`%ntid`| Block dimensions| `get_builtin(NTID_REG, dim)`  
`%ctaid`| Block ID within grid| `get_builtin(CTAID_REG, dim)`  
`%nctaid`| Grid dimensions| `get_builtin(NCTAID_REG, dim)`  
`%laneid`| Lane ID within warp| `get_builtin(LANEID_REG, 0)`  
`%clock`| Clock cycle counter| `get_builtin(CLOCK_REG, 0)`  
`%warpsz`| Warp size| `get_builtin(WARPSZ_REG, 0)`  
  
Sources: [src/cuda-sim/ptx_sim.cc199-305](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.cc#L199-L305)

## Function Calls and Control Flow

PTX simulation handles function calls using a call stack mechanism implemented in `ptx_thread_info`. When a function call is executed, the current context is saved, and a new context is created for the called function.
[/code]
[code] 
Key components:

  * `stack_entry`: Stores function call context (PC, RPC, symbol table, return variables)
  * `callstack_push()`: Saves current context and creates new context for function call
  * `callstack_pop()`: Restores caller context when a function returns



Sources: [src/cuda-sim/ptx_sim.h195-227](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h#L195-L227) [src/cuda-sim/ptx_sim.cc407-507](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.cc#L407-L507)

## Thread Synchronization

GPGPU-Sim models barriers and other synchronization mechanisms through the CTA information:

  * `m_barrier_num`: Tracks which barrier a thread is waiting at
  * `m_at_barrier`: Indicates if a thread is currently waiting at a barrier
  * `m_bar_threads`: Counts how many threads are at a barrier
  * `reset_bar_threads()`: Resets the counter when all threads reach the barrier



This allows the simulator to accurately model thread synchronization behavior in CUDA kernels.

Sources: [src/cuda-sim/ptx_sim.h132-136](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h#L132-L136) [src/cuda-sim/ptx_sim.cc132-136](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.cc#L132-L136)

## Memory Access

During PTX execution, memory operations are directed to the appropriate memory spaces:

  * Global memory: Accessible by all threads
  * Shared memory: Shared among threads in the same CTA
  * Local memory: Private to each thread
  * Constant memory: Read-only data accessible by all threads



Memory operations update the thread's `m_last_effective_address` and `m_last_memory_space` to track memory access patterns.

Sources: [src/cuda-sim/ptx_sim.h432-438](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h#L432-L438) [src/cuda-sim/ptx_sim.h466-469](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h#L466-L469)

## Integration with Performance Simulation

After functional simulation, information about thread execution is passed to the performance model to simulate timing behavior:

  1. The functional simulation determines what operations are performed
  2. The performance model determines when and how efficiently they execute
  3. Memory access patterns from functional simulation drive memory system simulation
  4. Thread synchronization points determine scheduling constraints



This separation of functional correctness and performance modeling allows GPGPU-Sim to maintain both accuracy and efficiency.

Sources: [src/cuda-sim/ptx_sim.h306-320](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h#L306-L320)

