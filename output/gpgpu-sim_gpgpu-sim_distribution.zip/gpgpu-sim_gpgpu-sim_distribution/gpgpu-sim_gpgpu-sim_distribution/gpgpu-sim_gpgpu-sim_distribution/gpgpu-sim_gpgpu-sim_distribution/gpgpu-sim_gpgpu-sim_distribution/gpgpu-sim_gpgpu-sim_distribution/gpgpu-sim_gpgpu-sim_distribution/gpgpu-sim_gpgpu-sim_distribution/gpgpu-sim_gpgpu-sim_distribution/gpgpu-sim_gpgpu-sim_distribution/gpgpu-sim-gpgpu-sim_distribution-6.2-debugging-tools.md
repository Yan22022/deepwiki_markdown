---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/6.2-debugging-tools
crawled_at: 2025-06-03T19:42:18.997048
---



# Debugging Tools

Relevant source files

  * [debug_tools/WatchYourStep/ptxjitplus/Makefile](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/debug_tools/WatchYourStep/ptxjitplus/Makefile)
  * [debug_tools/WatchYourStep/ptxjitplus/launchkernels](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/debug_tools/WatchYourStep/ptxjitplus/launchkernels)
  * [debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp)
  * [debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.h)



This page provides a comprehensive overview of the debugging capabilities available in GPGPU-Sim. It focuses on tools that help developers diagnose issues in CUDA applications running within the simulator environment.

## WatchYourStep (WYS): Kernel-Level Debugging

WatchYourStep is a specialized debugging tool built for GPGPU-Sim that allows developers to observe kernel execution step by step. Unlike traditional debuggers, WYS enables selective execution of individual CUDA kernels using parameters captured from earlier simulation runs.
[/code]
[code] 
**Figure: WatchYourStep Workflow in GPGPU-Sim**

Sources: [debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp16-40](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp#L16-L40)

### How WatchYourStep Works

WatchYourStep operates in two distinct phases:

  1. **Configuration Capture Phase** : When a CUDA application is run with GPGPU-Sim and `PTX_SIM_DEBUG=4`, the simulator captures kernel launch parameters and PTX code into configuration files.

  2. **Replay Phase** : Using the `ptxjitplus` tool, developers can execute specific kernels with their original parameters and inspect the results.



[/code]
[code] 
**Figure: WatchYourStep Execution Sequence**

Sources: [debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp138-191](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp#L138-L191) [debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp253-314](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp#L253-L314)

### Setup and Usage

To use WatchYourStep, follow these steps:

  1. **Set Environment Variables** :
[/code]
[code]   2. **Run Your CUDA Application with GPGPU-Sim** to generate configuration files.

  3. **Lower Debug Level** to avoid regenerating config files:
[/code]
[code]   4. **Execute Individual Kernels** :

     * For a single kernel: 
[/code]
[code]      * For multiple kernels: 
[/code]
[code]   5. **Examine Results** in `../data/wys.out*` files.




Sources: [debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp26-40](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp#L26-L40) [debug_tools/WatchYourStep/ptxjitplus/launchkernels1-4](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/debug_tools/WatchYourStep/ptxjitplus/launchkernels#L1-L4)

### Implementation Details

WatchYourStep consists of the following key components:
[/code]
[code] 
**Figure: WatchYourStep Component Structure**

Sources: [debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp193-346](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp#L193-L346)

#### Parameter Handling

The `param` structure is used to manage kernel parameters:
[/code]
[code] 
Sources: [debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.h15-20](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.h#L15-L20)

During execution, WatchYourStep:

  1. Reads parameter data from configuration files
  2. Allocates device memory for pointer parameters
  3. Copies data to device memory as necessary
  4. Launches the kernel with prepared parameters
  5. Copies results back to host and writes to output files



This process allows developers to inspect both input and output data for each kernel invocation.

Sources: [debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp257-314](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp#L257-L314)

### Example Output

WatchYourStep generates detailed output files containing parameter values after kernel execution. For each parameter that is a pointer (array), the output shows:
[code] 
    param n: size = X, data = 
     v1 v2 v3 ...
     v4 v5 v6 ...
     ...
    
[/code]

Where:

  * `n` is the parameter index
  * `X` is the size in bytes
  * `v1, v2, ...` are byte values in the array



This output provides visibility into the data transformations performed by each kernel.

Sources: [debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp300-314](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp#L300-L314)

## Building WatchYourStep

WatchYourStep can be built using the provided Makefile:
[/code]
[code] 
The Makefile configures the build for the appropriate architecture and creates the `ptxjitplus` executable.

Sources: [debug_tools/WatchYourStep/ptxjitplus/Makefile303-320](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/debug_tools/WatchYourStep/ptxjitplus/Makefile#L303-L320)

## Limitations and Best Practices

When using WatchYourStep, consider the following:

  1. **Configuration File Size** : For applications with many kernels or large parameter sets, configuration files can become quite large.

  2. **Memory Management** : WatchYourStep allocates memory for each parameter, which could be significant for large data sets.

  3. **Selective Debugging** : Rather than running all kernels, target specific problematic kernels to speed up the debugging process.

  4. **Environment Setup** : Ensure all environment variables are correctly set before each phase of debugging.




## Integration with Other GPGPU-Sim Components

WatchYourStep works alongside other GPGPU-Sim components:
[/code]
[code] 
**Figure: WatchYourStep in GPGPU-Sim Architecture**

Sources: [debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp16-40](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/debug_tools/WatchYourStep/ptxjitplus/ptxjitplus.cpp#L16-L40)

## Summary

WatchYourStep provides a powerful mechanism for kernel-level debugging in GPGPU-Sim. By capturing kernel parameters and PTX code during simulation and allowing selective replay of individual kernels, it enables developers to pinpoint issues in complex CUDA applications. The tool's output files provide detailed visibility into kernel execution results, facilitating effective debugging and analysis.

