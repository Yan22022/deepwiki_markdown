---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/1.2-build-system-and-setup
crawled_at: 2025-06-03T19:42:08.692481
---



# Build System and Setup

Relevant source files

  * [.gitignore](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.gitignore)
  * [.travis.yml](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.travis.yml)
  * [CHANGES](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/CHANGES)
  * [Makefile](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile)
  * [configs/tested-cfgs/SM7_QV100/config_volta_islip.icnt](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/configs/tested-cfgs/SM7_QV100/config_volta_islip.icnt)
  * [libcuda/cuda_api.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_api.h)
  * [linux-so-version.txt](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/linux-so-version.txt)
  * [setup_environment](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/setup_environment)
  * [version](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/version)
  * [version_detection.mk](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/version_detection.mk)



This document describes the GPGPU-Sim build system and the environment setup required to compile and run the simulator. It covers the prerequisites, environment setup procedure, build system structure, and build process. For information about the codebase organization, see [Codebase Organization](/gpgpu-sim/gpgpu-sim_distribution/1.3-codebase-organization).

## Prerequisites

Before building GPGPU-Sim, ensure you have the following prerequisites installed:

  1. CUDA Toolkit (supported versions up to CUDA 12.8)
  2. GCC/G++ compiler
  3. Make build system
  4. Git (for version information)



GPGPU-Sim supports both Linux and macOS platforms, with primary development and testing on Linux.

Sources: [setup_environment16-29](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/setup_environment#L16-L29) [Makefile100-119](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L100-L119)

## Environment Setup

The environment setup is managed by the `setup_environment` script that must be sourced before building or running GPGPU-Sim.
[/code]
[code] 
Optionally, you can enable debug mode:
[/code]
[code] 
The setup script performs several important functions:

  1. Sets `GPGPUSIM_ROOT` to the root directory of the project
  2. Checks for valid CUDA installation and adds CUDA binaries to PATH
  3. Detects CUDA and GCC versions
  4. Configures library paths and runtime environment
  5. Sets up OpenCL support if available
  6. Checks for AccelWattch power model support



### Environment Variables

The script sets several environment variables that control GPGPU-Sim behavior:

Variable| Purpose  
---|---  
GPGPUSIM_ROOT| Root directory of GPGPU-Sim  
CUDA_INSTALL_PATH| Path to CUDA installation  
GPGPUSIM_CONFIG| Configuration path (e.g., `gcc-8.3.0/cuda-10010/release`)  
LD_LIBRARY_PATH| Path to load GPGPU-Sim libraries  
GPGPUSIM_POWER_MODEL| Path to AccelWattch power model  
PTXAS_CUDA_INSTALL_PATH| Path to PTXAS utilities (can differ from CUDA_INSTALL_PATH)  
  
Sources: [setup_environment6-45](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/setup_environment#L6-L45) [setup_environment62-73](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/setup_environment#L62-L73) [setup_environment92-101](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/setup_environment#L92-L101) [setup_environment122-149](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/setup_environment#L122-L149)

## Build System Structure

The GPGPU-Sim build system is organized around a set of Makefiles that compile various components of the simulator.

### Makefile Hierarchy
[/code]
[code] 
Sources: [Makefile35](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L35-L35) [Makefile198-237](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L198-L237)

### Build Components

GPGPU-Sim is organized into several major libraries that are built independently and then linked together:
[/code]
[code] 
Sources: [Makefile61-65](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L61-L65) [Makefile218-227](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L218-L227)

## Build Process

The build process compiles each component into object files, archives them into libraries, and then links them together to create the final shared libraries that intercept CUDA and OpenCL calls.

### Build Directory Structure

GPGPU-Sim creates a directory structure based on the GCC and CUDA versions to store build artifacts:
[code] 
    lib/gcc-<GCC_VERSION>/cuda-<CUDA_VERSION>/<mode>/
    build/gcc-<GCC_VERSION>/cuda-<CUDA_VERSION>/<mode>/
    
[/code]

Where `<mode>` is either `debug` or `release`.

Sources: [Makefile37-56](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L37-L56) [Makefile238-248](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L238-L248)

### Build Targets

The main build targets include:

  1. `libcudart.so` \- CUDA Runtime API interceptor
  2. `libOpenCL.so` \- OpenCL API interceptor
  3. `cuobjdump_to_ptxplus` \- Tool for converting cubin files to PTX+ format



Each target is built with the relevant components linked in.
[/code]
[code] 
Sources: [Makefile98-99](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L98-L99) [Makefile146-170](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L146-L170) [Makefile185-196](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L185-L196) [Makefile233-237](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L233-L237)

## Building GPGPU-Sim

To build GPGPU-Sim, follow these steps:

  1. Ensure CUDA Toolkit is installed
  2. Source the environment setup script: 
[/code]
[code]   3. Run make: 
[/code]
[code] 


### Common Build Configurations

GPGPU-Sim supports several build configurations:

  1. **Release Build** (default): Optimized for performance
[/code]
[code]   2. **Debug Build** : Includes debug symbols and minimal optimization
[/code]
[code]   3. **With Power Model** : Includes AccelWattch power modeling
[/code]
[code] 


Sources: [setup_environment35-73](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/setup_environment#L35-L73) [Makefile37-45](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L37-L45)

## Build Outputs

The build process creates several key artifacts:

### Shared Libraries

  1. `libcudart.so` \- Intercepts CUDA Runtime API calls
  2. `libcudart.so.X.Y` \- Symbolic links for different CUDA versions
  3. `libOpenCL.so` \- Intercepts OpenCL API calls (if OpenCL support is enabled)



### Tools

  1. `cuobjdump_to_ptxplus` \- Converts CUDA binary format to PTX+ format



### Documentation

The build system can also generate documentation:
[/code]
[code] 
Sources: [Makefile146-196](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L146-L196) [Makefile254-255](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L254-L255)

## Continuous Integration

GPGPU-Sim uses Travis CI for continuous integration testing. The CI system tests multiple GPU configurations including GTX480 and TITANV with various CUDA versions.
[/code]
[code] 
Sources: [.travis.yml1-38](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/.travis.yml#L1-L38)

## Troubleshooting

Common build issues and their solutions:

  1. **CUDA not found** : Ensure `CUDA_INSTALL_PATH` is set correctly
[code] ERROR ** nvcc (from CUDA Toolkit) was not found in PATH but required to build GPGPU-Sim.
         
[/code]

  2. **Incorrect CUDA version** : GPGPU-Sim may show a warning if using an untested CUDA version

  3. **Missing OpenCL** : If OpenCL support is needed, ensure `NVOPENCL_LIBDIR` and `NVOPENCL_INCDIR` are set

  4. **AccelWattch issues** : If power modeling is needed, check that the power model files are in the correct location




Sources: [setup_environment16-45](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/setup_environment#L16-L45) [Makefile120-141](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L120-L141) [Makefile143-144](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/Makefile#L143-L144)

