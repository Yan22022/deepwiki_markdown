---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/3.1-cuda-runtime-api
crawled_at: 2025-06-03T19:42:07.038568
---



# CUDA Runtime API

Relevant source files

  * [libcuda/cuda_runtime_api.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc)
  * [src/cuda-sim/ptx_loader.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_loader.cc)
  * [src/cuda-sim/ptx_loader.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_loader.h)
  * [src/cuda-sim/ptxinfo.l](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptxinfo.l)
  * [src/cuda-sim/ptxinfo.y](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptxinfo.y)



## Purpose and Scope

The CUDA Runtime API component in GPGPU-Sim provides an implementation of NVIDIA's CUDA Runtime API that allows CUDA applications to be simulated within GPGPU-Sim rather than executed on actual GPU hardware. This implementation intercepts CUDA API calls from applications and redirects them to the simulator's internal mechanisms, allowing for detailed simulation and analysis of GPU program execution.

This page documents the CUDA Runtime API implementation in GPGPU-Sim, focusing on how it interfaces with application code and how it connects to the simulator's internal components. For information on the PTX execution and simulation, see [CUDA Simulation and PTX Execution](/gpgpu-sim/gpgpu-sim_distribution/2.2-cuda-simulation-and-ptx-execution).

## Architecture Overview

### CUDA Runtime API Structure
[/code]
[code] 
The CUDA Runtime API implementation serves as the primary interface between CUDA applications and the GPGPU-Sim simulator. It handles context creation, device management, kernel launch configuration, and memory operations, translating these operations into the appropriate simulator actions.

Sources: [libcuda/cuda_runtime_api.cc67-103](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L67-L103) [libcuda/cuda_runtime_api.cc197-266](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L197-L266)

## Core Components

### Context and Device Management

The CUDA Runtime API implementation provides functions for initializing the simulator and managing GPU contexts:
[/code]
[code] 
The key functions that manage contexts and devices include:

  * `GPGPUSim_Init()`: Initializes the GPU simulator, creating a device with appropriate properties.
  * `GPGPUSim_Context()`: Gets or creates a simulation context.
  * `GPGPU_Context()`: Gets or creates the global GPGPU context.



Sources: [libcuda/cuda_runtime_api.cc197-266](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L197-L266)

### Binary and Code Management

GPGPU-Sim needs to process CUDA binaries to extract PTX code for simulation. The CUDA Runtime API handles this through several functions:
[/code]
[code] 
Key functions include:

  * `cudaRegisterFatBinaryInternal()`: Registers CUDA binaries with the simulator
  * `cudaRegisterFunctionInternal()`: Maps host functions to device functions
  * `cudaRegisterVarInternal()`: Registers global and constant variables



Sources: [libcuda/cuda_runtime_api.cc786-872](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L786-L872)

### Kernel Execution Management

The API provides functions for configuring and launching CUDA kernels:
[/code]
[code] 
Key functions include:

  * `cudaConfigureCallInternal()`: Sets grid and block dimensions for kernel launch
  * `cudaSetupArgumentInternal()`: Adds arguments to the kernel
  * `cudaLaunchInternal()`: Initiates kernel execution



Sources: [libcuda/cuda_runtime_api.cc874-968](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L874-L968) [libcuda/cuda_runtime_api.cc969-1036](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L969-L1036)

## CUDA Runtime API Functions

### Initialization and Context Functions

The CUDA Runtime API initialization functions create and manage the simulation environment:

Function| Purpose  
---|---  
`GPGPUSim_Init()`| Initializes the GPU simulator and creates a simulated device  
`GPGPUSim_Context()`| Retrieves or creates a CUDA context for simulation  
`GPGPU_Context()`| Retrieves or creates the global GPGPU context  
  
Example initialization flow:

  1. `GPGPU_Context()` is called to get the global context
  2. `GPGPUSim_Context()` is called to get a CUDA context
  3. `GPGPUSim_Init()` is called to initialize the device if needed



Sources: [libcuda/cuda_runtime_api.cc197-266](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L197-L266)

### Device Management Functions

Device management functions allow applications to interact with simulated CUDA devices:

Function| Purpose  
---|---  
`cudaSetDeviceInternal()`| Sets the active CUDA device for subsequent operations  
`cudaGetDeviceInternal()`| Gets the current active CUDA device  
`cudaGetDeviceCountInternal()`| Gets the number of available CUDA devices  
`cudaGetDevicePropertiesInternal()`| Retrieves properties of a CUDA device  
`cudaDeviceGetLimitInternal()`| Gets resource limits for the current device  
  
These functions simulate the behavior of the corresponding CUDA Runtime API functions.

Sources: [libcuda/cuda_runtime_api.cc524-604](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L524-L604) [libcuda/cuda_runtime_api.cc893-943](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L893-L943)

### Binary and Function Registration

GPGPU-Sim needs to handle CUDA binaries and function registration to simulate kernel execution:

Function| Purpose  
---|---  
`cudaRegisterFatBinaryInternal()`| Registers a CUDA fat binary with the simulator  
`cudaRegisterFunctionInternal()`| Maps a host function to a device function  
`cudaRegisterVarInternal()`| Registers global and constant variables  
  
The fat binary registration process extracts PTX code, which is then parsed and used for simulation.

Sources: [libcuda/cuda_runtime_api.cc786-795](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L786-L795) [libcuda/cuda_runtime_api.cc807-871](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L807-L871)

### Kernel Execution Functions

Kernel execution functions manage the configuration and launching of CUDA kernels:

Function| Purpose  
---|---  
`cudaConfigureCallInternal()`| Sets up grid and block dimensions for kernel launch  
`cudaSetupArgumentInternal()`| Adds arguments to the kernel launch configuration  
`cudaLaunchInternal()`| Launches a configured kernel  
  
The kernel launch process involves:

  1. Configuring kernel dimensions with `cudaConfigureCallInternal()`
  2. Setting up arguments with `cudaSetupArgumentInternal()`
  3. Launching the kernel with `cudaLaunchInternal()`



Sources: [libcuda/cuda_runtime_api.cc874-967](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L874-L967) [libcuda/cuda_runtime_api.cc969-1036](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L969-L1036)

## PTX Processing

The CUDA Runtime API interfaces with GPGPU-Sim's PTX processing components to enable kernel simulation:
[/code]
[code] 
Key components:

  * PTX Extraction: Extracts PTX code from CUDA binaries
  * PTX Parsing: Parses PTX code to build a symbol table
  * PTX Loading: Loads PTX code into the simulator
  * PTX Info: Extracts resource usage information using ptxas



Sources: [src/cuda-sim/ptx_loader.cc169-203](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_loader.cc#L169-L203) [libcuda/cuda_runtime_api.cc610-684](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L610-L684)

### PTX Loading and Parsing

The PTX loading process involves extracting PTX code from CUDA binaries and parsing it:

  1. `cudaRegisterFatBinaryInternal()` extracts PTX code from CUDA binaries
  2. `cuobjdumpInit()` processes the binaries to extract PTX and SASS code
  3. `gpgpu_ptx_sim_load_ptx_from_string()` parses the PTX code
  4. The parsed PTX is stored in a symbol table for later use



Sources: [src/cuda-sim/ptx_loader.cc169-203](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_loader.cc#L169-L203) [src/cuda-sim/ptx_loader.cc205-210](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_loader.cc#L205-L210)

### PTXInfo Extraction

GPGPU-Sim uses ptxas (NVIDIA's PTX assembler) to extract resource usage information from PTX code:

  1. `gpgpu_ptxinfo_load_from_string()` runs ptxas on the PTX code
  2. The output is parsed to extract register usage, shared memory usage, etc.
  3. This information is used to simulate resource constraints during kernel execution



Sources: [src/cuda-sim/ptx_loader.cc376-583](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_loader.cc#L376-L583) [src/cuda-sim/ptxinfo.l90-111](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptxinfo.l#L90-L111) [src/cuda-sim/ptxinfo.y104-137](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptxinfo.y#L104-L137)

## Integration with GPGPU-Sim

The CUDA Runtime API connects to GPGPU-Sim's core simulation components through several key interfaces:
[/code]
[code] 
Key integration points:

  * Context Management: `GPGPUSim_Context()` connects to GPGPU-Sim's context system
  * Device Simulation: `GPGPUSim_Init()` initializes the GPU simulator
  * Kernel Execution: `cudaLaunchInternal()` initiates kernel simulation
  * Stream Management: Kernel launches are managed through CUDA streams



Sources: [libcuda/cuda_runtime_api.cc197-266](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L197-L266) [libcuda/cuda_runtime_api.cc969-1036](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L969-L1036)

### Execution Flow

The execution flow from a CUDA API call to simulator execution follows this pattern:

  1. Application calls CUDA Runtime API function
  2. GPGPU-Sim's implementation intercepts the call
  3. The implementation translates the call to simulator operations
  4. Context and device are initialized if needed
  5. For kernel launches: 
     * Kernel configuration and arguments are set up
     * PTX code for the kernel is located
     * A grid is created for simulation
     * The kernel is simulated functionally and for performance



This flow allows GPGPU-Sim to provide detailed simulation of CUDA applications without requiring changes to the applications themselves.

Sources: [libcuda/cuda_runtime_api.cc969-1036](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/libcuda/cuda_runtime_api.cc#L969-L1036)

