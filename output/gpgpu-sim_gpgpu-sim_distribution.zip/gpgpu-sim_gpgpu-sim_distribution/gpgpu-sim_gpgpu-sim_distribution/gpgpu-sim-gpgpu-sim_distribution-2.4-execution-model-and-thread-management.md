---
source: https://deepwiki.com/gpgpu-sim/gpgpu-sim_distribution/2.4-execution-model-and-thread-management
crawled_at: 2025-06-03T19:42:01.426376
---



# Execution Model and Thread Management

Relevant source files

  * [src/abstract_hardware_model.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.cc)
  * [src/abstract_hardware_model.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h)
  * [src/cuda-sim/ptx_sim.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.cc)
  * [src/cuda-sim/ptx_sim.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h)
  * [src/gpgpu-sim/gpu-sim.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.cc)
  * [src/gpgpu-sim/gpu-sim.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h)
  * [src/gpgpu-sim/shader.cc](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc)
  * [src/gpgpu-sim/shader.h](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h)



This page explains how GPGPU-Sim manages threads, warps, and Cooperative Thread Arrays (CTAs) during simulation. It covers the hierarchical organization of threads, SIMT execution model, warp scheduling policies, and the lifecycle of threads from creation to termination.

For information about memory hierarchy and memory access patterns, see [Memory System](/gpgpu-sim/gpgpu-sim_distribution/2.3-memory-system).

## Thread Hierarchy

GPGPU-Sim models the NVIDIA CUDA/OpenCL execution hierarchy consisting of threads, warps, CTAs (also called blocks), and grids.
[/code]
[code] 
The thread hierarchy in GPGPU-Sim:

  * **Thread** : Basic unit of execution; each thread executes the same kernel code but operates on different data
  * **Warp** : Group of threads (typically 32) that execute in SIMT (Single Instruction, Multiple Thread) fashion
  * **CTA/Block** : Collection of warps that execute on the same SM (Streaming Multiprocessor)
  * **Grid** : Collection of all CTAs in a kernel launch



Sources: [src/abstract_hardware_model.h433-436](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L433-L436) [src/gpgpu-sim/shader.h102-175](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L102-L175) [src/abstract_hardware_model.h226-375](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L226-L375)

## Thread and Warp Representation

GPGPU-Sim uses several key classes to represent threads and warps for simulation:
[/code]
[code]   * **thread_ctx_t** : Basic thread state information
  * **ptx_thread_info** : Full thread context including registers, PC, thread ID, and execution state
  * **shd_warp_t** : Warp state including active threads, completion status, and resources
  * **ptx_cta_info** : Information about CTA including threads and their completion status



Sources: [src/gpgpu-sim/shader.h89-101](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L89-L101) [src/cuda-sim/ptx_sim.h291-519](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h#L291-L519) [src/gpgpu-sim/shader.h103-334](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L103-L334) [src/cuda-sim/ptx_sim.h158-180](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h#L158-L180)

## Thread Initialization and Resource Management

When a kernel is launched, GPGPU-Sim initializes the thread hierarchy:
[/code]
[code] 
Key thread initialization steps:

  1. The kernel_info_t class prepares thread dimensions and CTA layout
  2. shader_core_ctx::init_warps() initializes warps for a new CTA
  3. Each warp is initialized with its active threads and initial PC
  4. Thread resources like registers and local memory are allocated
  5. Thread IDs and CTA IDs are assigned based on the kernel's grid configuration



Sources: [src/gpgpu-sim/shader.cc532-580](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L532-L580) [src/gpgpu-sim/shader.h143-174](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L143-L174) [src/abstract_hardware_model.h257-294](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L257-L294)

## SIMT Execution Model

GPGPU-Sim implements the SIMT execution model where threads in a warp execute the same instruction but can diverge at branches:
[/code]
[code] 
The SIMT execution model ensures:

  1. All threads in a warp execute the same instruction at the same time
  2. When branches cause threads to diverge, the SIMT stack records divergent paths
  3. The `simt_stack` class manages branch divergence and reconvergence
  4. Only active threads (as determined by the active mask) execute the current instruction
  5. The performance model simulates thread execution in lockstep within a warp



Sources: [src/abstract_hardware_model.h439-481](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L439-L481) [src/gpgpu-sim/shader.h334-342](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L334-L342)

## Warp Scheduling Policies

GPGPU-Sim implements various warp scheduling policies that determine which warps execute on each cycle:
[/code]
[code] 
Key warp scheduling features:

  1. The `scheduler_unit` class schedules warps for execution
  2. Multiple scheduling policies are implemented: 
     * **LRR (Loose Round Robin)** : Cycles through warps sequentially
     * **GTO (Greedy Then Oldest)** : Prioritizes older warps to improve throughput
     * **Two-Level Active** : Two-level scheduling with inner and outer policies
     * **RRR (Round Robin)** : Strict round robin scheduling
     * **Oldest First** : Prioritizes warps based on age
  3. The scheduler considers warp dependencies and resource availability
  4. Multiple schedulers can operate within a single core (controlled by gpgpu_num_sched_per_core)



Sources: [src/gpgpu-sim/shader.h376-490](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L376-L490) [src/gpgpu-sim/shader.h492-566](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L492-L566) [src/gpgpu-sim/shader.cc186-269](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L186-L269)

## Thread Lifecycle and Completion

Threads progress through a lifecycle from initialization to completion:
[/code]
[code] 
Thread lifecycle management includes:

  1. Thread creation when a kernel is launched
  2. Thread execution according to the scheduler
  3. Thread can be in various states: 
     * **Active** : Ready to execute or executing
     * **Waiting** : Waiting for memory access or synchronization
     * **Completed** : Finished execution
  4. Thread completion is detected when: 
     * The thread executes an exit instruction (`set_done()`)
     * All threads in a CTA complete, allowing CTA resources to be reclaimed
  5. Resource reclamation is managed at multiple levels: 
     * Thread resources (registers, local memory)
     * Warp resources
     * CTA resources



Sources: [src/cuda-sim/ptx_sim.h383-385](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h#L383-L385) [src/cuda-sim/ptx_sim.cc193-197](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.cc#L193-L197) [src/gpgpu-sim/shader.cc505-530](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L505-L530) [src/cuda-sim/ptx_sim.cc120-168](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.cc#L120-L168)

## Barriers and Synchronization

GPGPU-Sim implements CTA-wide barriers for thread synchronization:
[/code]
[code] 
Barrier and synchronization features:

  1. CTA-wide barriers synchronized with `__syncthreads()` instructions
  2. The `ptx_cta_info` class tracks barrier state, including: 
     * Current barrier count (`m_bar_threads`)
     * Maximum barriers per CTA (`max_barriers_per_cta`)
  3. Threads reaching a barrier increment the barrier counter
  4. When all threads in a CTA reach the barrier, execution continues
  5. Barrier counter is reset for future synchronization points



Sources: [src/cuda-sim/ptx_sim.h132-136](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h#L132-L136) [src/cuda-sim/ptx_sim.cc132-136](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.cc#L132-L136) [src/abstract_hardware_model.h41-42](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L41-L42)

## Thread ID Management and Mapping

GPGPU-Sim maps hardware thread IDs (hw_tid) to logical thread IDs in the CUDA programming model:
[/code]
[code] 
Thread ID mapping features:

  1. Each thread has both logical and hardware IDs: 
     * **Logical IDs** : CTA ID (ctaid) and thread ID (tid) in 3D coordinates
     * **Hardware IDs** : SM ID (hw_sid), warp ID (hw_wid), thread ID (hw_tid)
  2. Helper functions convert between logical and hardware IDs: 
     * `hw_tid_from_wid(wid, warp_size, i)`: Computes hardware thread ID from warp ID
     * `wid_from_hw_tid(tid, warp_size)`: Computes warp ID from hardware thread ID
  3. Thread IDs are used to access thread-specific data and for scheduling



Sources: [src/gpgpu-sim/shader.h336-341](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L336-L341) [src/cuda-sim/ptx_sim.h294-304](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h#L294-L304) [src/abstract_hardware_model.h257-294](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L257-L294)

## Thread and Warp Status Tracking

GPGPU-Sim tracks the status of threads and warps for both functional and performance simulation:
[/code]
[code] 
Status tracking mechanisms include:

  1. Thread status fields: 
     * `m_valid`: Thread is valid and initialized
     * `m_thread_done`: Thread has completed execution
     * `m_active`: Thread is currently active
  2. Warp status tracking: 
     * `m_active_threads`: Bitset of active threads in the warp
     * `n_completed`: Count of completed threads in the warp
     * `m_at_barrier`: Warp is waiting at a barrier
     * `functional_done()`: Warp is functionally complete
     * `hardware_done()`: Warp is complete from hardware perspective
  3. Thread status is used for: 
     * Scheduling decisions
     * Resource reclamation
     * Performance metrics collection



Sources: [src/gpgpu-sim/shader.h89-101](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L89-L101) [src/gpgpu-sim/shader.h176-185](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.h#L176-L185) [src/cuda-sim/ptx_sim.h383-385](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/cuda-sim/ptx_sim.h#L383-L385) [src/gpgpu-sim/shader.cc614-615](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L614-L615)

## Resource Management and Limits

GPGPU-Sim enforces hardware resource limits for threads, warps, and CTAs:

Resource Type| Limit Constant| Typical Value| Description  
---|---|---|---  
Warps per CTA| `WARP_PER_CTA_MAX`| 64| Maximum warps per CTA  
CTAs per SM| `MAX_CTA_PER_SHADER`| 32| Maximum CTAs per shader core  
Barriers per CTA| `MAX_BARRIERS_PER_CTA`| 16| Maximum barriers per CTA  
Threads per SM| `MAX_THREAD_PER_SM`| 2048| Maximum threads per SM  
Warps per SM| `MAX_WARP_PER_SM`| 64| Maximum warps per SM  
  
Key resource management features:

  1. Register allocation: 
     * Each thread gets a set of registers defined by `gpgpu_shader_registers`
     * Register usage limits the number of concurrent CTAs
  2. Shared memory allocation: 
     * Shared memory is allocated per CTA, limited by `gpgpu_shmem_per_block`
     * Total shared memory per SM is limited by `gpgpu_shmem_size`
  3. CTA allocation is limited by: 
     * Available registers
     * Available shared memory
     * Maximum CTA limit (`max_cta_per_core`)
  4. Resource tracking variables: 
     * `m_occupied_n_threads`: Number of occupied threads
     * `m_occupied_shmem`: Amount of shared memory in use
     * `m_occupied_regs`: Number of registers in use
     * `m_occupied_ctas`: Number of CTAs in use



Sources: [src/abstract_hardware_model.h40-46](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L40-L46) [src/abstract_hardware_model.h491-496](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/abstract_hardware_model.h#L491-L496) [src/gpgpu-sim/shader.cc504-518](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/shader.cc#L504-L518) [src/gpgpu-sim/gpu-sim.h525-552](https://github.com/gpgpu-sim/gpgpu-sim_distribution/blob/a4ce3fea/src/gpgpu-sim/gpu-sim.h#L525-L552)

